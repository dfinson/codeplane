#!/usr/bin/env python3
"""
Evee CLI - A command-line interface for the Evee model evaluation package.
"""

import os
import sys
from contextlib import contextmanager

import click

from evee.execution.environment import ProjectEnvironmentError

from ..logging.logger import get_console
from .commands.clear import clear
from .commands.compute import compute
from .commands.dataset import dataset
from .commands.list import list_components
from .commands.metric import metric
from .commands.model import model
from .commands.new import new_project
from .commands.run import run
from .commands.tracking import tracking
from .commands.validate import validate
from .commands.view import view
from .utils.constants import EVEE_ASCII

# Get version without importing main package to avoid performance issues
try:
    from importlib.metadata import PackageNotFoundError, version

    __version__ = version("evee-ms-core")
except PackageNotFoundError:
    __version__ = "0.1.3"  # fallback version

console = get_console()


@contextmanager
def working_directory(path):
    """Context manager to temporarily change working directory and Python path."""
    original_cwd = os.getcwd()
    original_sys_path = sys.path.copy()

    try:
        if path:
            abs_path = os.path.abspath(path)
            os.chdir(abs_path)
        else:
            # Even when path is None, we need to ensure the current directory is in sys.path
            # This is necessary because when running via entry points (like `uv run evee`),
            # sys.path[0] may not contain the current directory
            abs_path = original_cwd

        # Add the working directory to Python path so modules can be imported
        if abs_path not in sys.path:
            sys.path.insert(0, abs_path)

        yield
    finally:
        os.chdir(original_cwd)
        sys.path[:] = original_sys_path


class OrderedGroup(click.Group):
    """Click Group that maintains command order instead of using the default alphabetical sorting."""

    def list_commands(self, _):
        return list(self.commands.keys())


@click.group(invoke_without_command=True, cls=OrderedGroup)
@click.option(
    "--version",
    "-v",
    is_flag=True,
    expose_value=False,
    is_eager=True,
    callback=lambda ctx, _param, value: (console.print(f"evee {__version__}"), ctx.exit()) if value else None,
    help="Show the version and exit.",
)
@click.help_option("--help", "-h")
@click.pass_context
def cli(ctx):
    """Evee - Simplifying model evaluation
    For more information, visit: https://github.com/microsoft/evee
    """
    if ctx.invoked_subcommand is None:
        console.print(EVEE_ASCII, style="cyan")
        click.echo(ctx.get_help())


cli.add_command(new_project)
cli.add_command(run)
cli.add_command(view)
cli.add_command(validate)
cli.add_command(list_components, name="list")
cli.add_command(model)
cli.add_command(metric)
cli.add_command(dataset)
cli.add_command(compute)
cli.add_command(tracking)
cli.add_command(clear)


def main():
    """Entry point for the CLI.

    This entry point handles transparent environment detection and delegation.
    If running from a global installation, it automatically detects the project's
    Python environment and re-executes the command there. This works for ALL
    commands (existing and future) without any command-specific logic.
    """
    # Check if we're already running in project environment (avoid infinite recursion)
    execution_mode = os.environ.get("EVEE_EXECUTION_MODE")

    if execution_mode == "direct":
        # Already in project environment - execute normally
        cli()
    else:
        # Check if we should delegate to project environment
        # Only delegate if we're in a directory (not just showing help/version)
        if _should_delegate_to_project_env():
            _execute_in_project_env()
        else:
            # Simple commands like --version, --help, or no cwd - run directly
            cli()


def _should_delegate_to_project_env() -> bool:
    """Determine if we should delegate to project environment.

    Don't delegate for:
    - --version or --help flags (even for subcommands)
    - Commands that don't need project context (new, dataset, metric, clear)
    """
    # If no command or only flags, don't delegate
    if len(sys.argv) <= 1:
        return False

    args = sys.argv[1:]

    # Never delegate for help or version flags - these should be fast and work
    # even if the project environment is misconfigured
    if any(arg in ["--version", "-v", "--help", "-h"] for arg in args):
        return False

    # Commands that don't need project environment delegation
    # These commands work on the file system and don't need to run in project venv
    non_delegated_commands = ["new", "dataset", "metric", "clear", "view"]

    # Check if first non-flag argument is a non-delegated command
    for arg in args:
        if not arg.startswith("-"):
            return arg not in non_delegated_commands

    # No command specified, don't delegate
    return False


def _execute_in_project_env():
    """Execute the CLI command in the project's Python environment.

    Uses ExecutionRunner to detect the project environment and re-invoke
    the same command with the correct Python interpreter.
    """
    from dotenv import load_dotenv

    from evee.execution import ExecutionRunner

    runner = ExecutionRunner()

    # Determine project path, config, and env from CLI args
    project_path, config_path, config_explicit, env_path = _extract_project_info_from_args()

    # Load .env file before environment detection (for env var substitution in config)
    if env_path and os.path.isfile(env_path):
        load_dotenv(dotenv_path=env_path, override=True)

    # Get CLI args and convert relative paths to absolute
    cli_args = _normalize_cli_args_for_delegation(sys.argv[1:])

    try:
        # Detect and show which Python environment will be used
        env_info = runner.resolver.get_environment_info(project_path, config_path=config_path, config_explicit=config_explicit)
        console.print(f"[dim]Using Python environment: [cyan]{env_info['env_type']}[/cyan] ({env_info['path']})[/dim]")

        # Stream output to maintain interactive CLI experience
        def output_handler(line: str):
            sys.stdout.write(line)
            sys.stdout.flush()  # Ensure immediate output for progress bars

        result = runner.execute(
            project_path=project_path,
            cli_args=cli_args,
            output_callback=output_handler,
            env_vars={"EVEE_EXECUTION_MODE": "direct"},  # Prevent recursion
            config_path=config_path,  # For python_executable override
            config_explicit=config_explicit,  # Whether --config was explicit
        )

        # Exit with same code as subprocess
        sys.exit(result.returncode)

    except ProjectEnvironmentError as e:
        # Environment detection/validation errors - provide helpful message
        console.print(f"\n[red]Environment Error:[/red] {str(e)}", style="bold")
        console.print("\n[dim]Tip: Use -p/--path to specify the project directory, configure runtime.python_executable in your config.yaml, or ensure evee is installed in your project environment.[/dim]")
        sys.exit(1)
    except Exception as e:
        # Other execution errors
        console.print(f"\n[red]Error:[/red] {str(e)}", style="bold")
        sys.exit(1)


def _extract_project_info_from_args() -> tuple[str, str | None, bool, str | None]:
    """Extract project path, config path, and env path from CLI arguments.

    Strategy:
    1. For '-p/--path <PATH>' flag, use the PATH argument as project root
    2. Otherwise, use current working directory (user must cd to project)
    3. Extract --config path if provided, or fall back to default config location
    4. Extract --env path if provided, or fall back to default .env in project

    Returns:
        Tuple of (project_path, config_path, config_explicit, env_path)
        - project_path: Absolute path to the project directory
        - config_path: Absolute path to config file if found, None otherwise
        - config_explicit: True if --config was explicitly provided by user
        - env_path: Absolute path to env file if found, None otherwise
    """
    from .constants import DEFAULT_CONFIG_FILE, DEFAULT_ENV_FILE

    args = sys.argv[1:]  # Skip script name
    project_path = os.getcwd()  # Default to current directory
    config_path = None
    config_explicit = False  # Track if user explicitly provided --config
    env_path = None

    # Check for '-p' or '--path' flag
    for i, arg in enumerate(args):
        if arg in ["-p", "--path"] and i + 1 < len(args):
            path = args[i + 1]
            if os.path.isdir(path):
                project_path = os.path.abspath(path)
            else:
                # Explicitly-provided path must exist - fail loudly rather than silently falling back
                console.print(f"[red]Error:[/red] Path '{path}' does not exist or is not a directory")
                sys.exit(1)
            break

    # Extract --config path if provided (for override detection)
    for i, arg in enumerate(args):
        if arg in ["--config", "-c"] and i + 1 < len(args):
            cfg = args[i + 1]
            config_explicit = True  # User explicitly provided --config
            # Resolve to absolute path
            if os.path.isabs(cfg):
                config_path = cfg
            elif cfg.startswith("./") or cfg.startswith("../"):
                # Paths starting with ./ or ../ are relative to cwd
                config_path = os.path.abspath(cfg)
            else:
                # Other relative paths are relative to project_path
                config_path = os.path.abspath(os.path.join(project_path, cfg))
            break

    # If no config specified, check for default config in project directory
    if config_path is None:
        default_config = os.path.join(project_path, DEFAULT_CONFIG_FILE)
        if os.path.isfile(default_config):
            config_path = default_config

    # Extract --env path if provided
    for i, arg in enumerate(args):
        if arg in ["--env", "-e"] and i + 1 < len(args):
            env = args[i + 1]
            # Resolve to absolute path
            if os.path.isabs(env):
                env_path = env
            elif env.startswith("./") or env.startswith("../"):
                # Paths starting with ./ or ../ are relative to cwd
                env_path = os.path.abspath(env)
            else:
                # Other relative paths are relative to project_path
                env_path = os.path.abspath(os.path.join(project_path, env))
            break

    # If no env specified, check for default .env in project directory
    if env_path is None:
        default_env = os.path.join(project_path, DEFAULT_ENV_FILE)
        if os.path.isfile(default_env):
            env_path = default_env

    return project_path, config_path, config_explicit, env_path


def _normalize_cli_args_for_delegation(args: list[str]) -> list[str]:
    """Normalize CLI arguments by converting relative paths to absolute paths.

    This ensures that when the command is re-executed in a different working directory,
    relative paths still resolve correctly.

    When --path is specified, other relative paths (like --config) are resolved
    relative to the project path, not the current working directory.

    Note: This normalization handles separated flags (e.g., "--config file.yaml")
    but not combined short flags ("-pe .env") or equal-sign syntax ("--config=file.yaml").
    Users should use separated flag syntax for reliable path normalization.

    Args:
        args: Original CLI arguments

    Returns:
        Normalized CLI arguments with absolute paths
    """
    # Flags that accept file/directory paths
    path_flags = [
        "--path",
        "-p",  # project path
        "--config",
        "-c",  # config file
        "--dataset",
        "-d",  # dataset file
        "--env",
        "-e",  # environment file
        "--output",
        "-o",  # output directory
        "--from",
        "-f",  # source file for import
        "--from-source",
        "-s",  # source directory for new command
    ]

    # First pass: extract and normalize project path if specified
    project_path = None
    for i, arg in enumerate(args):
        if arg in ["--path", "-p"] and i + 1 < len(args):
            path = args[i + 1]
            if os.path.isdir(path):
                project_path = os.path.abspath(path)
            elif not os.path.isabs(path):
                # Make relative path absolute for warning check
                project_path = os.path.abspath(path)
            else:
                project_path = path
            break

    # Second pass: normalize all paths
    normalized = []
    i = 0
    while i < len(args):
        arg = args[i]

        # Check if previous arg was a path flag
        if i > 0 and args[i - 1] in path_flags:
            # Normalize --path to absolute (relative to cwd)
            if args[i - 1] in ["--path", "-p"]:
                if not os.path.isabs(arg):
                    arg = os.path.abspath(arg)
                normalized.append(arg)
            # Convert other relative paths to absolute
            elif not os.path.isabs(arg):
                # Paths starting with ./ or ../ are relative to cwd
                if arg.startswith("./") or arg.startswith("../"):
                    arg = os.path.abspath(arg)
                else:
                    # If project path is specified, resolve relative to it
                    # Otherwise, resolve relative to current directory
                    base_dir = project_path if project_path else os.getcwd()
                    arg = os.path.abspath(os.path.join(base_dir, arg))
                normalized.append(arg)
            else:
                normalized.append(arg)
        else:
            normalized.append(arg)

        i += 1

    return normalized


if __name__ == "__main__":
    main()
