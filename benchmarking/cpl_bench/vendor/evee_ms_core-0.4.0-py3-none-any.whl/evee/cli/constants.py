"""Constants used across the evee CLI."""

# Default paths
DEFAULT_CONFIG_FILE = "experiment/config.yaml"
DEFAULT_ENV_FILE = ".env"
DEFAULT_DATA_DIR = "experiment/data"
DEFAULT_MODELS_DIR = "models"
DEFAULT_METRICS_DIR = "experiment/metrics"
DEFAULT_PROMPTS_DIR = "prompt_template"
DEFAULT_OUTPUT_DIR = "experiment/output"

# File naming patterns
METRIC_FILE_SUFFIX = "_metric.py"
MODEL_FILE_SUFFIX = ".py"
PROMPT_FILE_SUFFIX = ".j2"

# Validation limits
MAX_NAME_LENGTH = 100
MAX_DESCRIPTION_LENGTH = 500

# Template types
TEMPLATE_TYPE_EMPTY = "empty"
TEMPLATE_TYPE_FOUNDRY = "foundry"

# Azure AI Evaluator data
AZURE_EVALUATORS_DATA_FILE = "azure_evaluators.json"

# Config version defaults
DEFAULT_DATASET_VERSION = "1.0.0"
DEFAULT_MODEL_VERSION = "1.0.0"
