"""Compute backend management commands for evee CLI."""

import copy
import tomllib
from importlib.metadata import entry_points
from importlib.resources import files
from pathlib import Path
from typing import Any

import click
from rich.console import Console

from evee.cli.constants import DEFAULT_CONFIG_FILE
from evee.cli.utils.backend_helpers import (
    print_dependency_instruction,
)
from evee.cli.utils.config_manager import ConfigManager

console = Console()

# Valid compute backends
VALID_COMPUTE_BACKENDS = ["local", "azureml"]

# Package requirements for each backend
BACKEND_PACKAGES = {
    "azureml": "evee-ms-azureml",
}

# Environment variables required for each backend
BACKEND_ENV_VARS = {
    "azureml": {
        "required": [
            "AZURE_ML_TENANT_ID",
            "AZURE_ML_WORKSPACE_NAME",
            "AZURE_ML_RESOURCE_GROUP",
            "AZURE_ML_SUBSCRIPTION_ID",
        ],
        "optional": [
            "AZURE_ML_CLIENT_ID",
        ],
    },
}

# Default templates for each backend
COMPUTE_TEMPLATES: dict[str, dict[str, Any]] = {
    "local": {
        "type": "local",
    },
    "azureml": {
        "type": "azureml",
        "workspace": {
            "tenant_id": "${AZURE_ML_TENANT_ID}",
            "client_id": "${AZURE_ML_CLIENT_ID:-}",
            "name": "${AZURE_ML_WORKSPACE_NAME}",
            "resource_group": "${AZURE_ML_RESOURCE_GROUP}",
            "subscription_id": "${AZURE_ML_SUBSCRIPTION_ID}",
        },
        "pyproject_file": "pyproject.toml",
        "stream_remote_logs": False,
        "compute_target": {
            "name": "cpu-cluster",
            "size": "STANDARD_DS3_v2",
            "location": "swedencentral",
            "min_instances": 0,
            "max_instances": 4,
            "idle_time_before_scale_down": "3600",
            "tier": "Dedicated",
        },
        "environment": {
            "name": "${EVEE_ENVIRONMENT_NAME:-evee-environment}",
            "version": "1.0.0",
        },
    },
}


def _print_dependency_instruction(backend: str, config_path: Path) -> None:
    """Print smart dependency instruction based on project source type."""
    if backend not in BACKEND_PACKAGES:
        return
    print_dependency_instruction(backend, config_path, console)


def _get_project_name(project_root: Path) -> str:
    """Get project name from pyproject.toml or directory name."""
    pyproject_path = project_root / "pyproject.toml"
    if pyproject_path.exists():
        try:
            with open(pyproject_path, "rb") as f:
                pyproject = tomllib.load(f)
            name = pyproject.get("project", {}).get("name")
            if name:
                return name
        except Exception:
            # Intentionally ignore errors reading/parsing pyproject.toml
            # and fall back to using the project_root directory name.
            pass
    return project_root.name


def _copy_azureml_overlay_files(project_root: Path) -> list[str]:
    """Copy Azure ML overlay files (Dockerfile.aml, .amlignore) if missing.

    Args:
        project_root: Root directory of the project

    Returns:
        List of files that were copied
    """
    copied_files = []

    # Locate template directory
    evee_package_dir = Path(__file__).parent.parent
    dev_overlay_dir = evee_package_dir / "templates" / "overlays" / "azureml"

    if dev_overlay_dir.exists():
        overlay_dir = dev_overlay_dir
    else:
        # Fall back to installed package resources
        try:
            overlay_dir = Path(str(files("evee").joinpath("cli/templates/overlays/azureml")))
        except Exception:
            return copied_files

    # Files to copy if missing
    overlay_files = ["Dockerfile.aml", ".amlignore"]
    project_name = _get_project_name(project_root)

    for filename in overlay_files:
        src_path = overlay_dir / filename
        dst_path = project_root / filename

        if not dst_path.exists() and src_path.exists():
            # Read and substitute template variables
            content = src_path.read_text()
            content = content.replace("{project_name}", project_name)
            dst_path.write_text(content)
            copied_files.append(filename)

    return copied_files


def _get_available_compute_backends() -> set[str]:
    """Get available compute backend types from entry points."""
    eps = entry_points(group="evee.compute_backends")
    return {ep.name for ep in eps}


def _check_backend_available(backend_type: str) -> tuple[bool, str | None]:
    """Check if backend is available, return (available, missing_package_name)."""
    available = _get_available_compute_backends()
    if backend_type in available:
        return True, None
    return False, BACKEND_PACKAGES.get(backend_type)


def _update_env_sample(env_vars: dict[str, list[str]], env_sample_path: Path) -> bool:
    """Update .env.sample with required environment variables.

    Args:
        env_vars: Dict with 'required' and 'optional' lists of env var names
        env_sample_path: Path to .env.sample file

    Returns:
        True if file was updated, False otherwise
    """
    try:
        existing_content = ""
        if env_sample_path.exists():
            existing_content = env_sample_path.read_text()

        lines_to_add = []

        # Add required vars
        for var in env_vars.get("required", []):
            if var not in existing_content:
                lines_to_add.append(f"{var}=")

        # Add optional vars with comment
        for var in env_vars.get("optional", []):
            if var not in existing_content:
                lines_to_add.append(f"# {var}=  # Optional")

        if lines_to_add:
            # Add a section header if adding new vars
            if existing_content and not existing_content.endswith("\n\n"):
                if not existing_content.endswith("\n"):
                    existing_content += "\n"
                existing_content += "\n"

            if "# Azure ML" not in existing_content:
                existing_content += "# Azure ML\n"

            existing_content += "\n".join(lines_to_add) + "\n"
            env_sample_path.write_text(existing_content)
            return True

        return False
    except Exception:
        return False


@click.group()
@click.help_option("--help", "-h")
def compute():
    """Manage compute backend configuration."""
    pass


@compute.command(name="set")
@click.argument("backend", type=click.Choice(VALID_COMPUTE_BACKENDS))
@click.option(
    "--config",
    "-c",
    default=DEFAULT_CONFIG_FILE,
    help=f"Path to config file (default: {DEFAULT_CONFIG_FILE})",
    type=click.Path(),
)
@click.option("--force", "-f", is_flag=True, help="Overwrite existing configuration without prompting")
@click.help_option("--help", "-h")
def set_backend(backend: str, config: str, force: bool):
    """Set the compute backend for your experiment.

    BACKEND: The compute backend to use (local, azureml)

    Examples:

        evee compute set local           # Run experiments locally

        evee compute set azureml         # Configure Azure ML remote execution

        evee compute set azureml -f      # Overwrite existing config
    """
    config_path = Path(config)
    if not config_path.exists():
        console.print(f"[red]Error: Config file not found:[/red] {config_path}")
        console.print("\n[dim]Create a project first with: evee new my-project[/dim]")
        raise click.Abort()

    # Check if backend package is installed (for non-local backends)
    if backend != "local":
        available, missing_package = _check_backend_available(backend)
        if not available:
            console.print(f"[red]Error: '{backend}' compute backend not available[/red]")
            _print_dependency_instruction(backend, config_path)
            raise click.Abort()

    manager = ConfigManager(config_path)
    existing_config = manager.get_compute_backend()

    # Check for existing non-trivial config
    existing_type = existing_config.get("type") if existing_config else None
    has_workspace = existing_config.get("workspace") if existing_config else None

    if existing_type == "azureml" and has_workspace and not force:
        console.print(f"[yellow]Compute backend already configured as '{existing_type}'[/yellow]")
        if not click.confirm("Overwrite existing configuration?", default=False):
            raise click.Abort()

    # Get and apply template
    # Use deepcopy since templates contain nested dicts (e.g., workspace)
    template = copy.deepcopy(COMPUTE_TEMPLATES[backend])
    success = manager.update_compute_backend(template)

    if not success:
        console.print("[red]Error: Failed to update config[/red]")
        raise click.Abort()

    console.print(f"[green]✓[/green] Compute backend set to [cyan]{backend}[/cyan]")

    # Show dependency instruction for non-local backends
    if backend in BACKEND_PACKAGES:
        _print_dependency_instruction(backend, config_path)

    # Backend-specific next steps
    if backend == "azureml":
        env_vars = BACKEND_ENV_VARS["azureml"]
        project_root = config_path.parent.parent

        # Try to update .env.sample
        env_sample_path = project_root / ".env.sample"
        if env_sample_path.exists() or (project_root / ".env").exists():
            _update_env_sample(env_vars, env_sample_path)
            console.print(f"\n[dim]Updated {env_sample_path}[/dim]")

        # Copy Azure ML overlay files if missing
        copied_files = _copy_azureml_overlay_files(project_root)
        if copied_files:
            console.print(f"\n[green]✓[/green] Added required files: [cyan]{', '.join(copied_files)}[/cyan]")

        console.print("\n[bold yellow]Configuration required:[/bold yellow]")
        console.print("\n[bold]1. Set environment variables[/bold] in .env or export them:")
        console.print("   [dim]Required:[/dim]")
        for var in env_vars["required"]:
            console.print(f"     {var}")
        console.print("   [dim]Optional:[/dim]")
        for var in env_vars["optional"]:
            console.print(f"     {var}")

        console.print("\n[bold]2. Review compute_target settings[/bold] in config.yaml:")
        console.print("   [dim]name: cluster name (created if doesn't exist)[/dim]")
        console.print("   [dim]size: VM size (default: STANDARD_DS3_v2)[/dim]")
        console.print("   [dim]max_instances: scaling limit[/dim]")

        console.print("\n[bold]3. Run with remote execution:[/bold]")
        console.print("   [cyan]evee run --remote[/cyan]")
    else:
        console.print("\n[dim]Run experiments with: evee run[/dim]")


@compute.command(name="show")
@click.option(
    "--config",
    "-c",
    default=DEFAULT_CONFIG_FILE,
    help=f"Path to config file (default: {DEFAULT_CONFIG_FILE})",
    type=click.Path(),
)
@click.help_option("--help", "-h")
def show_backend(config: str):
    """Show current compute backend configuration."""
    config_path = Path(config)
    if not config_path.exists():
        console.print(f"[red]Error: Config file not found:[/red] {config_path}")
        raise click.Abort()

    manager = ConfigManager(config_path)
    compute_config = manager.get_compute_backend()

    if not compute_config:
        console.print("[yellow]No compute backend configured[/yellow]")
        console.print("\n[dim]Set one with: evee compute set <local|azureml>[/dim]")
        return

    backend_type = compute_config.get("type", "local")
    console.print(f"\n[bold cyan]Compute Backend:[/bold cyan] {backend_type}\n")

    if backend_type == "azureml":
        workspace = compute_config.get("workspace", {})
        target = compute_config.get("compute_target", {})
        env = compute_config.get("environment", {})

        console.print("[bold]Workspace:[/bold]")
        for key in ["subscription_id", "resource_group", "name"]:
            val = workspace.get(key, "[dim]not set[/dim]")
            # Mask env var references for cleaner display
            if isinstance(val, str) and val.startswith("${"):
                val = f"[dim]{val}[/dim]"
            console.print(f"  {key}: {val}")

        console.print("\n[bold]Compute Target:[/bold]")
        for key in ["name", "size", "max_instances"]:
            console.print(f"  {key}: {target.get(key, '[dim]not set[/dim]')}")

        console.print("\n[bold]Environment:[/bold]")
        console.print(f"  name: {env.get('name', '[dim]not set[/dim]')}")
        console.print(f"  version: {env.get('version', '[dim]not set[/dim]')}")
    else:
        console.print("[dim]Local compute runs experiments on this machine.[/dim]")
