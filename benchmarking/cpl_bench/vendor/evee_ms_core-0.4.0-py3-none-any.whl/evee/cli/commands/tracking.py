"""Tracking backend management commands for evee CLI."""

import copy
from importlib.metadata import entry_points
from pathlib import Path
from typing import Any

import click
from rich.console import Console

from evee.cli.constants import DEFAULT_CONFIG_FILE
from evee.cli.utils.backend_helpers import (
    print_dependency_instruction,
)
from evee.cli.utils.config_manager import ConfigManager

console = Console()


# User-facing backend names
VALID_TRACKING_BACKENDS = ["none", "mlflow", "azureml"]

# Map user-facing names to internal types
BACKEND_NAME_MAP = {
    "none": "core",  # "none" maps to internal "core" (NoOpFallbackBackend)
}

# Map internal types to user-facing names (for display)
BACKEND_DISPLAY_MAP = {
    "core": "none",
}

# Package requirements for each backend
BACKEND_PACKAGES = {
    "mlflow": "evee-ms-mlflow",
    "azureml": "evee-ms-azureml",
}

# Environment variables for each backend
BACKEND_ENV_VARS = {
    "mlflow": {
        "optional": ["MLFLOW_TRACKING_URI"],
    },
    "azureml": {
        "required": [
            "AZURE_ML_TENANT_ID",
            "AZURE_ML_WORKSPACE_NAME",
            "AZURE_ML_RESOURCE_GROUP",
            "AZURE_ML_SUBSCRIPTION_ID",
        ],
        "optional": [
            "AZURE_ML_CLIENT_ID",
        ],
    },
}

# Default templates for each backend
TRACKING_TEMPLATES: dict[str, dict[str, Any]] = {
    "core": {  # Internal name for "none"
        "type": "core",
        "enabled": False,
    },
    "mlflow": {
        "type": "mlflow",
        "enabled": True,
        "tracking_uri": "${MLFLOW_TRACKING_URI:-sqlite:///mlflow.db}",
    },
    "azureml": {
        "type": "azureml",
        "enabled": True,
        "workspace": {
            "tenant_id": "${AZURE_ML_TENANT_ID}",
            "client_id": "${AZURE_ML_CLIENT_ID:-}",
            "name": "${AZURE_ML_WORKSPACE_NAME}",
            "resource_group": "${AZURE_ML_RESOURCE_GROUP}",
            "subscription_id": "${AZURE_ML_SUBSCRIPTION_ID}",
        },
    },
}


def _get_available_tracking_backends() -> set[str]:
    """Get available tracking backend types from entry points."""
    eps = entry_points(group="evee.tracking_backends")
    available = {ep.name for ep in eps}
    # "core" is always available (it's the built-in fallback)
    available.add("core")
    return available


def _check_backend_available(backend_type: str) -> tuple[bool, str | None]:
    """Check if backend is available, return (available, missing_package_name)."""
    available = _get_available_tracking_backends()
    if backend_type in available:
        return True, None
    return False, BACKEND_PACKAGES.get(backend_type)


def _get_workspace_from_compute(manager: ConfigManager) -> dict[str, Any] | None:
    """Check if compute_backend has workspace config that can be reused."""
    compute = manager.get_compute_backend()
    if compute and compute.get("type") == "azureml" and compute.get("workspace"):
        return compute["workspace"]
    return None


def _get_experiment_name(manager: ConfigManager) -> str | None:
    """Get experiment name from config."""
    experiment = manager.read_section("experiment")
    if experiment:
        return experiment.get("name")
    return None


@click.group()
@click.help_option("--help", "-h")
def tracking():
    """Manage tracking backend configuration."""
    pass


@tracking.command(name="set")
@click.argument("backend", type=click.Choice(VALID_TRACKING_BACKENDS))
@click.option(
    "--config",
    "-c",
    default=DEFAULT_CONFIG_FILE,
    help=f"Path to config file (default: {DEFAULT_CONFIG_FILE})",
    type=click.Path(),
)
@click.option("--force", "-f", is_flag=True, help="Skip confirmation prompts")
@click.help_option("--help", "-h")
def set_backend(backend: str, config: str, force: bool):
    """Set the tracking backend for your experiment.

    BACKEND: The tracking backend to use (none, mlflow, azureml)

    \b
    Backend descriptions:
      none    - Disable tracking (results saved locally only)
      mlflow  - Use MLflow for experiment tracking
      azureml - Use Azure ML workspace for tracking

    Examples:

        evee tracking set none           # Disable tracking

        evee tracking set mlflow         # Use MLflow tracking

        evee tracking set azureml        # Use Azure ML tracking
    """
    config_path = Path(config)
    if not config_path.exists():
        console.print(f"[red]Error: Config file not found:[/red] {config_path}")
        console.print("\n[dim]Create a project first with: evee new my-project[/dim]")
        raise click.Abort()

    # Map user-facing name to internal type
    backend_type = BACKEND_NAME_MAP.get(backend, backend)
    display_name = backend  # Use the user-provided name for display

    # Check if backend package is installed (for non-core backends)
    if backend_type not in ("core",):
        available, missing_package = _check_backend_available(backend_type)
        if not available:
            console.print(f"[red]Error: '{display_name}' tracking backend not available[/red]")
            print_dependency_instruction(backend_type, config_path, console)
            raise click.Abort()

    manager = ConfigManager(config_path)

    # Get experiment name to set in tracking config
    experiment_name = _get_experiment_name(manager)

    # Build the new tracking config from template
    # Use deepcopy since templates contain nested dicts (e.g., workspace)
    template = copy.deepcopy(TRACKING_TEMPLATES[backend_type])

    # Add experiment_name for mlflow/azureml
    if backend_type in ("mlflow", "azureml") and experiment_name:
        template["experiment_name"] = experiment_name

    # Handle workspace reuse for azureml
    if backend_type == "azureml" and not force:
        compute_workspace = _get_workspace_from_compute(manager)
        if compute_workspace:
            ws_name = compute_workspace.get("name", "unknown")
            ws_rg = compute_workspace.get("resource_group", "unknown")
            console.print("[green]✓[/green] Found Azure ML workspace in compute_backend")
            console.print(f"  [dim]Workspace: {ws_name} (resource-group: {ws_rg})[/dim]")

            if click.confirm("\nReuse this workspace for tracking?", default=True):
                # Deepcopy the workspace config to avoid sharing references
                template["workspace"] = copy.deepcopy(compute_workspace)

    # Update config
    success = manager.update_tracking_backend(template)

    if not success:
        console.print("[red]Error: Failed to update config[/red]")
        raise click.Abort()

    console.print(f"[green]✓[/green] Tracking backend set to [cyan]{display_name}[/cyan]")

    # Show dependency instruction for non-core backends
    if backend_type in BACKEND_PACKAGES:
        print_dependency_instruction(backend_type, config_path, console)

    # Backend-specific guidance
    if backend_type == "core":
        console.print("\n[dim]Tracking is disabled. Results will be saved locally in output_path.[/dim]")
    elif backend_type == "mlflow":
        console.print("\n[dim]MLflow will track runs to sqlite:///mlflow.db by default.[/dim]")
        console.print("[dim]Set MLFLOW_TRACKING_URI in .env for a remote server.[/dim]")
        console.print("\n[bold]View results with:[/bold]")
        console.print("  [cyan]mlflow ui[/cyan]")
    elif backend_type == "azureml":
        env_vars = BACKEND_ENV_VARS["azureml"]
        console.print("\n[bold yellow]Configuration required:[/bold yellow]")
        console.print("\n[bold]Set environment variables[/bold] in .env:")
        console.print("   [dim]Required:[/dim]")
        for var in env_vars["required"]:
            console.print(f"     {var}")
        console.print("\n[bold]View results in Azure ML Studio[/bold]")


@tracking.command(name="show")
@click.option(
    "--config",
    "-c",
    default=DEFAULT_CONFIG_FILE,
    help=f"Path to config file (default: {DEFAULT_CONFIG_FILE})",
    type=click.Path(),
)
@click.help_option("--help", "-h")
def show_backend(config: str):
    """Show current tracking backend configuration."""
    config_path = Path(config)
    if not config_path.exists():
        console.print(f"[red]Error: Config file not found:[/red] {config_path}")
        raise click.Abort()

    manager = ConfigManager(config_path)
    tracking_config = manager.get_tracking_backend()

    if not tracking_config:
        console.print("[yellow]No tracking backend configured[/yellow]")
        console.print("\n[dim]Set one with: evee tracking set <none|mlflow|azureml>[/dim]")
        return

    backend_type = tracking_config.get("type", "core")
    display_name = BACKEND_DISPLAY_MAP.get(backend_type, backend_type)
    enabled = tracking_config.get("enabled", True)

    status_icon = "[green]✓[/green]" if enabled else "[dim]✗[/dim]"
    console.print(f"\n[bold cyan]Tracking Backend:[/bold cyan] {display_name}")
    console.print(f"  Status: {status_icon} {'enabled' if enabled else 'disabled'}")

    if backend_type == "mlflow":
        uri = tracking_config.get("tracking_uri", "[dim]not set[/dim]")
        exp_name = tracking_config.get("experiment_name", "[dim]not set[/dim]")
        console.print(f"  Tracking URI: {uri}")
        console.print(f"  Experiment: {exp_name}")
    elif backend_type == "azureml":
        workspace = tracking_config.get("workspace", {})
        exp_name = tracking_config.get("experiment_name", "[dim]not set[/dim]")
        console.print(f"  Experiment: {exp_name}")
        console.print("\n[bold]Workspace:[/bold]")
        for key in ["name", "resource_group", "subscription_id"]:
            val = workspace.get(key, "[dim]not set[/dim]")
            if isinstance(val, str) and val.startswith("${"):
                val = f"[dim]{val}[/dim]"
            console.print(f"    {key}: {val}")
    elif backend_type == "core":
        console.print("\n[dim]Results are saved locally to output_path only.[/dim]")


@tracking.command(name="enable")
@click.option(
    "--config",
    "-c",
    default=DEFAULT_CONFIG_FILE,
    help=f"Path to config file (default: {DEFAULT_CONFIG_FILE})",
    type=click.Path(),
)
@click.help_option("--help", "-h")
def enable_tracking(config: str):
    """Enable tracking for the current backend."""
    config_path = Path(config)
    if not config_path.exists():
        console.print(f"[red]Error: Config file not found:[/red] {config_path}")
        raise click.Abort()

    manager = ConfigManager(config_path)
    tracking_config = manager.get_tracking_backend()

    if not tracking_config:
        console.print("[yellow]No tracking backend configured[/yellow]")
        console.print("\n[dim]Set one first with: evee tracking set <mlflow|azureml>[/dim]")
        raise click.Abort()

    backend_type = tracking_config.get("type", "core")
    if backend_type == "core":
        console.print("[yellow]Cannot enable 'none' backend - it disables tracking by design[/yellow]")
        console.print("\n[dim]Switch to a tracking backend: evee tracking set <mlflow|azureml>[/dim]")
        raise click.Abort()

    tracking_config["enabled"] = True
    success = manager.update_tracking_backend(tracking_config)

    if success:
        display_name = BACKEND_DISPLAY_MAP.get(backend_type, backend_type)
        console.print(f"[green]✓[/green] Tracking enabled for [cyan]{display_name}[/cyan]")
    else:
        console.print("[red]Error: Failed to update config[/red]")
        raise click.Abort()


@tracking.command(name="disable")
@click.option(
    "--config",
    "-c",
    default=DEFAULT_CONFIG_FILE,
    help=f"Path to config file (default: {DEFAULT_CONFIG_FILE})",
    type=click.Path(),
)
@click.help_option("--help", "-h")
def disable_tracking(config: str):
    """Disable tracking without changing the backend."""
    config_path = Path(config)
    if not config_path.exists():
        console.print(f"[red]Error: Config file not found:[/red] {config_path}")
        raise click.Abort()

    manager = ConfigManager(config_path)
    tracking_config = manager.get_tracking_backend()

    if not tracking_config:
        console.print("[yellow]No tracking backend configured[/yellow]")
        return

    tracking_config["enabled"] = False
    success = manager.update_tracking_backend(tracking_config)

    if success:
        backend_type = tracking_config.get("type", "core")
        display_name = BACKEND_DISPLAY_MAP.get(backend_type, backend_type)
        console.print(f"[green]✓[/green] Tracking disabled for [cyan]{display_name}[/cyan]")
        console.print("\n[dim]Re-enable with: evee tracking enable[/dim]")
    else:
        console.print("[red]Error: Failed to update config[/red]")
        raise click.Abort()
