"""Clear command for removing experiment output folders."""

from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from ..utils.clear_operations import (
    analyze,
    delete_folders,
    format_size,
    read_output_path_from_config,
    validate_path,
)

console = Console()


@click.command()
@click.option(
    "--path",
    "-p",
    type=click.Path(exists=False, path_type=Path),
    help="Path to output directory (default: experiment/output or from config)",
)
@click.option(
    "--config",
    "-c",
    type=click.Path(path_type=Path),
    default="experiment/config.yaml",
    help="Path to config.yaml (default: experiment/config.yaml)",
)
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Skip confirmation prompt",
)
@click.option(
    "--preview",
    "-r",
    is_flag=True,
    help="Preview what would be deleted without deleting",
)
@click.option(
    "--keep-last",
    "-k",
    type=click.IntRange(min=0),
    default=0,
    help="Keep N most recent experiments",
)
@click.option(
    "--before",
    "-b",
    type=str,
    help="Remove experiments before date (YYYY-MM-DD)",
)
@click.option(
    "--after",
    "-a",
    type=str,
    help="Remove experiments after date (YYYY-MM-DD)",
)
@click.option(
    "--logs-only",
    "-l",
    is_flag=True,
    help="Clear only logs subdirectories",
)
@click.help_option("--help", "-h")
def clear(
    path: Path | None,
    config: Path,
    force: bool,
    preview: bool,
    keep_last: int,
    before: str | None,
    after: str | None,
    logs_only: bool,
):
    """Clear experiment output folders.

    Discovers and removes timestamped experiment folders from the output directory.
    Supports filtering by date range and keeping recent experiments.

    Args:
        path: Path to output directory. If not provided, reads from config or defaults
            to "experiment/output".
        config: Path to config.yaml file for reading output_path setting.
        force: If True, skip the confirmation prompt.
        preview: If True, show what would be deleted without actually deleting.
        keep_last: Number of most recent experiments to preserve (0 = delete all).
        before: Only delete experiments before this date (YYYY-MM-DD format).
        after: Only delete experiments after this date (YYYY-MM-DD format).
        logs_only: If True, only clear logs/ subdirectories within experiment folders.

    Raises:
        click.Abort: If path is invalid, date format is wrong, or user cancels.
    """

    # Determine the output path
    if path is None:
        # Try to read from config
        config_output_path = read_output_path_from_config(config)
        path = Path(config_output_path) if config_output_path else Path("experiment/output")

    # Validate path
    if not validate_path(path):
        console.print(f"❌ [red]Error: Path does not exist or is not a directory:[/red] {path}")
        console.print("\n   Check the path and try again.")
        raise click.Abort()

    # Parse date filters
    before_date = None
    after_date = None
    try:
        if before:
            before_date = datetime.strptime(before, "%Y-%m-%d")
        if after:
            after_date = datetime.strptime(after, "%Y-%m-%d")
    except ValueError as e:
        console.print(f"❌ [red]Error: Invalid date format:[/red] {e}")
        console.print("   Use YYYY-MM-DD format (e.g., 2025-11-21)")
        raise click.Abort() from e

    # Analyze what would be deleted
    analysis = analyze(
        path,
        keep_last=keep_last,
        before=before_date,
        after=after_date,
        logs_only=logs_only,
    )

    if logs_only:
        logs_folders = analysis["logs_folders"]
        logs_folder_sizes = analysis["logs_folder_sizes"]
        count = analysis["count"]
        total_size = analysis["total_size_formatted"]
        display_folders = logs_folders
        folder_sizes: dict[Path, int] = {}  # Not used in logs-only mode
    else:
        folders = analysis["folders"]
        folder_sizes = analysis["folder_sizes"]
        logs_folders: list[Path] = []  # Not used in normal mode
        logs_folder_sizes: dict[Path, int] = {}
        count = analysis["count"]
        total_size = analysis["total_size_formatted"]
        display_folders = folders

    # Check if there's anything to delete
    if count == 0:
        if logs_only:
            console.print("✅ [green]No logs subdirectories found to clear.[/green]")
        else:
            console.print("✅ [green]No experiment folders found to clear.[/green]")
        return

    # Display what will be deleted
    if preview:
        console.print("\n⚠️  [yellow]PREVIEW - No files will be deleted[/yellow]\n")

    if logs_only:
        console.print(f"[bold]Found {count} logs folder(s) to clear:[/bold]\n")
    else:
        console.print(f"[bold]Found {count} experiment folder(s) to clear:[/bold]\n")

    # Create table
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("Folder Name", style="dim")
    table.add_column("Size", justify="right")

    for folder in display_folders[:10]:  # Show first 10
        folder_size = logs_folder_sizes.get(folder, 0) if logs_only else folder_sizes.get(folder, 0)
        table.add_row(folder.name if not logs_only else f"{folder.parent.name}/logs", format_size(folder_size))

    if count > 10:
        table.add_row("...", f"({count - 10} more)")

    console.print(table)
    console.print(f"\n[bold]Total size:[/bold] {total_size}\n")

    # Handle logs-only mode note
    if logs_only:
        console.print("⚠️  [yellow]Note: --logs-only mode will clear only logs/ subdirectories[/yellow]\n")

    # Confirmation prompt (unless force or preview)
    if not force and not preview and not click.confirm("Do you want to continue?"):
        console.print("⚠️  [yellow]Operation cancelled.[/yellow]")
        raise click.Abort()

    # Perform deletion
    results = delete_folders(logs_folders if logs_only else folders, preview=preview)

    # Display results
    if preview:
        console.print(f"\n✅ [green]Preview complete. Would delete {count} folder(s) ({total_size})[/green]")
    else:
        succeeded = results["succeeded"]
        failed = results["failed"]

        if failed == 0:
            console.print(f"\n✅ [green]Successfully deleted {succeeded} folder(s) ({total_size})[/green]")
        else:
            console.print(f"\n⚠️  [yellow]Deleted {succeeded} folder(s), failed: {failed}[/yellow]")
            if results["errors"]:
                console.print("\n❌ [red]Errors:[/red]")
                for error in results["errors"][:5]:  # Show first 5 errors
                    console.print(f"  • {error['folder']}: {error['error']}")
