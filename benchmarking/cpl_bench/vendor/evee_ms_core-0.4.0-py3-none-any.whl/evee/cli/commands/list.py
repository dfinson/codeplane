"""List command for component discovery.

Uses evee's built-in decorator discovery mechanism to find components.
"""

import json
from pathlib import Path

import click

from evee.logging.logger import get_console

console = get_console()


@click.command("list")
@click.option(
    "--type",
    "component_type",
    type=click.Choice(["all", "models", "metrics", "datasets"]),
    default="all",
    help="Type of components to discover.",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output result as JSON (for MCP integration).",
)
@click.help_option("--help", "-h")
def list_components(component_type: str, output_json: bool):
    """Discover and list project components (models, metrics, datasets).

    Uses evee's decorator discovery to import modules and populate registries.
    """
    # Import discovery and registries
    from evee.core.base_dataset import DATASET_REGISTRY
    from evee.core.base_metric import METRIC_REGISTRY
    from evee.core.base_model import MODEL_REGISTRY
    from evee.core.decorator_discovery import discover_components, import_builtin_datasets

    models = []
    metrics = []
    datasets = []
    discovery_warnings = []

    try:
        # Run evee's built-in discovery mechanism
        import_builtin_datasets()  # Load built-in loaders so they're available
        discover_components(force=True)  # Discover user-defined components

        # Extract models from registry
        if component_type in ["all", "models"]:
            for name, cls in MODEL_REGISTRY.items():
                models.append(
                    {
                        "name": name,
                        "file": _get_module_file(cls),
                        "description": cls.__doc__.split("\n")[0].strip() if cls.__doc__ else f"Model: {name}",
                    }
                )

        # Extract metrics from registry
        if component_type in ["all", "metrics"]:
            for name, cls in METRIC_REGISTRY.items():
                metrics.append(
                    {
                        "name": name,
                        "file": _get_module_file(cls),
                        "description": cls.__doc__.split("\n")[0].strip() if cls.__doc__ else f"Metric: {name}",
                    }
                )

        # Extract custom dataset loaders (user-defined, not built-in evee ones)
        if component_type in ["all", "datasets"]:
            for name, cls in DATASET_REGISTRY.items():
                # Skip built-in evee loaders, only show user-defined custom loaders
                module = getattr(cls, "__module__", "")
                if not module.startswith("evee."):
                    datasets.append(
                        {
                            "name": name,
                            "file": _get_module_file(cls),
                            "description": cls.__doc__.split("\n")[0].strip() if cls.__doc__ else f"Dataset: {name}",
                        }
                    )

            # Also read dataset instance from config.yaml
            cwd = Path.cwd()
            config_file = cwd / "experiment" / "config.yaml"
            if config_file.exists():
                dataset_info = _read_dataset_from_config(config_file)
                if dataset_info:
                    datasets.append(dataset_info)

    except Exception as e:
        discovery_warnings.append(f"Discovery error: {e}")

    result = {
        "models": models,
        "metrics": metrics,
        "datasets": datasets,
    }

    if discovery_warnings:
        result["discovery_warnings"] = discovery_warnings

    if output_json:
        print(json.dumps(result))
    else:
        _print_components(result)


def _get_module_file(cls: type) -> str:
    """Get the file path for a class's module."""
    import inspect

    try:
        return inspect.getfile(cls)
    except (TypeError, OSError):
        return cls.__module__


def _read_dataset_from_config(config_path: Path) -> dict | None:
    """Read dataset configuration from config.yaml.

    Args:
        config_path: Path to config.yaml

    Returns:
        Dataset info dictionary or None if not configured
    """
    try:
        import yaml

        with open(config_path, encoding="utf-8") as f:
            config = yaml.safe_load(f) or {}

        experiment = config.get("experiment", {})
        dataset = experiment.get("dataset")

        if not dataset:
            return None

        name = dataset.get("name", "unknown")
        dataset_type = dataset.get("type", "unknown")
        data_path = dataset.get("args", {}).get("data_path", "")

        return {
            "name": name,
            "file": data_path,
            "description": f"{dataset_type.upper()} dataset",
            "type": dataset_type,
        }
    except Exception:
        return None


def _print_components(result: dict):
    """Print components in a human-readable format."""
    total = len(result["models"]) + len(result["metrics"]) + len(result["datasets"])

    if total == 0:
        console.print("[yellow]No components found.[/yellow]")
        if result.get("discovery_warnings"):
            for warn in result["discovery_warnings"]:
                console.print(f"  [dim]{warn}[/dim]")
        return

    console.print(f"\n[bold]Discovered {total} component(s):[/bold]\n")

    if result["models"]:
        console.print("[cyan]Models:[/cyan]")
        for m in result["models"]:
            console.print(f"  • {m['name']}")
            if m.get("description"):
                console.print(f"    [dim]{m['description']}[/dim]")

    if result["metrics"]:
        console.print("[cyan]Metrics:[/cyan]")
        for m in result["metrics"]:
            console.print(f"  • {m['name']}")
            if m.get("description"):
                console.print(f"    [dim]{m['description']}[/dim]")

    if result["datasets"]:
        console.print("[cyan]Datasets:[/cyan]")
        for d in result["datasets"]:
            console.print(f"  • {d['name']}")
            if d.get("description"):
                console.print(f"    [dim]{d['description']}[/dim]")

    if result.get("discovery_warnings"):
        console.print("\n[yellow]Warnings:[/yellow]")
        for warn in result["discovery_warnings"]:
            console.print(f"  [dim]{warn}[/dim]")
