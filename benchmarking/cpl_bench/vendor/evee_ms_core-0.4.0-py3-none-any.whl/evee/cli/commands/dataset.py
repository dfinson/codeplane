"""Dataset management commands for evee CLI."""

import csv
import json
from pathlib import Path

import click
from rich.console import Console

from ..utils.dataset_operations import (
    copy_dataset,
    create_minimal_sample,
    format_record_preview,
    get_available_dataset_types,
    get_file_size_str,
    get_first_record,
    infer_dataset_type,
    read_dataset_from_config,
    update_dataset_in_config,
    validate_dataset,
)

console = Console()


@click.group()
@click.help_option("--help", "-h")
def dataset():
    """Manage datasets"""
    pass


@dataset.command()
@click.option("--type", "-t", "dataset_type", type=str, help="Dataset format (csv or jsonl) - required for creating sample")
@click.option("--from", "-f", "from_file", type=click.Path(exists=True), help="Path to existing dataset file - required for importing")
@click.option("--name", "-n", required=True, help="Dataset name (as it appears in config.yaml)")
@click.option("--output", "-o", type=click.Path(), default="experiment/data", help="Output directory (default: experiment/data)")
@click.option("--config", "-c", type=click.Path(), default="experiment/config.yaml", help="Path to config.yaml (default: experiment/config.yaml)")
@click.option("--force", "-F", is_flag=True, help="Overwrite existing file and config without prompting")
@click.help_option("--help", "-h")
def add(dataset_type: str | None, from_file: str | None, name: str, output: str, config: str, force: bool):
    """Add or replace the project's dataset.

    Examples:

      # Create minimal sample dataset
      evee dataset add --type jsonl --name my_dataset

      # Import existing data
      evee dataset add --from ~/data.csv --name evaluation_data

      # Overwrite existing dataset
      evee dataset add --from data.jsonl --name my_data --force
    """
    # Validate mutually exclusive options
    if dataset_type and from_file:
        console.print("❌ [red]Error: Cannot specify both --type and --from[/red]")
        console.print("   Use --type to create a sample OR --from to import a file")
        raise click.Abort()

    if not dataset_type and not from_file:
        console.print("❌ [red]Error: Must specify either --type or --from[/red]")
        console.print("   • Use --type to create a minimal sample dataset")
        console.print("   • Use --from to import your existing dataset")
        raise click.Abort()

    output_dir = Path(output)
    config_path = Path(config)

    # Mode A: Create minimal sample
    if dataset_type:
        _create_sample_dataset(dataset_type, name, output_dir, config_path, force)

    # Mode B: Import existing dataset
    elif from_file:
        _import_dataset(Path(from_file), name, output_dir, config_path, force)


def _create_sample_dataset(dataset_type: str, name: str, output_dir: Path, config_path: Path, force: bool):
    """Create a minimal sample dataset."""
    # Validate dataset type
    available_types = get_available_dataset_types()
    if dataset_type not in available_types:
        console.print(f"❌ [red]Error: Unsupported dataset type: {dataset_type}[/red]")
        console.print("\n[bold]Available types:[/bold]")
        for type_name in available_types:
            console.print(f"  • {type_name}")
        raise click.Abort()

    # Determine output file path
    output_file = output_dir / f"sample_dataset.{dataset_type}"

    # Check if file exists
    if output_file.exists() and not force:
        console.print(f"❌ [red]Error: Dataset file already exists:[/red] {output_file}")
        console.print("\n   Use --force to overwrite")
        raise click.Abort()

    # Check if config has different dataset
    if not force:
        existing_dataset = read_dataset_from_config(config_path)
        if existing_dataset and existing_dataset.get("name") != name:
            console.print("❌ [red]Error: Config already has a dataset configured[/red]")
            console.print("\n[bold]Current dataset in config.yaml:[/bold]")
            console.print(f"  • Name: {existing_dataset.get('name')}")
            console.print(f"  • Path: {existing_dataset.get('args', {}).get('data_path')}")
            console.print("\n[bold]You're trying to add:[/bold]")
            console.print(f"  • Name: {name}")
            console.print(f"  • Path: {output_file}")
            console.print("\n[bold]Options:[/bold]")
            console.print("  1. Use --force to replace the existing dataset configuration")
            console.print("  2. Manually update config.yaml if you want different settings")
            raise click.Abort()

    # Create the sample dataset
    try:
        if output_file.exists():
            console.print(f"⚠️  [yellow]Overwriting:[/yellow] {output_file}")

        create_minimal_sample(output_file, dataset_type)
        console.print(f"✅ [green]Created dataset:[/green] {output_file}")

    except Exception as e:
        console.print(f"❌ [red]Error creating dataset:[/red] {e}")
        raise click.Abort() from e

    # Update config.yaml
    success = update_dataset_in_config(config_path, name, dataset_type, str(output_file))

    if success:
        console.print(f"✅ [green]Updated {config_path}[/green]")
        console.print("\n[yellow]⚠️  This is placeholder data for testing only![/yellow]")
        console.print("   Replace it with your own data for real evaluations.")
    else:
        console.print("\n⚠️  [yellow]Warning: Could not update config.yaml[/yellow]")
        console.print(f"\n[bold]Add this to {config_path}:[/bold]")
        _print_config_snippet(name, dataset_type, str(output_file))

    console.print("\n💡 [dim]Next step: evee run[/dim]")


def _import_dataset(source_file: Path, name: str, output_dir: Path, config_path: Path, force: bool):
    """Import an existing dataset file."""
    # Infer dataset type from extension
    try:
        dataset_type = infer_dataset_type(source_file)
    except ValueError:
        available_types = get_available_dataset_types()
        console.print(f"❌ [red]Error: Unsupported file type:[/red] {source_file.suffix}")
        console.print("\n[bold]Supported types:[/bold]")
        for type_name in available_types:
            ext = "jsonl" if type_name == "jsonl" else type_name
            console.print(f"  • {type_name} - .{ext}")
        console.print("\nConvert your file to one of these formats first.")
        raise click.Abort() from None

    # Validate the source file
    console.print("✅ [cyan]Validating dataset format...[/cyan]")
    is_valid, error_msg = validate_dataset(source_file, dataset_type)

    if not is_valid:
        console.print("❌ [red]Error: Failed to validate dataset file[/red]")
        console.print(f"\n[bold]File:[/bold] {source_file}")
        console.print(f"[bold]Error:[/bold] {error_msg}")
        console.print(f"\nPlease ensure your file is a valid {dataset_type.upper()} format.")
        console.print("Check the file and try again.")
        raise click.Abort()

    console.print(f"✅ [green]Dataset is valid![/green] ({dataset_type} format)")

    # Determine output file path
    output_file = output_dir / source_file.name

    # Check if file exists
    if output_file.exists() and not force:
        console.print(f"❌ [red]Error: Dataset file already exists:[/red] {output_file}")
        console.print("\n   Use --force to overwrite")
        raise click.Abort()

    # Check if config has different dataset
    if not force:
        existing_dataset = read_dataset_from_config(config_path)
        if existing_dataset and existing_dataset.get("name") != name:
            console.print("❌ [red]Error: Config already has a dataset configured[/red]")
            console.print("\n[bold]Current dataset in config.yaml:[/bold]")
            console.print(f"  • Name: {existing_dataset.get('name')}")
            console.print(f"  • Path: {existing_dataset.get('args', {}).get('data_path')}")
            console.print("\n[bold]You're trying to add:[/bold]")
            console.print(f"  • Name: {name}")
            console.print(f"  • Path: {output_file}")
            console.print("\n[bold]Options:[/bold]")
            console.print("  1. Use --force to replace the existing dataset configuration")
            console.print("  2. Manually update config.yaml if you want different settings")
            raise click.Abort()

    # Copy the file
    try:
        if output_file.exists():
            console.print(f"⚠️  [yellow]Overwriting:[/yellow] {output_file}")

        copy_dataset(source_file, output_file)
        console.print(f"✅ [green]Imported dataset:[/green] {output_file}")

    except Exception as e:
        console.print(f"❌ [red]Error importing dataset:[/red] {e}")
        raise click.Abort() from e

    # Update config.yaml
    success = update_dataset_in_config(config_path, name, dataset_type, str(output_file))

    if success:
        console.print(f"✅ [green]Updated {config_path}[/green]")
    else:
        console.print("\n⚠️  [yellow]Warning: Could not update config.yaml[/yellow]")
        console.print(f"\n[bold]Add this to {config_path}:[/bold]")
        _print_config_snippet(name, dataset_type, str(output_file))

    console.print("\n💡 [dim]Ready to run: evee run[/dim]")


def _print_config_snippet(name: str, dataset_type: str, data_path: str):
    """Print config.yaml snippet for manual update."""
    console.print("\n  dataset:")
    console.print(f'    name: "{name}"')
    console.print(f'    type: "{dataset_type}"')
    console.print('    version: "1.0.0"')
    console.print("    args:")
    console.print(f'      data_path: "{data_path}"')


@dataset.command()
@click.option("--config", "-c", type=click.Path(), default="experiment/config.yaml", help="Path to config.yaml (default: experiment/config.yaml)")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed information")
@click.help_option("--help", "-h")
def show(config: str, verbose: bool):
    """Show information about the current dataset.

    Examples:

      # Show basic dataset info
      evee dataset show

      # Show detailed info with sample records
      evee dataset show --verbose
    """
    config_path = Path(config)

    # Check if config exists
    if not config_path.exists():
        console.print("❌ [red]Error: Config file not found[/red]")
        console.print(f"\n   Looking for: {config_path}")
        console.print("\n   Create a config file or specify path with --config")
        raise click.Abort()

    # Read dataset config
    dataset_config = read_dataset_from_config(config_path)

    if not dataset_config:
        console.print(f"⚠️  [yellow]No dataset configured in {config_path}[/yellow]")
        console.print("\n[bold]Create a dataset with:[/bold]")
        console.print("  evee dataset add --type jsonl --name my_dataset    (create sample)")
        console.print("  evee dataset add --from <file> --name my_dataset   (import your data)")
        return

    # Display dataset configuration
    console.print(f"\n[bold]Current dataset (from {config_path}):[/bold]\n")

    name = dataset_config.get("name", "Unknown")
    dataset_type = dataset_config.get("type", "Unknown")
    version = dataset_config.get("version", "Unknown")
    data_path = dataset_config.get("args", {}).get("data_path", "Unknown")

    console.print(f"  [bold]Name:[/bold] {name}")
    console.print(f"  [bold]Type:[/bold] {dataset_type}")
    console.print(f"  [bold]Version:[/bold] {version}")
    console.print(f"  [bold]Path:[/bold] {data_path}")

    # Check if file exists
    dataset_file = Path(data_path)
    if not dataset_file.exists():
        console.print("\n  [bold]File status:[/bold]")
        console.print(f"  ❌ [red]File not found:[/red] {data_path}")
        console.print("\n💡 [dim]Create this dataset with:[/dim]")
        console.print(f"   evee dataset add --type {dataset_type} --name {name}")
        return

    # Validate and get info
    is_valid, error_msg = validate_dataset(dataset_file, dataset_type)

    console.print("\n  [bold]File info:[/bold]")
    if is_valid:
        # Try to get record count from the dataset
        try:
            from evee.core.decorator_discovery import import_builtin_datasets
            from evee.datasets.dataset_factory import DatasetFactory

            import_builtin_datasets()
            factory = DatasetFactory()
            ds = factory.create_dataset(dataset_type=dataset_type, args={"data_path": str(dataset_file)})
            record_count = len(ds)
        except (ImportError, ValueError, OSError, KeyError) as e:
            if verbose:
                console.print(f"  [dim]Note: Could not count records: {e}[/dim]")
            record_count = 0

        console.print(f"  • Records: {record_count}")
        console.print(f"  • Size: {get_file_size_str(dataset_file)}")
        console.print("  • Status: ✅ Valid")

        # Show first record
        first_record = get_first_record(dataset_file, dataset_type)
        if first_record:
            console.print("\n  [bold]First record:[/bold]")
            console.print(f"    {format_record_preview(first_record)}")

        # Show more details in verbose mode
        if verbose and record_count > 1 and first_record:
            console.print(f"\n  [bold]Fields detected:[/bold] {', '.join(first_record.keys())}")

            # Try to show first 3 records
            console.print("\n  [bold]Sample records:[/bold]")
            try:
                if dataset_type == "jsonl":
                    with open(dataset_file, encoding="utf-8") as f:
                        for i, line in enumerate(f, 1):
                            if i > 3:
                                break
                            record = json.loads(line.strip())
                            console.print(f"    {i}. {format_record_preview(record)}")
                elif dataset_type == "csv":
                    with open(dataset_file, encoding="utf-8") as f:
                        reader = csv.DictReader(f)
                        for i, row in enumerate(reader, 1):
                            if i > 3:
                                break
                            console.print(f"    {i}. {format_record_preview(dict(row))}")
            except (OSError, json.JSONDecodeError, UnicodeDecodeError, csv.Error) as e:
                console.print(f"  [dim]Could not display sample records: {e}[/dim]")

    else:
        console.print("  • Status: ❌ Invalid format")
        console.print(f"  • Error: {error_msg}")
        console.print("\n💡 [dim]Fix the file or replace with:[/dim]")
        console.print(f"   evee dataset add --from <valid-file> --name {name}")
