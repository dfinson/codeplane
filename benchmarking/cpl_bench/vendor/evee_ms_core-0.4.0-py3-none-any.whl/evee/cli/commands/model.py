"""Model management commands for evee CLI."""

from pathlib import Path

import click
from rich.console import Console

from evee.cli.constants import DEFAULT_CONFIG_FILE, DEFAULT_MODELS_DIR
from evee.cli.utils.config_manager import ConfigManager
from evee.cli.utils.model_operations import (
    create_new_model_files,
    model_exists,
    read_models_from_config,
    update_model_in_config,
)

console = Console()

MODEL_LLM_PLACEHOLDER = ["Specify your LLM configurations here", "e.g. connection name"]


@click.group()
@click.help_option("--help", "-h")
def model():
    """Manage models."""
    pass


@model.command()
@click.option(
    "--config",
    "-c",
    default=DEFAULT_CONFIG_FILE,
    help=f"Path to config file (optional default: {DEFAULT_CONFIG_FILE})",
    type=click.Path(),
)
@click.option(
    "--force",
    "-F",
    is_flag=True,
    help="Overwrite existing model configuration and files.",
)
@click.option(
    "--name",
    "-n",
    default=None,
    help="Name for the model (optional, defaults to 'baseline').",
)
@click.help_option("--help", "-h")
def add(config, force: bool, name: str | None):
    """Add or replace a model in the evee project.

    Creates a boilerplate model implementation file and adds the model
    to your configuration.

    Examples:

      evee model add                        # Create model (prompts for name)
      evee model add --name my_model        # Create a named model
    """
    config_path = Path(config)
    if not config_path.exists():
        console.print(f"❌ [red]Error: Config file not found:[/red] {config_path}")
        console.print("\n💡 [dim]Make sure you're in the project directory or use --config to specify the path[/dim]")
        raise click.Abort()

    console.print("Scaffolding model.", style="green")

    if not name:
        name = click.prompt("Enter a name for the model (default: 'baseline')", default="baseline")

    _create_model(model_name=name, config_file=config_path, force=force)


def _create_model(
    model_name: str,
    config_file: Path = Path(DEFAULT_CONFIG_FILE),
    *,
    force: bool = False,
):
    """Create model configuration and files."""
    console.print("Creating model configuration...", style="blue")

    manager = ConfigManager(config_file)
    if manager.read() is None:
        raise click.ClickException(f"Unable to read configuration file: {config_file}")

    base_path = Path(DEFAULT_MODELS_DIR)
    exists_in_config, files_exist = _validate_model_targets(manager, model_name, base_path, force)

    if force and (exists_in_config or files_exist):
        console.print(f"Model '{model_name}' already exists. Overwriting model due to --force flag.", style="yellow")

    # Set up files
    try:
        model_folder = base_path / model_name
        files_existed = model_folder.exists()

        create_new_model_files(model_name=model_name, base_path=base_path, overwrite=force)

        if files_existed:
            console.print(f"✅ [green]Model files overwritten for '{model_name}'[/green]")
        else:
            console.print(f"✅ [green]Model files created for '{model_name}'[/green]")
    except Exception as e:
        console.print(f"❌ [red]Error: Failed to create model files:[/red] {e}")
        raise click.Abort() from None

    # Add/update model in config
    llm_values = MODEL_LLM_PLACEHOLDER

    result = update_model_in_config(
        config_path=config_file,
        name=model_name,
        args=[{"llm": llm_values}],
        entry_point=None,
    )

    if not result:
        console.print("\n⚠️  [yellow]Warning: Could not update config.yaml[/yellow]")
        _print_model_config_snippet(model_name)
        return

    console.print(f"✅ [green]Model configuration added to {config_file}[/green]")

    console.print("\n💡 [dim]Next steps:[/dim]")
    console.print("   1. Update the YAML to configure your LLM")
    console.print("   2. Run your experiment with: evee run")


def _print_model_config_snippet(model_name: str) -> None:
    """Display a YAML snippet users can copy into their config."""
    console.print("\n[bold]Add this to your config manually:[/bold]")
    console.print("  models:")
    console.print(f'    - name: "{model_name}"')
    console.print("      args:")
    console.print("        - llm:")
    for value in MODEL_LLM_PLACEHOLDER:
        console.print(f'            - "{value}"')


def _validate_model_targets(manager: ConfigManager, model_name: str, base_path: Path, force: bool) -> tuple[bool, bool]:
    """Ensure configuration and filesystem targets allow creation."""
    exists_in_config = model_exists(manager, model_name)
    model_folder = base_path / model_name
    files_exist = model_folder.exists()

    if not force:
        if exists_in_config:
            console.print(f"❌ [red]Error: Model '{model_name}' already exists in config[/red]")
            console.print("\n   Use --force to overwrite")
            raise click.Abort()
        if files_exist:
            console.print(f"❌ [red]Error: Model files for '{model_name}' already exist[/red]")
            console.print("\n   Use --force to overwrite")
            raise click.Abort()

    return exists_in_config, files_exist


@model.command()
@click.option("--config", "-c", default=DEFAULT_CONFIG_FILE, help=f"Path to config file (optional default: {DEFAULT_CONFIG_FILE})", type=click.Path())
@click.option("--verbose", "-v", is_flag=True, help="Show detailed model information.")
@click.help_option("--help", "-h")
def list(config: str, verbose: bool):
    """List all models configured in your project."""
    config_path = Path(config)

    # Check if config exists
    if not config_path.exists():
        console.print(f"❌ [red]Error: Config file not found:[/red] {config_path}")
        console.print("\n💡 [dim]Make sure you're in the project directory or use --config to specify the path[/dim]")
        raise click.Abort()

    # Read models from config
    models = read_models_from_config(config_path)

    if not models:
        console.print("\n[yellow]No models configured in your project.[/yellow]")
        console.print("\n💡 [dim]Add a model with:[/dim]")
        console.print("   evee model add --name my_model")
        return

    console.print(f"\n[bold cyan]Configured Models ({len(models)}):[/bold cyan]\n")

    for i, model_config in enumerate(models, start=1):
        name = model_config.get("name", "unknown")

        if verbose:
            # Show all config details
            console.print(f"{i}. [green]{name}[/green]")
            for key, value in model_config.items():
                if key != "name":
                    console.print(f"   {key}: {value}")
            console.print()
        else:
            # Show just the model name
            console.print(f"{i}. [green]{name}[/green]")

    if not verbose:
        console.print("\n[dim]💡 Use --verbose to see full configuration details[/dim]")
