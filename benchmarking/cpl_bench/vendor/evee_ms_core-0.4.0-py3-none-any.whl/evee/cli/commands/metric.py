"""Metric management commands for evee CLI."""

from pathlib import Path

import click
from rich.console import Console

from evee.cli.constants import (
    DEFAULT_CONFIG_FILE,
    DEFAULT_METRICS_DIR,
    TEMPLATE_TYPE_EMPTY,
    TEMPLATE_TYPE_FOUNDRY,
)
from evee.cli.utils.init_file_manager import add_import_to_init
from evee.cli.utils.metric_operations import (
    add_metric_to_config,
    format_callable_params_for_template,
    format_init_params,
    get_azure_evaluator_info,
    get_metric_file_path,
    load_azure_evaluators,
    metric_exists_in_config,
    read_metrics_from_config,
    snake_to_pascal,
)
from evee.cli.utils.validators import validate_metric_name

console = Console()


@click.group()
@click.help_option("--help", "-h")
def metric():
    """Manage metrics."""
    pass


@metric.command()
@click.option("--type", "-t", "metric_type", required=True, help="Metric type: 'empty' or 'foundry' (see 'evee metric list-types')")
@click.option("--name", "-n", required=True, help="Metric name (snake_case) or evaluator name for foundry metrics")
@click.option("--output", "-o", type=click.Path(), default=DEFAULT_METRICS_DIR, help=f"Output directory (default: {DEFAULT_METRICS_DIR})")
@click.option("--config", "-c", type=click.Path(), default=DEFAULT_CONFIG_FILE, help=f"Path to config.yaml (default: {DEFAULT_CONFIG_FILE})")
@click.option("--force", "-F", is_flag=True, help="Overwrite existing file without prompting")
@click.help_option("--help", "-h")
def add(
    metric_type: str,
    name: str,
    output: str,
    config: str,
    force: bool,
):
    """Add a new metric to your project.

    Examples:

      # Create an empty metric template
      evee metric add --type empty --name accuracy

      # Create an Azure AI Foundry evaluator metric
      evee metric add --type foundry --name F1ScoreEvaluator

      # See all available foundry evaluator types
      evee metric list-types

      # See configured metrics
      evee metric list
    """
    # Validate metric name
    is_valid, error = validate_metric_name(name)
    if not is_valid:
        console.print(f"❌ [red]Error: Invalid metric name:[/red] {error}")
        console.print("\n[bold]Metric name requirements:[/bold]")
        console.print("  • Start with a letter")
        console.print("  • Contain only letters, numbers, and underscores")
        console.print("  • Not start or end with underscores")
        console.print("  • Be 100 characters or less")
        raise click.Abort()

    metrics_dir = Path(output)
    config_path = Path(config)

    # Validate config file exists
    if not config_path.exists():
        console.print(f"❌ [red]Error: Config file not found:[/red] {config_path}")
        console.print("\n💡 [dim]Make sure you're in the project directory or use --config to specify the path[/dim]")
        raise click.Abort()

    # Determine metric type and create accordingly
    if metric_type == TEMPLATE_TYPE_EMPTY:
        _create_empty_metric(name, metrics_dir, config_path, force)
    elif metric_type == TEMPLATE_TYPE_FOUNDRY:
        # For foundry type, name should be the evaluator name
        _create_azure_metric(name, name, metrics_dir, config_path, force)
    else:
        console.print(f"❌ [red]Error: Unknown metric type:[/red] {metric_type}")
        console.print("\n[bold]Supported types:[/bold]")
        console.print(f"  • {TEMPLATE_TYPE_EMPTY} - Empty metric template")
        console.print(f"  • {TEMPLATE_TYPE_FOUNDRY} - Azure AI Foundry evaluator wrapper")
        console.print("\n💡 [dim]See all available types with:[/dim]")
        console.print("   evee metric list-types")
        raise click.Abort()

    # Prompt to install azure-ai-evaluation if using foundry type
    if metric_type == TEMPLATE_TYPE_FOUNDRY:
        console.print("\n[bold cyan]📦 Dependency Required:[/bold cyan]")
        console.print("   This metric requires the [bold]azure-ai-evaluation[/bold] package.")
        console.print("\n   [dim]Install it with your package manager:[/dim]")
        console.print("   • pip: [yellow]pip install azure-ai-evaluation[/yellow]")
        console.print("   • uv: [yellow]uv add azure-ai-evaluation[/yellow]")
        console.print("   • poetry: [yellow]poetry add azure-ai-evaluation[/yellow]")


def _create_empty_metric(
    name: str,
    metrics_dir: Path,
    config_path: Path,
    force: bool,
):
    """Create an empty metric from template."""
    metric_file = get_metric_file_path(metrics_dir, name)

    # Check if file exists
    if metric_file.exists() and not force:
        console.print(f"❌ [red]Error: Metric file already exists:[/red] {metric_file}")
        console.print("\n   Use --force to overwrite")
        raise click.Abort()

    # Check if metric exists in config
    if not force and metric_exists_in_config(config_path, name):
        console.print(f"❌ [red]Error: Metric '{name}' already exists in config[/red]")
        console.print("\n   Use --force to overwrite")
        raise click.Abort()

    # Create metric file from template
    template_path = Path(__file__).parent.parent / "templates" / "metrics" / "empty_metric.py"
    template_content = template_path.read_text(encoding="utf-8")

    # Replace placeholders
    class_name = snake_to_pascal(name)
    description = f"{class_name} metric"
    metric_content = template_content.format(
        name=name,
        description=description,
        class_name=class_name,
    )

    # Write metric file
    metric_file.parent.mkdir(parents=True, exist_ok=True)
    metric_file.write_text(metric_content, encoding="utf-8")

    console.print(f"✅ [green]Created metric file:[/green] {metric_file}")

    # Update __init__.py
    init_file = metrics_dir / "__init__.py"
    module_name = metric_file.stem  # Get filename without extension (e.g., "accuracy_metric")
    class_name = snake_to_pascal(name)
    if add_import_to_init(init_file, module_name, class_name):
        console.print(f"✅ [green]Updated {init_file}[/green]")

    # Add to config
    mapping = {"response": "model.response"}  # Default mapping as example
    if add_metric_to_config(config_path, name, mapping=mapping):
        console.print(f"✅ [green]Updated {config_path}[/green]")
    else:
        console.print(f"\n⚠️  [yellow]Warning: Could not update {config_path}[/yellow]")
        console.print("\n[bold]Add this to your config manually:[/bold]")
        console.print(f"  - name: {name}")
        console.print("    mapping:")
        console.print('      response: "model.response"')

    console.print("\n[bold yellow]TODO:[/bold yellow]")
    console.print("  1. Update the mapping in config.yaml to match your model output fields")
    console.print("  2. Implement the compute() method in your metric")
    console.print("  3. Implement the aggregate() method in your metric")
    console.print(f"\n💡 [dim]See {metric_file} for implementation details[/dim]")


def _validate_metric_file_and_config(metric_file: Path, config_path: Path, name: str, force: bool):
    """Validate that metric file and config don't already exist (unless force=True)."""
    if metric_file.exists() and not force:
        console.print(f"❌ [red]Error: Metric file already exists:[/red] {metric_file}")
        console.print("\n   Use --force to overwrite")
        raise click.Abort()

    if not force and metric_exists_in_config(config_path, name):
        console.print(f"❌ [red]Error: Metric '{name}' already exists in config[/red]")
        console.print("\n   Use --force to overwrite")
        raise click.Abort()


def _validate_azure_evaluator(evaluator_name: str) -> dict:
    """Validate that the Azure evaluator exists and return its info."""
    evaluator_info = get_azure_evaluator_info(evaluator_name)
    if not evaluator_info:
        console.print(f"❌ [red]Error: Unknown Azure evaluator:[/red] {evaluator_name}")
        console.print("\n💡 [dim]See all available Azure AI evaluators with:[/dim]")
        console.print("   evee metric list-types")
        raise click.Abort()
    return evaluator_info


def _generate_metric_content(name: str, evaluator_name: str, evaluator_info: dict) -> tuple[str, str]:
    """Generate metric file content from template and return content with snake_case name."""
    template_path = Path(__file__).parent.parent / "templates" / "metrics" / "azure_evaluator_metric.py"
    template_content = template_path.read_text(encoding="utf-8")

    # Format init parameters for __init__ method
    init_params, init_params_doc, init_args, complex_params_todo = format_init_params(evaluator_info)

    # Format callable parameters for compute method
    compute_params, compute_params_doc, callable_params_comment, example_call = format_callable_params_for_template(evaluator_info)

    # When name == evaluator_name (Foundry type), use evaluator_name as class_name to preserve casing
    # Otherwise, convert name to PascalCase for custom names
    class_name = evaluator_name if name == evaluator_name else snake_to_pascal(name)
    description = f"{class_name} metric"

    # Convert name to snake_case for decorator (even for foundry types)
    import re

    snake_name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name).lower()

    metric_content = template_content.format(
        name=snake_name,
        description=description,
        class_name=class_name,
        azure_evaluator_class=evaluator_name,
        init_params=init_params,
        init_params_doc=init_params_doc,
        init_args=init_args,
        complex_params_todo=complex_params_todo,
        compute_params=compute_params,
        compute_params_doc=compute_params_doc,
        callable_params_comment=callable_params_comment,
        example_call=example_call,
    )

    return metric_content, snake_name


def _build_config_mapping(evaluator_info: dict) -> dict:
    """Build the config mapping based on evaluator's callable parameters."""
    callable_params = evaluator_info.get("callable_params", [])

    if callable_params:
        # Build mapping based on actual required parameters
        mapping = {}
        for param in callable_params:
            param_name = param["name"]
            # Map to common model/dataset fields based on parameter name
            if param_name == "response":
                mapping["response"] = "model.response"
            elif param_name == "ground_truth":
                mapping["ground_truth"] = "dataset.ground_truth"
            elif param_name == "query":
                mapping["query"] = "dataset.query"
            elif param_name == "context":
                mapping["context"] = "dataset.context"
            else:
                # For unknown parameters, use dataset.{param_name}
                mapping[param_name] = f"dataset.{param_name}"
    else:
        # Fallback: minimal mapping with just response
        mapping = {"response": "model.response"}

    return mapping


def _build_config_kwargs(evaluator_info: dict, mapping: dict) -> dict:
    """Build config kwargs including mapping and simple parameters with defaults."""
    kwargs = {"mapping": mapping}

    for param in evaluator_info.get("parameters", []):
        param_name = param.get("name")
        param_category = param.get("category", "")

        # Skip complex parameters (model_config, credential, azure_ai_project, etc.)
        if param_category in ("model_config", "credential", "complex"):
            continue

        # Add simple parameters with their default values
        if param_category == "simple" and not param.get("required", True):
            default_value = param.get("default")
            if default_value:
                # Convert string default to appropriate type
                param_type = param.get("type", "")
                if param_type == "int":
                    kwargs[param_name] = int(default_value)
                elif param_type == "float":
                    kwargs[param_name] = float(default_value)
                elif param_type == "bool":
                    kwargs[param_name] = default_value.lower() == "true"
                else:
                    kwargs[param_name] = default_value

    return kwargs


def _update_config_file(config_path: Path, snake_name: str, kwargs: dict):
    """Update config file with metric configuration."""
    if add_metric_to_config(config_path, snake_name, **kwargs):
        console.print(f"✅ [green]Updated {config_path}[/green]")
    else:
        console.print(f"\n⚠️  [yellow]Warning: Could not update {config_path}[/yellow]")
        console.print("\n[bold]Add this to your config manually:[/bold]")
        console.print(f"  - name: {snake_name}")
        # Print all simple parameters
        for key, value in kwargs.items():
            if key != "mapping":
                console.print(f"    {key}: {value}")
        console.print("    mapping:")
        console.print('      response: "model.response"')


def _print_next_steps(config_path: Path, metric_file: Path, evaluator_info: dict):
    """Print next steps and configuration instructions."""
    console.print("\n[bold yellow]⚠️  Configuration Required:[/bold yellow]")
    console.print("\n[bold]1. Update config.yaml mapping:[/bold]")
    console.print(f"   The mapping in {config_path} needs to match your data structure.")

    # Show which parameters are required based on callable_params
    callable_params = evaluator_info.get("callable_params", [])
    if callable_params:
        console.print("\n   [bold]This evaluator requires these parameters:[/bold]")
        for param in callable_params:
            param_name = param["name"]
            required = param.get("required", True)
            req_str = "[red]REQUIRED[/red]" if required else "[dim]optional[/dim]"
            console.print(f"   • {param_name} ({req_str})")

    console.print("\n[bold]2. Implement the compute() method:[/bold]")
    console.print(f"   Open {metric_file} and map your data to the evaluator's expected format.")
    console.print("   See the TODO comments in the file for parameter details.")

    console.print("\n[bold]3. Setup Azure AI connection:[/bold]")
    # Check if evaluator needs credential/azure_ai_project
    init_params = evaluator_info.get("parameters", [])
    needs_azure_config = any(p.get("name") in ["credential", "azure_ai_project"] for p in init_params)
    if needs_azure_config:
        console.print("   This evaluator requires Azure AI credentials:")
        console.print("   • Set up your Azure AI project")
        console.print("   • Configure authentication (credential)")
        console.print("   • Provide azure_ai_project details")

    console.print("\n[bold]4. Implement the aggregate() method:[/bold]")
    console.print("   Define how to combine multiple evaluation results.")

    console.print(f"\n💡 [dim]See {metric_file} for implementation details[/dim]")


def _write_metric_file(metric_file: Path, metric_content: str, evaluator_name: str):
    """Write metric file and print success message."""
    metric_file.parent.mkdir(parents=True, exist_ok=True)
    metric_file.write_text(metric_content, encoding="utf-8")

    console.print(f"✅ [green]Created metric file:[/green] {metric_file}")
    console.print(f"   [dim]Using Azure AI evaluator: {evaluator_name}[/dim]")


def _update_init_file(metrics_dir: Path, metric_file: Path, name: str, evaluator_name: str):
    """Update __init__.py with new metric import."""
    init_file = metrics_dir / "__init__.py"
    module_name = metric_file.stem
    class_name = evaluator_name if name == evaluator_name else snake_to_pascal(name)
    if add_import_to_init(init_file, module_name, class_name):
        console.print(f"✅ [green]Updated {init_file}[/green]")


def _create_azure_metric(
    name: str,
    evaluator_name: str,
    metrics_dir: Path,
    config_path: Path,
    force: bool,
):
    """Create an Azure AI evaluator metric from template."""
    evaluator_info = _validate_azure_evaluator(evaluator_name)
    metric_file = get_metric_file_path(metrics_dir, name)
    _validate_metric_file_and_config(metric_file, config_path, name, force)

    metric_content, snake_name = _generate_metric_content(name, evaluator_name, evaluator_info)
    _write_metric_file(metric_file, metric_content, evaluator_name)
    _update_init_file(metrics_dir, metric_file, name, evaluator_name)

    mapping = _build_config_mapping(evaluator_info)
    kwargs = _build_config_kwargs(evaluator_info, mapping)
    _update_config_file(config_path, snake_name, kwargs)
    _print_next_steps(config_path, metric_file, evaluator_info)


@metric.command(name="list-types")
@click.help_option("--help", "-h")
def list_types():
    """List all available metric types and Azure AI evaluators."""
    console.print("\n[bold cyan]Available Metric Types:[/bold cyan]\n")

    # Empty template
    console.print(f"[green]• {TEMPLATE_TYPE_EMPTY}[/green]")
    console.print("  Create a blank metric template for custom implementation")
    console.print(f"  [dim]Example: evee metric add --type {TEMPLATE_TYPE_EMPTY} --name accuracy[/dim]\n")

    # Azure Foundry evaluators
    console.print(f"[green]• {TEMPLATE_TYPE_FOUNDRY}[/green]")
    console.print("  Wrap an Azure AI Foundry evaluator from azure-ai-evaluation package")
    console.print(f"  [dim]Example: evee metric add --type {TEMPLATE_TYPE_FOUNDRY} --name F1ScoreEvaluator[/dim]\n")

    # List all Azure evaluators
    evaluators_data = load_azure_evaluators()
    if evaluators_data:
        console.print(f"[bold cyan]Available Azure AI Foundry Evaluators ({len(evaluators_data)}):[/bold cyan]\n")

        # Display as vertical list
        for name in sorted(evaluators_data.keys()):
            console.print(f"  [yellow]• {name}[/yellow]")

        console.print("\n[dim]💡 Use 'evee metric add --type foundry --name <EvaluatorName>' to create a metric[/dim]")
    else:
        console.print("[yellow]⚠️  No Azure AI evaluators found (azure-ai-evaluation package may not be installed)[/yellow]")


@metric.command(name="list")
@click.option("--config", "-c", type=click.Path(), default=DEFAULT_CONFIG_FILE, help=f"Path to config.yaml (default: {DEFAULT_CONFIG_FILE})")
@click.option("--verbose", "-v", is_flag=True, help="Show detailed information")
@click.help_option("--help", "-h")
def list_metrics(config: str, verbose: bool):
    """List metrics configured in your project."""
    config_path = Path(config)

    # Check if config exists
    if not config_path.exists():
        console.print(f"❌ [red]Error: Config file not found:[/red] {config_path}")
        console.print("\n💡 [dim]Make sure you're in the project directory or use --config to specify the path[/dim]")
        raise click.Abort()

    # Read metrics from config
    metrics = read_metrics_from_config(config_path)

    if not metrics:
        console.print("\n[yellow]No metrics configured in your project.[/yellow]")
        console.print("\n💡 [dim]Add a metric with:[/dim]")
        console.print(f"   evee metric add --type {TEMPLATE_TYPE_EMPTY} --name my_metric")
        console.print(f"   evee metric add --type {TEMPLATE_TYPE_FOUNDRY} --name F1ScoreEvaluator")
        console.print("\n[dim]   See available types with:[/dim]")
        console.print("   evee metric list-types")
        return

    console.print(f"\n[bold cyan]Configured Metrics ({len(metrics)}):[/bold cyan]\n")

    for i, metric_config in enumerate(metrics, 1):
        name = metric_config.get("name", "unknown")

        if verbose:
            # Show all config details
            console.print(f"{i}. [green]{name}[/green]")
            for key, value in metric_config.items():
                if key != "name":
                    console.print(f"   {key}: {value}")
            console.print()
        else:
            # Show just the metric name
            console.print(f"{i}. [green]{name}[/green]")

    if not verbose:
        console.print("\n[dim]💡 Use --verbose to see full configuration details[/dim]")
