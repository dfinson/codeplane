"""Validate command for config file validation."""

import json
import os
import sys

import click
from dotenv import load_dotenv

from evee.logging.logger import get_console

console = get_console()


@click.command("validate")
@click.argument("config_path", default="experiment/config.yaml")
@click.option(
    "--env",
    "-e",
    default=".env",
    help="Path to .env file (default: .env)",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    help="Output result as JSON (for MCP integration).",
)
@click.help_option("--help", "-h")
def validate(config_path: str, env: str, output_json: bool):
    """Validate an experiment configuration file.

    CONFIG_PATH: Path to the config file (default: experiment/config.yaml)

    Performs deep validation which discovers and instantiates models and metrics
    to catch configuration errors like invalid field mappings, missing parameters,
    and registry issues.
    """
    from evee.config import Config

    # Load .env file if it exists (for environment variable substitution in config)
    if env and os.path.isfile(env):
        load_dotenv(dotenv_path=env, override=True)

    # Resolve config path
    if not os.path.isabs(config_path):
        config_path = os.path.abspath(config_path)

    errors = []
    warnings = []

    # Check if file exists
    if not os.path.isfile(config_path):
        errors.append(f"Config file does not exist: {config_path}")
        _output_result(False, errors, warnings, output_json)
        return

    config = None

    # Try to load and validate the config
    try:
        config = Config.from_yaml(config_path)

        # Check for required fields
        if not config.experiment:
            errors.append("Missing 'experiment' section in config")
        else:
            # Check dataset config
            if not config.experiment.dataset:
                warnings.append("No dataset configured")
            elif not config.experiment.dataset.name:
                errors.append("Dataset 'name' is required")

            # Check models
            if not config.experiment.models:
                warnings.append("No models configured")

            # Check metrics
            if not config.experiment.metrics:
                warnings.append("No metrics configured")

            # Check compute backend
            if not config.experiment.compute_backend:
                warnings.append("No compute_backend configured (will use 'local' by default)")

            # Check tracking backend
            if not config.experiment.tracking_backend:
                warnings.append("No tracking_backend configured (will use 'local' by default)")

    except Exception as e:
        errors.append(f"Failed to parse config: {str(e)}")

    # Deep validation: actually instantiate models and metrics
    if config and config.experiment and len(errors) == 0:
        deep_errors, deep_warnings = _deep_validate(config)
        errors.extend(deep_errors)
        warnings.extend(deep_warnings)

    valid = len(errors) == 0
    _output_result(valid, errors, warnings, output_json)


def _deep_validate(config) -> tuple[list[str], list[str]]:
    """Perform deep validation by instantiating models and metrics.

    This catches configuration errors that can only be detected at instantiation time,
    such as invalid metric field mappings or missing required parameters.

    Args:
        config: Loaded Config object

    Returns:
        Tuple of (errors, warnings) lists
    """
    errors = []
    warnings = []

    # Import registries and discovery
    from evee.core.base_metric import METRIC_REGISTRY
    from evee.core.base_model import MODEL_REGISTRY
    from evee.core.decorator_discovery import discover_components, import_builtin_datasets

    # Discover components to populate registries
    try:
        import_builtin_datasets()
        discover_components(force=True)
    except Exception as e:
        warnings.append(f"Component discovery failed: {e}")
        return errors, warnings

    # Build connections registry and execution context from config
    from evee.core.execution_context import ExecutionContext

    connections_registry = {}
    if config.experiment.connections:
        for connection in config.experiment.connections:
            connections_registry[connection.name] = connection

    validation_context = ExecutionContext(connections_registry=connections_registry)

    # Validate models exist in registry
    if config.experiment.models:
        for model_config in config.experiment.models:
            model_name = model_config.name
            if model_name not in MODEL_REGISTRY:
                available = list(MODEL_REGISTRY.keys())
                errors.append(f"Model '{model_name}' not found in registry. Available models: {available}. Ensure the model is decorated with @model(name='{model_name}') and imported.")

    # Validate metrics by attempting instantiation
    if config.experiment.metrics:
        for metric_config in config.experiment.metrics:
            metric_name = metric_config.name
            metric_class = METRIC_REGISTRY.get(metric_name)

            if not metric_class:
                available = list(METRIC_REGISTRY.keys())
                errors.append(f"Metric '{metric_name}' not found in registry. Available metrics: {available}. Ensure the metric is decorated with @metric(name='{metric_name}') and imported.")
                continue

            # Try to instantiate to validate config (mappings, required params, etc.)
            try:
                metric_dict = metric_config.model_dump()
                metric_class(metric_dict, validation_context)
            except ValueError as e:
                # Validation errors from validate_metric_definition
                errors.append(f"Metric '{metric_name}': {e}")
            except Exception as e:
                # Other instantiation errors
                errors.append(f"Metric '{metric_name}' instantiation failed: {e}")

    return errors, warnings


def _output_result(valid: bool, errors: list, warnings: list, output_json: bool):
    """Output the validation result."""
    if output_json:
        result = {
            "valid": valid,
            "errors": errors,
            "warnings": warnings,
        }
        print(json.dumps(result))
    else:
        if valid:
            console.print("[green]✓[/green] Config is valid")
            for warn in warnings:
                console.print(f"  [yellow]⚠[/yellow] {warn}")
        else:
            console.print("[red]✗[/red] Config validation failed")
            for err in errors:
                console.print(f"  [red]•[/red] {err}")
            for warn in warnings:
                console.print(f"  [yellow]⚠[/yellow] {warn}")

        sys.exit(0 if valid else 1)
