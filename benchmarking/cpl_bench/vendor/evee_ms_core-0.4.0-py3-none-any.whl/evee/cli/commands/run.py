"""Run commands for executing experiments."""

import os

import click
from rich.console import Console

from ..utils.constants import EVEE_ASCII
from ..utils.validators import parse_models

console = Console()


def _validate_paths(path, config, dataset, env):
    """Validate that required files exist in the target directory."""
    target_dir = os.path.abspath(path)
    if not os.path.exists(os.path.join(path, config)):
        raise click.ClickException(f"Config file '{config}' not found in working directory: {target_dir}")
    if dataset and not os.path.exists(os.path.join(path, dataset)):
        raise click.ClickException(f"Dataset file '{dataset}' not found in working directory: {target_dir}")
    if env and env != ".env" and not os.path.exists(os.path.join(path, env)):
        raise click.ClickException(f"Env file '{env}' not found in working directory: {target_dir}")


def _execute_runner(config, env, dataset, stream_remote_logs, auto_approve, path, no_tracking=False, **kwargs):
    """Helper to execute the experiment runner with common parameters.

    Returns:
        JobInfo from the experiment runner.

    Raises:
        click.ClickException: If the job fails.
    """
    from evee.cli.main import working_directory

    with working_directory(path):
        # Lazy import
        from ...compute.backend import JobStatus
        from ...execution.experiment_runner import ExperimentRunner

        runner = ExperimentRunner()
        job_info = runner.run(config_path=config, env_path=env, dataset_path=dataset, stream_remote_logs=stream_remote_logs, interactive=not auto_approve, tracking_enabled=not no_tracking, **kwargs)

        if job_info.status == JobStatus.FAILED:
            error_message = job_info.metadata.get("error", "Evaluation failed")
            raise click.ClickException(f"Evaluation failed: {error_message}")

        return job_info


@click.command()
@click.option("--path", "-p", default=".", type=click.Path(exists=True, file_okay=False, dir_okay=True), help="Optional working directory for the experiment.")
@click.option("--auto-approve", "-y", is_flag=True, help="Skip confirmation prompts.")
@click.option("--stream-remote-logs", is_flag=True, default=False, help="Stream logs from remote compute to terminal (only applies with --remote)")
@click.option("--dataset", "-d", required=False, help="Path to dataset file (optional, will be loaded from config if not provided)")
@click.option("--env", "-e", default=".env", help="Path to .env file (default: .env)")
@click.option("--config", "-c", default="experiment/config.yaml", required=False, help="Path to config file")
@click.option("--no-tracking", is_flag=True, help="Disable tracking backend")
@click.option("--remote", "-r", is_flag=True, help="Run on configured compute backend (requires compute_backend in config)")
@click.option("--models", "-m", required=False, help="Comma-separated list of model names to evaluate (e.g., 'model_a,model_b'). If not specified, all models are evaluated.")
@click.help_option("--help", "-h")
def run(config, env, dataset, stream_remote_logs, auto_approve, path, no_tracking, remote, models):
    """Run model evaluation.

    By default, runs locally. Use --remote to run on the configured compute backend.

    Examples:

        evee run                           # Run locally (default)

        evee run --remote                  # Run on configured compute backend

        evee run --config custom.yaml      # Use custom config file

        evee run -p ~/my-project           # Run from specific directory
    """
    from evee.utils.environment import is_mcp_mode

    mcp_mode = is_mcp_mode()
    if not mcp_mode:
        console.print(EVEE_ASCII, style="cyan")

    _validate_paths(path, config, dataset, env)
    model_filter = parse_models(models)
    # Validate that --models flag has valid model names if provided
    if models is not None and model_filter is None:
        raise click.ClickException("Invalid --models value. Please provide at least one valid model name (e.g., --models model_a,model_b).")
    job_info = _execute_runner(
        config,
        env,
        dataset,
        stream_remote_logs,
        auto_approve,
        path,
        no_tracking=no_tracking,
        remote_compute=remote,
        model_filter=model_filter,
    )

    # In MCP mode, output structured JSON to stdout for programmatic consumption
    if mcp_mode:
        import json
        import sys

        summary = {
            "status": job_info.metadata.get("status", "completed"),
            "output_path": job_info.metadata.get("output_path", ""),
            "total_records": job_info.metadata.get("total_records", 0),
            "failed_records": job_info.metadata.get("failed_records", 0),
            "models_evaluated": job_info.metadata.get("models_evaluated", 0),
        }
        sys.stdout.write(json.dumps(summary) + "\n")
