"""Command for creating new projects from templates."""

import re
import tomllib
from importlib.metadata import version
from importlib.resources import files
from pathlib import Path

import click
from rich.console import Console

from ..utils.new_project_operations import (
    copy_and_render_template,
    validate_description,
    validate_project_name,
)

console = Console()

_RELEASE_RE = re.compile(r"^v?(\d+\.\d+\.\d+)$")

_GIT_BASE = "git+https://github.com/microsoft/evee.git"


def _resolve_evee_version() -> str | None:
    """
    Resolve and validate the evee version to use.

    Returns:
        Version string (X.Y.Z format, no 'v' prefix), or None if dev version
    """
    installed_version = version("evee-ms-core")

    m = _RELEASE_RE.match(installed_version)
    if not m:
        return None

    return m.group(1)


def _backend_dep_from_source(backend: str, source_path: Path) -> dict[str, str]:
    """Generate dependency strings for backend packages from local source.

    All backends use [tool.uv.sources] format for consistency and to support
    remote execution (which uses --no-sources to ignore local paths).
    """
    deps = {
        "evee_core_dependency": "evee-ms-core",
        "evee_core_source": f'evee-ms-core = {{ path = "{source_path.resolve()}" }}',
    }

    if backend == "mlflow":
        pkg_path = source_path / "packages" / "evee-mlflow"
        if pkg_path.exists():
            deps["evee_mlflow_dependency"] = "evee-ms-mlflow"
            deps["evee_mlflow_source"] = f'evee-ms-mlflow = {{ path = "{pkg_path.resolve()}" }}'
        else:
            deps["evee_mlflow_dependency"] = "# evee-ms-mlflow not found in source checkout"
            deps["evee_mlflow_source"] = "# evee-ms-mlflow not found"
    elif backend == "azureml":
        pkg_path = source_path / "packages" / "evee-azureml"
        if pkg_path.exists():
            deps["evee_azureml_dependency"] = "evee-ms-azureml"
            deps["evee_azureml_source"] = f'evee-ms-azureml = {{ path = "{pkg_path.resolve()}" }}'
        else:
            deps["evee_azureml_dependency"] = "# evee-ms-azureml not found in source checkout"
            deps["evee_azureml_source"] = "# evee-ms-azureml not found"

    return deps


def _backend_dep_from_git(backend: str, ver: str) -> dict[str, str]:
    """Generate dependency strings for backend packages from git.

    All backends use [tool.uv.sources] format for consistency. Remote execution
    uses --no-sources to ignore git URLs and --find-links to use local wheels.
    """
    repo_url = "https://github.com/microsoft/evee.git"
    tag = f"v{ver}"

    deps = {
        "evee_core_dependency": f"evee-ms-core>={ver}",
        "evee_core_source": f'evee-ms-core = {{ git = "{repo_url}", tag = "{tag}" }}',
    }

    if backend == "mlflow":
        deps["evee_mlflow_dependency"] = f"evee-ms-mlflow>={ver}"
        deps["evee_mlflow_source"] = f'evee-ms-mlflow = {{ git = "{repo_url}", tag = "{tag}", subdirectory = "packages/evee-mlflow" }}'
    elif backend == "azureml":
        deps["evee_azureml_dependency"] = f"evee-ms-azureml>={ver}"
        deps["evee_azureml_source"] = f'evee-ms-azureml = {{ git = "{repo_url}", tag = "{tag}", subdirectory = "packages/evee-azureml" }}'

    return deps


def _get_python_requires() -> str:
    """
    Get the Python version requirement from evee's package metadata.

    Returns:
        Python version constraint string (e.g., ">=3.12,<3.14")
        Falls back to ">=3.12" if unable to retrieve.
    """
    try:
        from importlib.metadata import metadata

        # Get the requires-python from installed package metadata
        evee_metadata = metadata("evee-ms-core")
        python_requires = evee_metadata.get("Requires-Python")

        if python_requires:
            return python_requires

        # If not in metadata, try reading from source pyproject.toml (development mode)
        evee_package_dir = Path(__file__).parent.parent.parent.parent
        pyproject_path = evee_package_dir / "pyproject.toml"

        if pyproject_path.exists():
            with open(pyproject_path, "rb") as f:
                pyproject_data = tomllib.load(f)
            return pyproject_data.get("project", {}).get("requires-python", ">=3.12")

        return ">=3.12,<3.14"
    except Exception:
        # Fallback if anything goes wrong
        return ">=3.12,<3.14"


@click.command(name="new")
@click.argument("name", required=False)
@click.option("--description", "-d", help="Project description", default="Model evaluation experiment")
@click.option("--output", "-o", default=".", help="Output directory (default: current directory)")
@click.option(
    "--backend",
    "-b",
    type=click.Choice(["core", "mlflow", "azureml"]),
    default="core",
    help="Project backend (default: core)",
)
@click.option(
    "--from-source",
    "-s",
    type=click.Path(exists=True),
    help="[Advanced] Use local source checkout (may cause unexpected behavior)",
)
@click.option("--force", "-f", is_flag=True, help="Overwrite if project already exists")
@click.help_option("--help", "-h")
def new_project(
    name: str | None,
    description: str,
    output: str,
    backend: str,
    from_source: str | None,
    force: bool,
):
    """
    Create a new evaluation project.

    NAME: Name of the new project

    \b
    Source Selection:
      (default)           Use installed evee version (must be a release X.Y.Z)
      --from-source PATH  [Advanced] Use local source checkout

    ⚠️  --from-source is primarily for development and advanced users.
    It may cause unexpected behavior - use with caution.

    Examples:

        evee new my-qa-project

        evee new my-test --from-source /path/to/evee

        evee new my-test -o /path/to/projects -f
    """

    if not name:
        name = click.prompt("Project name", type=str)

    is_valid, error_msg = validate_project_name(name)
    if not is_valid:
        console.print(f"[red]Error: {error_msg}[/red]")
        raise click.Abort()

    # Defensive: validator does this too, but be explicit
    name = name.strip()

    is_valid, error_msg = validate_description(description)
    if not is_valid:
        console.print(f"[red]Error: {error_msg}[/red]")
        raise click.Abort()

    # Locate template directories (base + backend overlay)
    evee_package_dir = Path(__file__).parent.parent

    # Try development mode first (running from repo)
    dev_base_dir = evee_package_dir / "templates" / "base"
    dev_overlay_dir = evee_package_dir / "templates" / "overlays" / backend

    if dev_base_dir.exists() and dev_overlay_dir.exists():
        template_dirs = [dev_base_dir, dev_overlay_dir]
    else:
        # Fall back to installed package resources
        try:
            # Convert to Path - works with both Path-like and Traversable objects
            base_dir = Path(str(files("evee").joinpath("cli/templates/base")))
            overlay_dir = Path(str(files("evee").joinpath(f"cli/templates/overlays/{backend}")))
            if not base_dir.exists() or not overlay_dir.exists():
                raise FileNotFoundError("Template directories not found")
            template_dirs = [base_dir, overlay_dir]
        except Exception:
            console.print(f"[red]Error: Template directories for backend '{backend}' not found[/red]")
            raise click.Abort() from None

    output_path = Path(output).resolve()
    project_path = output_path / name

    try:
        output_path.mkdir(parents=True, exist_ok=True)

        if project_path.exists() and not force:
            console.print(f"[yellow]Warning: Directory '{project_path}' already exists.[/yellow]")
            if not click.confirm("Do you want to overwrite it?", default=False):
                raise click.Abort()

        console.print(f"[cyan]Creating project '{name}'...[/cyan]")

        if from_source:
            source_path = Path(from_source).resolve()
            deps = _backend_dep_from_source(backend, source_path)
            evee_version = None
        else:
            evee_version = _resolve_evee_version()
            if evee_version:
                deps = _backend_dep_from_git(backend, evee_version)
            else:
                console.print("[yellow]Warning: Running a dev version of evee. The scaffolded project will need --from-source or a released version to sync.[/yellow]")
                # Use placeholder deps that won't resolve - user must fix
                deps = {
                    "evee_core_dependency": "# TODO: Install evee-ms-core (use --from-source or wait for release)",
                    "evee_core_source": "# TODO: Add evee-ms-core source",
                }
                if backend == "mlflow":
                    deps["evee_mlflow_dependency"] = "# TODO: Install evee-ms-mlflow"
                    deps["evee_mlflow_source"] = "# TODO: Add evee-ms-mlflow source"
                elif backend == "azureml":
                    deps["evee_azureml_dependency"] = "# TODO: Install evee-ms-azureml"
                    deps["evee_azureml_source"] = "# TODO: Add evee-ms-azureml source"

        replacements = {
            "{project_name}": name,
            "{description}": description,
            "{python_requires}": _get_python_requires(),
            **{f"{{{k}}}": v for k, v in deps.items()},
        }

        copy_and_render_template(
            template_dirs=template_dirs,
            output_dir=project_path,
            replacements=replacements,
        )

        console.print(f"\n[green]✓ Project '{name}' created successfully![/green]")
        console.print(f"[dim]Location:[/dim] {project_path}")

        console.print("\n[bold]Next steps:[/bold]")
        console.print(f"  1. cd {project_path}")
        console.print("  2. Copy .env.sample to .env and edit with your Azure credentials:")
        console.print("     [cyan]cp .env.sample .env[/cyan]")

        step = 3

        if evee_version:
            console.print(f"  {step}. Authenticate with GitHub (required for private repository):")
            console.print("     [cyan]gh auth login[/cyan]")
            step += 1

        console.print(f"  {step}. Install dependencies:")
        console.print("     [cyan]uv sync[/cyan]")
        console.print(f"  {step + 1}. Run your evaluation:")
        console.print("     [cyan]evee run --config experiment/config.yaml --env .env[/cyan]")

    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled.[/yellow]")
        raise click.Abort() from None
    except Exception as e:
        console.print(f"[red]Error creating project: {e}[/red]")
        raise click.Abort() from e
