"""View command for viewing experiment results in a browser."""

import asyncio
import http.server
import json
import os
import signal
import socketserver
import threading
import webbrowser
from pathlib import Path

import click
from rich.console import Console

console = Console()

DEFAULT_OUTPUT_DIR = "experiment/output"


def _get_app_html() -> str:
    """Get the built results viewer app HTML."""
    app_path = Path(__file__).parent.parent.parent / "ui" / "results-viewer" / "dist" / "index.html"
    if not app_path.exists():
        raise click.ClickException(f"Results viewer app not built. Run:\n  cd {app_path.parent.parent}\n  npm install\n  npm run build")
    return app_path.read_text()


def _json_for_script_tag(data: object) -> str:
    """Serialize data to JSON safe for embedding in a <script> tag.

    Escapes '</'' sequences to prevent premature tag closure (XSS).
    """
    return json.dumps(data).replace("</", "<\\/")


def _inject_results_into_html(html: str, results_data: dict, output_dir: str) -> str:
    """Inject results data and output directory into the HTML as a script tag."""
    script = f"""
    <script>
        window.__EVEE_RESULTS_DATA__ = {_json_for_script_tag(results_data)};
        window.__EVEE_OUTPUT_DIR__ = {_json_for_script_tag(output_dir)};
    </script>
    """
    return html.replace("</head>", f"{script}</head>")


def _find_experiment_dirs(output_dir: str) -> list[Path]:
    """Find experiment output directories that contain results files."""
    output_path = Path(output_dir)
    if not output_path.is_dir():
        return []

    experiments = []
    for child in sorted(output_path.iterdir(), reverse=True):
        if not child.is_dir():
            continue
        # Check if directory contains results files (directly or in artifacts/)
        has_results = list(child.glob("*_results.json")) or (list((child / "artifacts").glob("*_results.json")) if (child / "artifacts").is_dir() else [])
        if has_results:
            experiments.append(child)

    return experiments


def _load_results_sync(output_path: str) -> dict:
    """Load results for a given output path."""
    from evee.mcp.tools.view_results import ViewResultsTool

    async def _load():
        tool = ViewResultsTool()
        result = await tool.execute({"output_path": output_path})
        return result.to_dict()

    return asyncio.run(_load())


class ResultsRequestHandler(http.server.SimpleHTTPRequestHandler):
    """Custom request handler that serves the results viewer and API endpoints."""

    results_html = None
    output_dir = None

    def do_GET(self):
        """Serve the results viewer HTML or API responses."""
        if self.path == "/" or self.path == "/index.html":
            self._serve_html()
        elif self.path == "/api/experiments":
            self._serve_experiments_list()
        elif self.path.startswith("/api/results/"):
            self._serve_experiment_results()
        else:
            self.send_error(404, "File not found")

    def _serve_html(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(self.results_html.encode())

    def _serve_experiments_list(self):
        """Return list of available experiments in the output directory."""
        experiments = _find_experiment_dirs(self.output_dir)
        data = [{"name": exp.name, "path": str(exp)} for exp in experiments]
        self._send_json(data)

    def _serve_experiment_results(self):
        """Load and return results for a specific experiment."""
        # Extract experiment name from URL path, validate it's a simple name
        experiment_name = self.path[len("/api/results/") :]
        experiment_name = experiment_name.strip("/")

        # Security: only allow simple directory names (no path traversal)
        if not experiment_name or "/" in experiment_name or "\\" in experiment_name or ".." in experiment_name:
            self._send_json({"error": "Invalid experiment name"}, status=400)
            return

        # Look up the experiment from the trusted directory listing
        # instead of constructing a path from user input
        experiments = _find_experiment_dirs(self.output_dir)
        matched = next((exp for exp in experiments if exp.name == experiment_name), None)
        if matched is None:
            self._send_json({"error": "Experiment not found"}, status=404)
            return

        try:
            results_data = _load_results_sync(str(matched))
            if "error" in results_data:
                self._send_json(results_data, status=500)
            else:
                self._send_json(results_data)
        except Exception as e:
            self._send_json({"error": str(e)}, status=500)

    def _send_json(self, data: dict | list, status: int = 200):
        self.send_response(status)
        self.send_header("Content-type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def log_message(self, format, *args):
        """Suppress request logs."""
        pass


@click.command()
@click.argument("output_path", required=False, default=None, type=click.Path())
@click.option("--port", "-p", default=8765, help="Port to serve on (default: 8765)")
@click.option("--no-browser", is_flag=True, help="Don't automatically open browser")
def view(output_path: str | None, port: int, no_browser: bool):
    """View experiment results in your browser.

    Opens an interactive results viewer showing metrics across all models.
    If no OUTPUT_PATH is given, scans the default output directory and
    auto-selects the most recent experiment.

    \b
    Examples:
        evee view
        evee view experiment/output/my_exp_v1.0__2026-01-29_12-00-00
    """
    # Resolve output directory for experiment switching in browser
    output_dir = DEFAULT_OUTPUT_DIR

    # If no path provided, scan for experiments and let user pick
    if output_path is None:
        if not os.path.isdir(output_dir):
            raise click.ClickException(f"No output directory found at '{output_dir}'.\nRun an experiment first with 'evee run', or specify a path: evee view <path>")

        experiments = _find_experiment_dirs(output_dir)
        if not experiments:
            raise click.ClickException(f"No experiment results found in '{output_dir}'.\nRun an experiment first with 'evee run'.")

        # Auto-select the most recent experiment (list is sorted newest-first)
        output_path = str(experiments[0])
    elif not os.path.exists(output_path):
        raise click.ClickException(f"Path does not exist: {output_path}")
    else:
        # Derive output_dir from the given path (parent directory)
        output_dir = str(Path(output_path).parent)

    console.print(f"[cyan]Loading results from:[/cyan] {output_path}")

    try:
        results_data = _load_results_sync(output_path)
    except Exception as e:
        raise click.ClickException(f"Failed to load results: {e}") from e

    if "error" in results_data:
        error = results_data.get("error", {})
        msg = error.get("message", "Unknown error")
        suggestion = error.get("suggestion", "")
        raise click.ClickException(f"{msg}\n{suggestion}" if suggestion else msg)

    html = _get_app_html()
    html = _inject_results_into_html(html, results_data, output_dir)
    ResultsRequestHandler.results_html = html
    ResultsRequestHandler.output_dir = output_dir

    try:
        with socketserver.TCPServer(("127.0.0.1", port), ResultsRequestHandler) as httpd:
            url = f"http://localhost:{port}"
            console.print(f"\n[green]✓[/green] Results viewer running at: [cyan]{url}[/cyan]")
            console.print("[dim]Press Ctrl+C to stop[/dim]\n")

            if not no_browser:
                threading.Timer(0.5, lambda: webbrowser.open(url)).start()

            # Handle Ctrl+C gracefully
            def _shutdown(_sig, _frame):
                console.print("\n[yellow]Stopping server...[/yellow]")
                threading.Thread(target=httpd.shutdown).start()

            signal.signal(signal.SIGINT, _shutdown)
            httpd.serve_forever()
    except OSError as e:
        if "Address already in use" in str(e):
            raise click.ClickException(f"Port {port} is already in use. Try a different port with --port") from e
        raise
