"""Template used to scaffold base model."""

TEMPLATE = '''from typing import Any

from evee import ExecutionContext, model, setup_logger


@model(name="${name}")
class ${class_name}:
    """
    ${description}
    """

    def __init__(self, context: ExecutionContext) -> None:
        """Initialize the model with execution context."""
        self.logger = setup_logger(self.__class__.__module__)
        self.context = context
        # TODO: Pull out any dependencies you need, e.g.:
        # connection = context.connections_registry["MODEL_CONNECTION_NAME"]
        # self.client = build_client(**connection)

    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        """Run a single inference on an input record and return structured output."""
        # TODO: Replace with your model invocation.
        # response = self.client.generate(input["query"])
        # return {"response": response.text, "tokens_used": response.tokens}
        raise NotImplementedError("Implement infer() to call your model backend.")
    '''

__all__ = ["TEMPLATE"]
