from typing import Any

from azure.ai.evaluation import {azure_evaluator_class}

from evee import metric, setup_logger


@metric(name="{name}")
class {class_name}:
    """
    Wrapper for Azure AI {azure_evaluator_class}.
    {description}
    """

    def __init__(self{init_params}) -> None:
        """
        Initialize the metric.
{init_params_doc}
        """
        self.logger = setup_logger(self.__class__.__module__)
{complex_params_todo}
        self.evaluator = {azure_evaluator_class}({init_args})

    def compute(self{compute_params}) -> Any:
        """
        Compute the metric using Azure AI evaluator.

        Args:
{compute_params_doc}

        Returns:
            The computed metric value from Azure AI evaluator
        """
        # TODO: Call the evaluator with the provided parameters
        # Example implementation:
        {example_call}
        raise NotImplementedError("Evaluator call not implemented. See TODO comment above.")

    def aggregate(self, results: list[Any]) -> Any:
        """
        Aggregate metric results across multiple evaluations.

        Args:
            results: List of individual metric results

        Returns:
            Aggregated metric value
        """
        # TODO: Implement aggregation logic
        # Example: return sum(results) / len(results)
        raise NotImplementedError("Aggregation not implemented.")
