from numbers import Number
from typing import Any

from evee import metric, setup_logger


@metric(name="{name}")
class {class_name}:
    """
    {description}
    """

    def __init__(self) -> None:
        """Initialize the metric."""
        self.logger = setup_logger(self.__class__.__module__)

    def compute(self, response: Any) -> dict[str, Any]:
        """
        Compute the metric for a single data point.

        Args:
            response: The response field mapped from model output

        Returns:
            Dictionary with metric results for this data point
        """
        # TODO: Implement your metric calculation logic here
        # The 'response' parameter is mapped from your model output in config.yaml
        # Update the mapping in config.yaml to match your actual model output fields
        raise NotImplementedError("Metric computation not implemented")

    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, Number]:
        """
        Aggregate metric scores across all data points.

        Args:
            scores: List of score dictionaries from compute() calls

        Returns:
            Dictionary with aggregated metric values (e.g., mean, median, etc.)
        """
        # TODO: Implement aggregation logic here
        # Common aggregations: mean, median, min, max, std, etc.
        raise NotImplementedError("Metric aggregation not implemented")
