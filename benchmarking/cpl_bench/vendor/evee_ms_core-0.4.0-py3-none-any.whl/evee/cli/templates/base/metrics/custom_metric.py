from typing import Any

from evee import metric, setup_logger


@metric(name="custom_metric")
class CustomMetric:
    """Custom evaluation metric."""

    def __init__(self):
        """Initialize the metric."""
        self.logger = setup_logger(self.__class__.__module__)

    def compute(self, response: str, ground_truth: str) -> dict[str, Any]:  # noqa: ARG002
        """Compute metric for a single example.

        Args:
            response: Model response (mapped from model output)
            ground_truth: Ground truth value (mapped from dataset)

        Returns:
            Dictionary with metric values
        """
        # TODO: Implement your metric computation logic
        # Example for exact match:
        # exact_match = 1.0 if response.strip().lower() == ground_truth.strip().lower() else 0.0
        # return {"exact_match": exact_match}

        # Placeholder implementation
        return {"score": 0.75, "match": True}

    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Aggregate scores across all examples.

        Args:
            scores: List of score dictionaries from compute()

        Returns:
            Dictionary with aggregated metrics
        """
        # TODO: Implement aggregation logic
        # Example:
        # total = len(scores)
        # avg_score = sum(s["score"] for s in scores) / total if total > 0 else 0.0
        # return {"average_score": avg_score}

        # Placeholder implementation
        if not scores:
            return {"mean": 0.0}

        avg_score = sum(s.get("score", 0) for s in scores) / len(scores)
        return {"mean": avg_score, "count": len(scores)}
