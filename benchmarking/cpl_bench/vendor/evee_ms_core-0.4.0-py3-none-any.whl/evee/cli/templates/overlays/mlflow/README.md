# {project_name}

{description}

## Quick Start

1. **Configure credentials**

   ```bash
   cp .env.sample .env
   # Edit .env with your Azure OpenAI credentials
   ```

2. **Install dependencies**

   ```bash
   uv sync
   ```

3. **Run experiment locally**

   ```bash
   evee run --config experiment/config.yaml --env .env
   ```

4. **View results in MLflow UI**

   ```bash
   mlflow ui
   # Open http://localhost:5000 in your browser
   ```

## Project Structure

```text
.
├── experiment/
│   ├── config.yaml          # Experiment configuration
│   └── data/                # Your evaluation dataset
├── models/                  # Your model implementations
│   └── baseline.py          # Example baseline model
├── metrics/                 # Your custom metrics
│   └── custom_metric.py     # Example custom metric
├── mlflow.db                # MLflow tracking data (created on first run)
└── .env                     # Credentials (not committed)
```

## Configuration

Edit `experiment/config.yaml` to configure:

- Model parameters and variations
- Evaluation metrics
- Dataset location
- MLflow tracking settings

## Next Steps

1. Add your evaluation data to `experiment/data/`
2. Implement your model in `models/baseline.py`
3. Create custom metrics in `metrics/`
4. Run evaluations with `evee run`
5. View results in MLflow UI
