# {project_name}

{description}

## Quick Start

1. **Configure credentials**

   ```bash
   cp .env.sample .env
   # Edit .env with your Azure OpenAI credentials
   ```

2. **Install dependencies**

   ```bash
   uv sync
   ```

3. **Run experiment locally**

   ```bash
   evee run --config experiment/config.yaml --env .env
   ```

## Project Structure

```text
.
├── experiment/
│   ├── config.yaml          # Experiment configuration
│   └── data/                # Your evaluation dataset
├── models/                  # Your model implementations
│   └── baseline.py          # Example baseline model
├── metrics/                 # Your custom metrics
│   └── custom_metric.py     # Example custom metric
└── .env                     # Credentials (not committed)
```

## Configuration

Edit `experiment/config.yaml` to configure:

- Model parameters and variations
- Evaluation metrics
- Dataset location

## Next Steps

1. Add your evaluation data to `experiment/data/`
2. Implement your model in `models/baseline.py`
3. Create custom metrics in `metrics/`
4. Run evaluations with `evee run`
