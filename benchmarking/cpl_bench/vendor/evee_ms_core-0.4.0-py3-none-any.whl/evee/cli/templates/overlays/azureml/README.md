# {project_name}

{description}

## Quick Start

1. **Configure Azure credentials**

   ```bash
   cp .env.sample .env
   # Edit .env with your Azure OpenAI and Azure ML credentials
   ```

2. **Install dependencies**

   ```bash
   uv sync
   ```

3. **Run experiment locally** (with Azure ML tracking)

   ```bash
   evee run --config experiment/config.yaml --env .env
   ```

4. **Run experiment on Azure ML**

   ```bash
   az login --tenant <your-tenant-id>
   evee run --remote --config experiment/config.yaml --env .env
   ```

## Project Structure

```text
.
├── experiment/
│   ├── config.yaml          # Experiment configuration
│   └── data/                # Your evaluation dataset
├── models/                  # Your model implementations
│   └── baseline.py          # Example baseline model
├── metrics/                 # Your custom metrics
│   └── custom_metric.py     # Example custom metric
├── Dockerfile.aml           # Docker image for Azure ML compute
└── .env                     # Azure credentials (not committed)
```

## Configuration

Edit `experiment/config.yaml` to configure:

- Model parameters and variations
- Evaluation metrics
- Dataset location
- Azure ML workspace and compute settings

## Next Steps

1. Add your evaluation data to `experiment/data/`
2. Implement your model in `models/baseline.py`
3. Create custom metrics in `metrics/`
4. Run evaluations locally with `evee run`
5. Scale to Azure ML with `evee run --remote`
