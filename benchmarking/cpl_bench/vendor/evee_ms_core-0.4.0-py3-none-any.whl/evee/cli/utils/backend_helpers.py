"""Shared utility functions for backend management commands."""

import re
import tomllib
from importlib.metadata import version
from pathlib import Path
from urllib.parse import urlparse

from rich.console import Console

# Regex to match release versions (e.g., "1.2.3" or "v1.2.3")
RELEASE_VERSION_RE = re.compile(r"^v?(\d+\.\d+\.\d+)$")

# Base URL for git-based installs
GIT_BASE_URL = "git+https://github.com/microsoft/evee.git"


def get_evee_version() -> str | None:
    """Get current evee version if it's a release version.

    Returns:
        Version string (e.g., "1.2.3") if a release version is installed,
        None if running a dev version or version cannot be determined.
    """
    try:
        installed_version = version("evee-ms-core")
        m = RELEASE_VERSION_RE.match(installed_version)
        return m.group(1) if m else None
    except Exception:
        # Cannot determine version - likely running from source or not installed
        return None


def get_local_source_path(config_path: Path) -> Path | None:
    """Check if project uses local source and return the evee source path.

    Detects if the project was created with --from-source by checking
    pyproject.toml for file:// URLs or path-based sources.

    Args:
        config_path: Path to the experiment config.yaml file

    Returns:
        The local evee source path if the project was created with --from-source,
        otherwise None.
    """
    pyproject_path = config_path.parent.parent / "pyproject.toml"
    if not pyproject_path.exists():
        return None

    try:
        with open(pyproject_path, "rb") as f:
            pyproject = tomllib.load(f)
    except Exception:
        # Cannot read or parse pyproject.toml - fall back to no local source
        return None

    # Check dependencies for file:// URL pattern
    deps = pyproject.get("project", {}).get("dependencies", [])
    for dep in deps:
        if "evee-ms-core" in dep and "file://" in dep:
            # Extract path from: evee-ms-core @ file:///path/to/evee
            match = re.search(r"file://([^\s]+)", dep)
            if match:
                return Path(urlparse(f"file://{match.group(1)}").path)

    # Also check [tool.uv.sources] for path-based sources
    sources = pyproject.get("tool", {}).get("uv", {}).get("sources", {})
    core_source = sources.get("evee-ms-core", {})
    if isinstance(core_source, dict) and "path" in core_source:
        return Path(core_source["path"])

    return None


def print_dependency_instruction(backend: str, config_path: Path, console: Console | None = None) -> None:
    """Print smart dependency instruction based on project source type.

    Args:
        backend: Backend name (e.g., "mlflow", "azureml")
        config_path: Path to the experiment config.yaml file
        console: Rich console for output (creates new one if not provided)
    """
    if console is None:
        console = Console()

    evee_ver = get_evee_version()
    local_source = get_local_source_path(config_path)
    console.print("\n[bold]Add dependency to your project:[/bold]")

    pkg_name = f"evee-ms-{backend}"
    pkg_subdir = f"evee-{backend}"

    if local_source:
        # Project uses --from-source, provide matching local path.
        # Using inline "pkg @ file://path" format is intentional:
        # - `uv add` without --raw automatically manages [tool.uv.sources] for us
        # - This keeps the instruction simple (single command) while uv handles the format
        pkg_path = local_source / "packages" / pkg_subdir
        if pkg_path.exists():
            console.print(f'  [cyan]uv add "{pkg_name} @ file://{pkg_path}"[/cyan]')
        else:
            console.print(f"  [yellow]Warning: {pkg_path} not found[/yellow]")
    else:
        # Git-based install
        ver_ref = f"v{evee_ver}" if evee_ver else "latest"
        dep_str = f"{pkg_name} @ {GIT_BASE_URL}@{ver_ref}#subdirectory=packages/{pkg_subdir}"
        console.print(f'  [cyan]uv add "{dep_str}"[/cyan]')
