"""Utility for managing __init__.py import statements."""

import ast
import re
from pathlib import Path


def add_import_to_init(init_file: Path, module_name: str, import_what: str = "*") -> bool:
    """
    Add an import statement to __init__.py if not already present.

    Args:
        init_file: Path to the __init__.py file
        module_name: Module to import from (e.g., "f1score_metric")
        import_what: What to import (default: "*" for "from module import *")

    Returns:
        True if successful, False otherwise

    Examples:
        >>> add_import_to_init(Path("metrics/__init__.py"), "f1score_metric")
        # Adds: from .f1score_metric import *

        >>> add_import_to_init(Path("metrics/__init__.py"), "custom_metric", "CustomMetric")
        # Adds: from .custom_metric import CustomMetric
    """
    try:
        # Create the file if it doesn't exist
        if not init_file.exists():
            init_file.parent.mkdir(parents=True, exist_ok=True)
            init_file.write_text('"""Metrics module."""\n\n', encoding="utf-8")

        # Read current content
        content = init_file.read_text(encoding="utf-8")

        # Check if import already exists
        import_statement = f"from .{module_name} import {import_what}"
        if import_statement in content:
            return True  # Already exists, nothing to do

        # Also check for variations with different whitespace
        pattern = rf"from\s+\.{re.escape(module_name)}\s+import\s+{re.escape(import_what)}"
        if re.search(pattern, content):
            return True  # Already exists with different formatting

        # Find the best place to insert the import
        lines = content.split("\n")
        insert_index = _find_import_insertion_point(lines)

        # Insert the new import
        lines.insert(insert_index, import_statement)

        # Update __all__ if it exists and import_what is not "*"
        if import_what != "*":
            lines = _update_all_list(lines, import_what)

        # Write back
        new_content = "\n".join(lines)
        init_file.write_text(new_content, encoding="utf-8")

        return True

    except (OSError, UnicodeDecodeError) as e:
        import logging

        logging.warning(f"Failed to add import to {init_file}: {e}")
        return False


def _find_import_insertion_point(lines: list[str]) -> int:
    """
    Find the best position to insert a new import statement.

    Inserts after:
    1. Module docstring (if present)
    2. Other imports (to keep imports together)
    3. Before any other code

    Args:
        lines: Lines of the __init__.py file

    Returns:
        Line index where the import should be inserted
    """
    # Track state
    in_docstring = False
    docstring_closed = False
    last_import_line = -1
    docstring_quote = None

    for i, line in enumerate(lines):
        stripped = line.strip()

        # Handle docstrings (only at module level, before any code/imports)
        if not docstring_closed:
            # Check for docstring start (must be at beginning of stripped line)
            if not in_docstring:
                if stripped.startswith('"""') or stripped.startswith("'''"):
                    docstring_quote = '"""' if stripped.startswith('"""') else "'''"
                    # Check if it's a single-line docstring
                    if stripped.count(docstring_quote) >= 2:
                        docstring_closed = True
                    else:
                        in_docstring = True
                    continue
            else:
                # We're in a multi-line docstring, look for the end
                if docstring_quote in line:
                    docstring_closed = True
                    in_docstring = False
                continue

        # Skip lines while in docstring
        if in_docstring:
            continue

        # Track import statements
        if stripped.startswith(("import ", "from ")):
            last_import_line = i

        # If we hit non-import code after docstring, insert before it
        elif stripped and not stripped.startswith("#"):
            if last_import_line >= 0:
                # Insert after last import
                return last_import_line + 1
            else:
                # Insert before first code
                return i

    # If we get here, either:
    # - File is all imports (append after last import)
    # - File is empty or only docstring (append at end)
    if last_import_line >= 0:
        return last_import_line + 1

    # Add after docstring if present, otherwise at end
    return len(lines)


def _update_all_list(lines: list[str], name: str) -> list[str]:
    """
    Update __all__ list to include the given name if not already present.

    Args:
        lines: Lines of the __init__.py file
        name: Name to add to __all__

    Returns:
        Updated lines
    """
    # Find __all__ definition
    all_index = None
    for i, line in enumerate(lines):
        if "__all__" in line and "=" in line:
            all_index = i
            break

    if all_index is None:
        # No __all__ found, don't create one
        return lines

    # Check if name already in __all__
    all_line = lines[all_index]
    if f'"{name}"' in all_line or f"'{name}'" in all_line:
        return lines  # Already present

    # Simple case: single-line __all__ = [...]
    if "[" in all_line and "]" in all_line:
        # Replace closing bracket with new entry
        all_line = all_line.rstrip()
        if all_line.endswith("]"):
            # Check if list is empty
            all_line = all_line.replace("[]", f'["{name}"]') if "[]" in all_line else all_line[:-1] + f', "{name}"]'
        lines[all_index] = all_line

    return lines


def remove_import_from_init(init_file: Path, module_name: str) -> bool:
    """
    Remove an import statement from __init__.py.

    Args:
        init_file: Path to the __init__.py file
        module_name: Module to remove imports for

    Returns:
        True if successful (including if import didn't exist), False on error

    Examples:
        >>> remove_import_from_init(Path("metrics/__init__.py"), "f1score_metric")
        # Removes: from .f1score_metric import *
    """
    try:
        if not init_file.exists():
            return True  # Nothing to remove

        content = init_file.read_text(encoding="utf-8")
        lines = content.split("\n")

        # Filter out lines that import from this module
        pattern = rf"from\s+\.{re.escape(module_name)}\s+import\s+"
        new_lines = [line for line in lines if not re.search(pattern, line)]

        # Write back
        new_content = "\n".join(new_lines)
        init_file.write_text(new_content, encoding="utf-8")

        return True

    except (OSError, UnicodeDecodeError) as e:
        import logging

        logging.warning(f"Failed to remove import from {init_file}: {e}")
        return False


def get_imported_modules(init_file: Path) -> list[str]:
    """
    Get list of modules imported in __init__.py.

    Args:
        init_file: Path to the __init__.py file

    Returns:
        List of module names that are imported

    Examples:
        >>> get_imported_modules(Path("metrics/__init__.py"))
        ['f1score_metric', 'accuracy_metric']
    """
    if not init_file.exists():
        return []

    try:
        content = init_file.read_text(encoding="utf-8")
        tree = ast.parse(content)

        modules = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.level == 1 and node.module:
                # Only handle relative imports from current package
                modules.append(node.module)

        return modules

    except Exception:
        # Fallback to regex if AST parsing fails
        try:
            content = init_file.read_text(encoding="utf-8")
            pattern = r"from\s+\.(\w+)\s+import\s+"
            matches = re.findall(pattern, content)
            return matches
        except Exception:
            return []
