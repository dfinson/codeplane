"""Operations for the 'evee new' command - project scaffolding and validation."""

import re
import shutil
from collections.abc import Sequence
from pathlib import Path


def validate_project_name(name: str | None) -> tuple[bool, str]:
    """
    Validate a project name.

    Args:
        name: Project name to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not name:
        return False, "Project name cannot be empty"

    # Strip whitespace for better UX
    name = name.strip()

    if not name:
        return False, "Project name cannot be empty"

    # Allow alphanumeric, hyphens, and underscores
    if not re.match(r"^[a-zA-Z0-9_-]+$", name):
        return False, "Project name must contain only alphanumeric characters, hyphens, or underscores"

    # Check length
    if len(name) > 100:
        return False, "Project name is too long (max 100 characters)"

    return True, ""


def validate_description(description: str | None) -> tuple[bool, str]:
    """
    Validate a project description.

    Args:
        description: Project description to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not description:
        return True, ""  # Empty description is allowed

    # Check for problematic characters that could break YAML/TOML
    problematic_chars = ['"', "'", "\n", "\r", "\t"]
    for char in problematic_chars:
        if char in description:
            char_name = {'"': "double quotes", "'": "single quotes", "\n": "newlines", "\r": "carriage returns", "\t": "tabs"}.get(char, char)
            return False, f"Project description cannot contain {char_name}"

    # Check length
    if len(description) > 500:
        return False, "Project description is too long (max 500 characters)"

    return True, ""


def copy_and_render_template(
    template_dirs: Path | Sequence[Path],
    output_dir: Path,
    replacements: dict[str, str],
) -> Path:
    """
    Copy template directories (with layering) and replace placeholders in files.

    Supports layered template composition: if multiple directories are provided,
    they are copied in order, with later directories overlaying earlier ones.
    This allows a base template to be extended by backend-specific overlays.

    Note: If output_dir exists, it will be removed and recreated. Callers should
    handle confirmation prompts before calling this function.

    Args:
        template_dirs: Source template directory or sequence of directories.
                       If a sequence, directories are layered in order (later overlays earlier).
        output_dir: Destination directory (will be created if doesn't exist)
        replacements: Dictionary of placeholder -> value mappings
                     e.g., {"{project_name}": "my-project", "{description}": "My desc"}

    Returns:
        Path to the created project directory

    Raises:
        FileNotFoundError: If any template_dir doesn't exist
    """
    # Normalize to sequence
    if isinstance(template_dirs, Path):
        template_dirs = [template_dirs]

    # Validate all template directories exist
    for template_dir in template_dirs:
        if not template_dir.exists():
            raise FileNotFoundError(f"Template directory not found: {template_dir}")

    if output_dir.exists():
        shutil.rmtree(output_dir)

    # Copy template directories in order (layering)
    for i, template_dir in enumerate(template_dirs):
        if i == 0:
            # First directory: copy entirely
            shutil.copytree(template_dir, output_dir, symlinks=False)
        else:
            # Subsequent directories: overlay (copy with overwrite)
            shutil.copytree(template_dir, output_dir, symlinks=False, dirs_exist_ok=True)

    # Replace placeholders in all text files
    _replace_in_files(output_dir, replacements)

    return output_dir


def _replace_in_files(directory: Path, replacements: dict[str, str]) -> None:
    """
    Recursively replace placeholders in all text files in a directory.

    Args:
        directory: Directory to process
        replacements: Dictionary of placeholder -> value mappings
    """
    for file_path in directory.rglob("*"):
        if file_path.is_file():
            try:
                content = file_path.read_text(encoding="utf-8")

                # Replace all placeholders
                for placeholder, value in replacements.items():
                    content = content.replace(placeholder, value)

                file_path.write_text(content, encoding="utf-8")
            except (UnicodeDecodeError, PermissionError):
                # Skip binary files or files we can't read/write
                continue
