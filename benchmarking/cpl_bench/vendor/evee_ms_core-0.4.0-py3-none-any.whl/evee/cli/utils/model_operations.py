"""Helper functions for model CLI commands."""

from __future__ import annotations

import re
import runpy
from collections.abc import Mapping, Sequence
from copy import deepcopy
from pathlib import Path
from string import Template
from typing import Any

from ruamel.yaml.comments import CommentedMap, CommentedSeq
from ruamel.yaml.scalarstring import DoubleQuotedScalarString

from evee.cli.utils.config_manager import ConfigManager

MODEL_TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "templates" / "model"
DEFAULT_MODEL_TEMPLATE = MODEL_TEMPLATE_DIR / "empty_model.py"


def _resolve_model_template() -> Path:
    """Return the model template path."""
    return DEFAULT_MODEL_TEMPLATE


def read_models_from_config(config_path: Path) -> list[dict[str, Any]] | None:
    """Read the list of models from a configuration file.

    Args:
            config_path: Path to the configuration file.

    Returns:
            List of model configurations or None if the file cannot be read.
    """
    if not config_path.exists():
        return None

    try:
        manager = ConfigManager(config_path)
        if manager.read() is None:
            return None

        models_section = manager.get_models()
        if models_section is None:
            return []

        if not isinstance(models_section, Sequence):
            return []

        models: list[dict[str, Any]] = []
        for model in models_section:
            if isinstance(model, Mapping):
                models.append(_to_plain_object(model))

        return models

    except Exception as e:
        raise ValueError(f"Error reading models from config: {e}") from e


def model_exists(manager: ConfigManager, name: str) -> bool:
    """Check whether a model entry with the provided name already exists."""
    models = manager.get_models()
    if not models:
        return False

    return any(isinstance(entry, Mapping) and entry.get("name") == name for entry in models)


def update_model_in_config(
    config_path: Path,
    name: str,
    args: Sequence[Mapping[str, Any]] | Mapping[str, Any] | None = None,
    entry_point: str | None = None,
    metadata: Mapping[str, Any] | None = None,
) -> bool:
    """Add or update a model configuration within the experiment config.

    Raises ``ValueError`` if unable to read or update the configuration.

    Args:
            config_path: Path to the configuration file.
            name: Unique model identifier.
            args: Model argument definitions (list of mappings or a single mapping).
            entry_point: Optional import path for the model implementation.
            metadata: Additional fields to include with the model definition.

    Returns:
            True if the config was updated successfully, False otherwise.
    """
    try:
        if not config_path.exists():
            return False

        model_entry = _build_model_entry(name, args=args, entry_point=entry_point, metadata=metadata)
        sanitized_entry = _quote_strings(model_entry)
        manager = ConfigManager(config_path)

        return manager.update_model(name, sanitized_entry)

    except Exception as e:
        raise ValueError(f"Error updating model '{name}' in config. {e}") from e


def create_new_model_files(
    model_name: str,
    base_path: Path = Path("models"),
    overwrite: bool = False,
) -> None:
    """Create boilerplate files for a new model.

    Raises ``FileExistsError`` when the model directory already exists and
    ``overwrite`` is ``False``. All generated files overwrite existing
    content only when ``overwrite`` is explicit.

    Args:
        model_name: Name of the new model.
        base_path: Base directory where model folders are created.
        overwrite: Whether to overwrite existing model files.
    """

    # if no models folder, create it
    if not base_path.exists():
        base_path.mkdir(parents=True)

    # if no __init__.py in models folder, create it
    init_file = base_path / "__init__.py"
    if not init_file.exists():
        init_file.write_text("# Models package\n")

    # if model folder with model_name exists, check overwrite flag
    model_folder = base_path / model_name
    if model_folder.exists() and not overwrite:
        raise FileExistsError(f"Model folder '{model_folder}' already exists.")

    model_folder.mkdir(parents=True, exist_ok=True)
    model_init_file = model_folder / "__init__.py"
    if not model_init_file.exists() or overwrite:
        model_init_file.write_text(f"# {model_name} model package\n")

    # Create model file with boilerplate code
    model_file = model_folder / f"{model_name}.py"
    if not model_file.exists() or overwrite:
        template_path = _resolve_model_template()
        template_source = _render_model_template(model_name, template_path)
        model_file.write_text(template_source)


def _render_model_template(model_name: str, template_path: Path = DEFAULT_MODEL_TEMPLATE) -> str:
    """Render the model template with the provided model name."""
    name = _safe_model_name(model_name)
    class_name = _build_model_class_name(model_name)
    description = f"{class_name} model"

    try:
        namespace = runpy.run_path(str(template_path))
    except FileNotFoundError as error:
        raise FileNotFoundError(f"Model template not found: {template_path}") from error

    template_source = namespace.get("TEMPLATE")
    if not isinstance(template_source, str):
        raise ValueError("Model template module must define a TEMPLATE string")

    try:
        return Template(template_source).substitute(name=name, class_name=class_name, description=description)
    except KeyError as error:
        raise ValueError(f"Model template is missing required placeholders: {error}") from error


def _safe_model_name(model_name: str) -> str:
    """Generate a safe name suitable for YAML identifiers from the model name."""
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "_", model_name.strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned.lower() or "model"


def _build_model_class_name(model_name: str) -> str:
    """Create a PascalCase class name for the generated model."""
    parts = re.findall(r"[A-Za-z0-9]+", model_name)
    if not parts:
        return "GeneratedModel"

    candidate = "".join(part.capitalize() for part in parts)
    if not candidate.endswith("Model"):
        candidate = f"{candidate}Model"
    return candidate


def _build_model_entry(
    name: str,
    args: Sequence[Mapping[str, Any]] | Mapping[str, Any] | None,
    entry_point: str | None,
    metadata: Mapping[str, Any] | None,
) -> CommentedMap:
    """Construct the model entry prior to YAML serialization."""
    entry = CommentedMap()
    entry["name"] = name

    if entry_point:
        entry["entry_point"] = entry_point

    if args is not None:
        normalized_args = _normalize_args(args)
        entry["args"] = normalized_args

    if metadata:
        for key, value in metadata.items():
            if key in {"name", "entry_point", "args"}:
                continue
            entry[key] = deepcopy(value)

    return entry


def _normalize_args(args: Sequence[Mapping[str, Any]] | Mapping[str, Any]) -> CommentedSeq:
    """Normalize args into a CommentedSeq of mappings."""
    seq = CommentedSeq()

    if isinstance(args, Mapping):
        for key, value in args.items():
            mapping = CommentedMap()
            mapping[key] = _normalize_arg_value(value)
            seq.append(mapping)
        return seq

    if isinstance(args, Sequence) and not isinstance(args, (str, bytes)):
        for item in args:
            if not isinstance(item, Mapping):
                raise ValueError("Each item in args sequence must be a mapping")
            mapping = CommentedMap()
            for key, value in item.items():
                mapping[key] = _normalize_arg_value(value)
            seq.append(mapping)
        return seq

    raise ValueError("Args must be a mapping or a sequence of mappings")


def _normalize_arg_value(value: Any) -> CommentedSeq:
    """Ensure individual argument values serialize as lists."""
    seq = CommentedSeq()

    if isinstance(value, CommentedSeq) or (isinstance(value, Sequence) and not isinstance(value, (str, bytes, Mapping))):
        for item in value:
            seq.append(deepcopy(item))
    else:
        seq.append(deepcopy(value))

    seq.fa.set_flow_style()
    return seq


def _quote_strings(value: Any) -> Any:
    """Recursively wrap string values to preserve double quotes when dumping YAML."""
    if isinstance(value, str):
        return DoubleQuotedScalarString(value)

    if isinstance(value, CommentedSeq):
        seq = CommentedSeq()
        for item in value:
            seq.append(_quote_strings(item))
        flow_style = value.fa.flow_style()
        if flow_style:
            seq.fa.set_flow_style()
        elif flow_style is False:
            seq.fa.set_block_style()
        return seq

    if isinstance(value, tuple):
        seq = CommentedSeq()
        for item in value:
            seq.append(_quote_strings(item))
        seq.fa.set_flow_style()
        return seq

    if isinstance(value, list):
        seq = CommentedSeq()
        for item in value:
            seq.append(_quote_strings(item))
        seq.fa.set_flow_style()
        return seq

    if isinstance(value, Mapping):
        mapping = CommentedMap()
        for key, item in value.items():
            mapping[key] = _quote_strings(item)
        return mapping

    return value


def _to_plain_object(value: Any) -> Any:
    """Convert CommentedMap/Seq structures into plain Python types."""
    if isinstance(value, Mapping):
        return {key: _to_plain_object(item) for key, item in value.items()}

    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [_to_plain_object(item) for item in value]

    return value
