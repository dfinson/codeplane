"""CLI utility functions."""
