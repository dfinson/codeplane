"""Helper functions for dataset CLI commands."""

import csv
import json
import shutil
from pathlib import Path
from typing import Any

from evee.cli.utils.config_manager import ConfigManager

# Minimal sample datasets for testing
MINIMAL_SAMPLES = {
    "jsonl": [
        {"input": "Sample input 1", "output": "Sample output 1"},
        {"input": "Sample input 2", "output": "Sample output 2"},
    ],
    "csv": {"headers": ["input", "output"], "rows": [["Sample input 1", "Sample output 1"], ["Sample input 2", "Sample output 2"]]},
}


def get_available_dataset_types() -> dict[str, str]:
    """Get available dataset types from registry.

    Returns:
        dict mapping type name to description
    """
    from evee.core.base_dataset import DATASET_REGISTRY
    from evee.core.decorator_discovery import import_builtin_datasets

    # Ensure built-in datasets are imported
    import_builtin_datasets()

    types = {}
    for name, cls in DATASET_REGISTRY.items():
        # Extract description from docstring if available
        desc = (cls.__doc__ or "").split("\n")[0] if cls.__doc__ else "No description"
        types[name] = desc

    return types


def validate_dataset(file_path: Path, dataset_type: str) -> tuple[bool, str | None]:
    """Validate that a dataset file can be loaded.

    Args:
        file_path: Path to the dataset file
        dataset_type: Type of dataset (csv, jsonl, etc.)

    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        # Import inside function to avoid circular imports
        from evee.core.decorator_discovery import import_builtin_datasets
        from evee.datasets.dataset_factory import DatasetFactory

        # Ensure built-in datasets are registered
        import_builtin_datasets()

        factory = DatasetFactory()
        dataset = factory.create_dataset(dataset_type=dataset_type, args={"data_path": str(file_path)})

        record_count = len(dataset)

        if record_count == 0:
            return False, "Dataset is empty (0 records)"

        return True, None

    except (FileNotFoundError, ValueError, TypeError, KeyError, json.JSONDecodeError, UnicodeDecodeError, OSError) as e:
        # Expected validation errors - return as validation failure
        return False, str(e)
    except Exception as e:
        # Unexpected errors - these indicate bugs that should be visible
        # Re-raise with context to help debugging
        raise RuntimeError(f"Unexpected error validating dataset at {file_path}: {e}") from e


def create_minimal_sample(output_path: Path, dataset_type: str) -> None:
    """Create a minimal sample dataset file.

    Args:
        output_path: Path where the file should be created
        dataset_type: Type of dataset (csv or jsonl)

    Raises:
        ValueError: If dataset_type is not supported
    """
    if dataset_type not in MINIMAL_SAMPLES:
        raise ValueError(f"Unsupported dataset type: {dataset_type}")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    if dataset_type == "jsonl":
        with open(output_path, "w", encoding="utf-8") as f:
            for record in MINIMAL_SAMPLES["jsonl"]:
                f.write(json.dumps(record) + "\n")
    elif dataset_type == "csv":
        with open(output_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            sample = MINIMAL_SAMPLES["csv"]
            writer.writerow(sample["headers"])
            writer.writerows(sample["rows"])


def copy_dataset(source_path: Path, dest_path: Path) -> None:
    """Copy a dataset file to destination.

    Args:
        source_path: Source file path
        dest_path: Destination file path

    Raises:
        ValueError: If source_path doesn't exist or isn't a file
    """
    # Ensure source file exists and is a file
    if not source_path.exists():
        raise ValueError(f"Source file does not exist: {source_path}")
    if not source_path.is_file():
        raise ValueError(f"Source path is not a file: {source_path}")

    # Create destination directory and copy file
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_path, dest_path)


def infer_dataset_type(file_path: Path) -> str:
    """Infer dataset type from file extension.

    Args:
        file_path: Path to the dataset file

    Returns:
        Dataset type (csv, jsonl)

    Raises:
        ValueError: If file extension is not supported
    """
    extension_map = {".csv": "csv", ".jsonl": "jsonl"}
    dataset_type = extension_map.get(file_path.suffix.lower())
    if dataset_type is None:
        supported = ", ".join(extension_map.keys())
        raise ValueError(f"Unsupported file type '{file_path.suffix}'. Supported types: {supported}")
    return dataset_type


def read_dataset_from_config(config_path: Path) -> dict[str, Any] | None:
    """Read dataset configuration from config.yaml.

    Args:
        config_path: Path to config.yaml

    Returns:
        Dataset configuration dict or None if not found
    """
    if not config_path.exists():
        return None

    try:
        manager = ConfigManager(config_path)
        return manager.get_dataset()
    except Exception:
        return None


def update_dataset_in_config(config_path: Path, name: str, dataset_type: str, data_path: str, version: str = "1.0.0") -> bool:
    """Update dataset section in config.yaml.

    Args:
        config_path: Path to config.yaml
        name: Dataset name
        dataset_type: Dataset type (csv, jsonl)
        data_path: Path to dataset file
        version: Dataset version

    Returns:
        True if successful, False otherwise
    """
    if not config_path.exists():
        return False

    try:
        manager = ConfigManager(config_path)
        return manager.update_dataset(name, dataset_type, data_path, version)
    except Exception:
        return False


def get_file_size_str(file_path: Path) -> str:
    """Get human-readable file size.

    Args:
        file_path: Path to file

    Returns:
        Formatted size string (e.g., "45.2 KB")
    """
    try:
        size_bytes = file_path.stat().st_size
    except FileNotFoundError:
        return "0 B"

    if size_bytes < 1024:
        return f"{size_bytes} B"

    for unit in ["KB", "MB", "GB"]:
        size_bytes /= 1024.0
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"

    return f"{size_bytes:.1f} TB"


def get_first_record(file_path: Path, dataset_type: str) -> dict | None:
    """Get the first record from a dataset.

    Args:
        file_path: Path to dataset file
        dataset_type: Type of dataset

    Returns:
        First record as dict or None if error
    """
    try:
        if dataset_type == "jsonl":
            with open(file_path, encoding="utf-8") as f:
                first_line = f.readline().strip()
                if first_line:
                    return json.loads(first_line)
        elif dataset_type == "csv":
            with open(file_path, encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    return dict(row)
    except Exception:
        return None

    return None


def format_record_preview(record: dict, max_value_length: int = 100) -> str:
    """Format a record for display.

    Args:
        record: Record dictionary
        max_value_length: Maximum length per field value

    Returns:
        Formatted string
    """
    formatted = {}
    for key, value in record.items():
        str_value = str(value)
        if len(str_value) > max_value_length:
            str_value = str_value[:max_value_length] + "..."
        formatted[key] = str_value

    return json.dumps(formatted, ensure_ascii=False)
