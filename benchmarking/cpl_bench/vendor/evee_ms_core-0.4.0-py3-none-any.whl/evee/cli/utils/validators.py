"""Input validation utilities for CLI commands."""

from pathlib import Path

from evee.cli.constants import MAX_DESCRIPTION_LENGTH, MAX_NAME_LENGTH


def parse_models(models: str | None) -> list[str] | None:
    """Parse comma-separated models string into a list.

    Args:
        models: Comma-separated model names or None

    Returns:
        List of model names or None if no models specified

    Examples:
        >>> parse_models("model_a,model_b")
        ['model_a', 'model_b']
        >>> parse_models("model_a, model_b , model_c")
        ['model_a', 'model_b', 'model_c']
        >>> parse_models(None)
        None
        >>> parse_models("")
        None
    """
    if not models:
        return None
    # Split by comma and strip whitespace from each model name
    parsed_models = [m.strip() for m in models.split(",") if m.strip()]
    # Normalize behavior: return None when no valid models are provided
    return parsed_models or None


def validate_metric_name(name: str) -> tuple[bool, str | None]:
    """
    Validate a metric name.

    Metric names must:
    - Be 1-100 characters long
    - Start with a letter
    - Contain only letters, numbers, and underscores
    - Not start or end with underscores

    Args:
        name: The metric name to validate

    Returns:
        Tuple of (is_valid, error_message)

    Examples:
        >>> validate_metric_name("f1_score")
        (True, None)
        >>> validate_metric_name("my_metric_v2")
        (True, None)
        >>> validate_metric_name("_invalid")
        (False, "Name must start with a letter")
        >>> validate_metric_name("123invalid")
        (False, "Name must start with a letter")
    """
    if not name:
        return False, "Name cannot be empty"

    if len(name) > MAX_NAME_LENGTH:
        return False, f"Name must be {MAX_NAME_LENGTH} characters or less"

    # Must start with a letter
    if not name[0].isalpha():
        return False, "Name must start with a letter"

    # Cannot end with underscore
    if name.endswith("_"):
        return False, "Name cannot end with underscores"

    # Only ASCII letters, numbers, and underscores allowed
    if not name.replace("_", "").isascii() or not name.replace("_", "").isalnum():
        return False, "Name can only contain letters, numbers, and underscores"

    return True, None


def validate_description(description: str) -> tuple[bool, str | None]:
    """
    Validate a description string.

    Args:
        description: The description to validate

    Returns:
        Tuple of (is_valid, error_message)
    """
    if not description or not description.strip():
        return False, "Description cannot be empty"

    if len(description) > MAX_DESCRIPTION_LENGTH:
        return False, f"Description must be {MAX_DESCRIPTION_LENGTH} characters or less"

    return True, None


def validate_file_path(file_path: Path, must_exist: bool = True) -> tuple[bool, str | None]:
    """
    Validate a file path.

    Args:
        file_path: The file path to validate
        must_exist: Whether the file must already exist

    Returns:
        Tuple of (is_valid, error_message)
    """
    if must_exist and not file_path.exists():
        return False, f"File does not exist: {file_path}"

    if must_exist and not file_path.is_file():
        return False, f"Path is not a file: {file_path}"

    return True, None
