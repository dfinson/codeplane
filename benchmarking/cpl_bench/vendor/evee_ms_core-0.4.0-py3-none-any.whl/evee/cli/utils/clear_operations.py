"""Clear operations utility for managing experiment output cleanup."""

import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

# Pattern to match timestamped experiment folders: name__YYYY-MM-DD_HH-MM-SS
TIMESTAMP_PATTERN = re.compile(r"__(\d{4})-(\d{2})-(\d{2})_(\d{2})-(\d{2})-(\d{2})$")


def validate_path(path: Path) -> bool:
    """Validate that the target path exists and is a directory.

    Args:
        path: Path to validate

    Returns:
        True if path is valid, False otherwise
    """
    return path.exists() and path.is_dir()


def discover_experiment_folders(path: Path) -> list[Path]:
    """Discover all timestamped experiment folders in the target path.

    Args:
        path: Path to output directory

    Returns:
        List of Path objects for experiment folders
    """
    if not validate_path(path):
        return []

    folders = []
    for item in path.iterdir():
        if item.is_dir() and parse_timestamp(item.name) is not None:
            folders.append(item)

    return folders


def parse_timestamp(folder_name: str) -> datetime | None:
    """Extract timestamp from folder name.

    Args:
        folder_name: Name of the folder (e.g., "exp__2025-11-21_17-42-25")

    Returns:
        datetime object if pattern matches, None otherwise
    """
    match = TIMESTAMP_PATTERN.search(folder_name)
    if not match:
        return None

    year, month, day, hour, minute, second = map(int, match.groups())
    try:
        return datetime(year, month, day, hour, minute, second)
    except ValueError:
        return None


def calculate_size(folder: Path, errors: list | None = None) -> int:
    """Calculate total size of a folder recursively.

    Args:
        folder: Path to folder
        errors: Optional list to collect error messages for inaccessible files

    Returns:
        Total size in bytes
    """
    total_size = 0
    try:
        for item in folder.rglob("*"):
            try:
                if item.is_file() and not item.is_symlink():
                    total_size += item.stat().st_size
            except (OSError, PermissionError) as e:
                if errors is not None:
                    errors.append(f"Could not access {item}: {e}")
    except (OSError, PermissionError) as e:
        if errors is not None:
            errors.append(f"Could not traverse {folder}: {e}")

    return total_size


def format_size(size_bytes: int) -> str:
    """Format bytes to human-readable format.

    Args:
        size_bytes: Size in bytes

    Returns:
        Human-readable string (e.g., "1.5 MB")
    """
    size = float(size_bytes)
    for unit in ["bytes", "KB", "MB", "GB", "TB"]:
        if size < 1024.0:
            if unit == "bytes":
                return f"{int(size)} {unit}"
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} PB"


def read_output_path_from_config(config_path: Path) -> str | None:
    """Read output_path from config.yaml file.

    Args:
        config_path: Path to config.yaml

    Returns:
        Output path from config, or None if not found
    """
    try:
        if not config_path.exists():
            return None

        with open(config_path) as f:
            config = yaml.safe_load(f)

        return config.get("experiment", {}).get("output_path")
    except (OSError, yaml.YAMLError):
        return None


def sort_by_timestamp(folders: list[Path], reverse: bool = False) -> list[Path]:
    """Sort folders by their timestamps.

    Args:
        folders: List of folder paths
        reverse: If True, sort descending (newest first)

    Returns:
        Sorted list of folders
    """

    def get_timestamp(folder: Path) -> datetime:
        ts = parse_timestamp(folder.name)
        return ts if ts else datetime.min

    return sorted(folders, key=get_timestamp, reverse=reverse)


def filter_by_date(
    folders: list[Path],
    before: datetime | None = None,
    after: datetime | None = None,
) -> list[Path]:
    """Filter folders by date range.

    Args:
        folders: List of folder paths
        before: Only include folders before this date
        after: Only include folders after this date

    Returns:
        Filtered list of folders
    """
    filtered = []
    for folder in folders:
        timestamp = parse_timestamp(folder.name)
        if timestamp is None:
            continue

        if before and timestamp >= before:
            continue
        if after and timestamp <= after:
            continue

        filtered.append(folder)

    return filtered


def analyze(
    path: Path,
    keep_last: int = 0,
    before: datetime | None = None,
    after: datetime | None = None,
    logs_only: bool = False,
) -> dict[str, Any]:
    """Analyze what would be deleted with given filters.

    Args:
        path: Path to output directory
        keep_last: Number of most recent experiments to keep
        before: Only include folders before this date
        after: Only include folders after this date
        logs_only: If True, analyze only logs/ subdirectories within experiments

    Returns:
        Dictionary with analysis results. When logs_only=True, returns:
        - logs_folders: List of logs folder paths
        - logs_folder_sizes: Dict mapping logs folder to size
        - count: Number of logs folders
        - total_size: Total size in bytes
        - total_size_formatted: Human-readable total size

        When logs_only=False (default), returns:
        - folders: List of experiment folder paths
        - folder_sizes: Dict mapping folder to size
        - count: Number of folders
        - total_size: Total size in bytes
        - total_size_formatted: Human-readable total size
    """
    folders = discover_experiment_folders(path)

    # Apply date filters
    if before or after:
        folders = filter_by_date(folders, before=before, after=after)

    # Handle keep_last
    if keep_last > 0:
        sorted_folders = sort_by_timestamp(folders, reverse=True)
        folders = sorted_folders[keep_last:]  # Keep newest N, delete rest

    # For logs_only mode, find logs subdirectories
    if logs_only:
        logs_folders: list[Path] = []
        logs_folder_sizes: dict[Path, int] = {}
        total_size = 0

        for folder in folders:
            logs_dir = folder / "logs"
            if logs_dir.exists() and logs_dir.is_dir():
                logs_folders.append(logs_dir)
                log_size = calculate_size(logs_dir)
                logs_folder_sizes[logs_dir] = log_size
                total_size += log_size

        return {
            "logs_folders": logs_folders,
            "logs_folder_sizes": logs_folder_sizes,
            "count": len(logs_folders),
            "total_size": total_size,
            "total_size_formatted": format_size(total_size),
        }

    # Standard mode: return experiment folders
    folder_sizes = {f: calculate_size(f) for f in folders}
    total_size = sum(folder_sizes.values())

    return {
        "folders": folders,
        "folder_sizes": folder_sizes,
        "count": len(folders),
        "total_size": total_size,
        "total_size_formatted": format_size(total_size),
    }


def delete_folders(
    folders: list[Path],
    preview: bool = False,
) -> dict[str, Any]:
    """Delete the specified folders.

    Args:
        folders: List of folder paths to delete
        preview: If True, don't actually delete

    Returns:
        Dictionary with deletion results
    """
    succeeded = 0
    failed = 0
    errors = []

    for folder in folders:
        if preview:
            succeeded += 1
            continue

        try:
            # Check if folder still exists (concurrent modifications)
            if not folder.exists():
                continue

            # Handle symlinks specially - unlink them without following
            if folder.is_symlink():
                folder.unlink()
            else:
                # Use shutil.rmtree to recursively delete
                shutil.rmtree(folder)
            succeeded += 1
        except (OSError, PermissionError) as e:
            failed += 1
            errors.append({"folder": str(folder), "error": str(e)})

    return {
        "succeeded": succeeded,
        "failed": failed,
        "errors": errors,
    }
