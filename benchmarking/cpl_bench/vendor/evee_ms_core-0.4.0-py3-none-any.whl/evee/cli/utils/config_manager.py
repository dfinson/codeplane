"""Centralized configuration file management using ruamel.yaml."""

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedSeq
from ruamel.yaml.scalarstring import DoubleQuotedScalarString

# Configuration path constants
DEFAULT_CONFIG_PATH = "experiment/config.yaml"
DEFAULT_CONFIG_DIR = "experiment"

# Configuration section paths - using tuples for type safety
SECTION_EXPERIMENT = ("experiment",)
SECTION_DATASET = ("experiment", "dataset")
SECTION_MODELS = ("experiment", "models")
SECTION_METRICS = ("experiment", "metrics")
SECTION_CONNECTIONS = ("experiment", "connections")
SECTION_COMPUTE_BACKEND = ("experiment", "compute_backend")
SECTION_TRACKING_BACKEND = ("experiment", "tracking_backend")


class ConfigManager:
    """Manages YAML configuration files with formatting preservation.

    This class provides both low-level section access and high-level
    domain-specific methods for common operations like managing datasets,
    models, and metrics.
    """

    def __init__(self, config_path: Path):
        """Initialize config manager with path to config file.

        Args:
            config_path: Path to the config.yaml file
        """
        self.config_path = config_path
        self._yaml = self._create_yaml_instance()

    @staticmethod
    def _create_yaml_instance() -> YAML:
        """Create configured YAML instance with preservation settings."""
        yaml = YAML()
        yaml.preserve_quotes = True
        yaml.default_flow_style = False
        yaml.width = 4096  # Prevent line wrapping
        yaml.indent(mapping=2, sequence=4, offset=2)  # Match evee formatting
        return yaml

    def read(self) -> dict[str, Any] | None:
        """Read entire config file.

        Returns:
            Config dictionary or None if file doesn't exist or error occurs
        """
        if not self.config_path.exists():
            return None
        try:
            with open(self.config_path, encoding="utf-8") as f:
                return self._yaml.load(f) or {}
        except Exception:
            return None

    def read_section(self, *keys: str | int) -> Any | None:
        """Read specific section by path.

        Supports nested navigation through dicts and lists.

        Args:
            *keys: Path to the section (e.g., "experiment", "dataset")
                  Can include integers for list access

        Returns:
            Value at the specified path or None if not found

        Examples:
            >>> manager.read_section("experiment", "dataset")
            >>> manager.read_section("experiment", "models", 0)  # First model
            >>> manager.read_section(*SECTION_METRICS)  # Using constant
        """
        config = self.read()
        if config is None:
            return None

        current = config
        for key in keys:
            if isinstance(current, dict):
                current = current.get(key)
            elif isinstance(current, list) and isinstance(key, int):
                try:
                    current = current[key]
                except IndexError:
                    return None
            else:
                return None

            if current is None:
                return None

        return current

    def write(self, config: dict[str, Any]) -> bool:
        """Write entire config file.

        Args:
            config: Complete configuration dictionary to write

        Returns:
            True if successful, False otherwise
        """
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                self._yaml.dump(config, f)
            return True
        except Exception:
            return False

    def update_section(self, *keys: str | int, value: Any) -> bool:
        """Update specific section by path.

        Creates intermediate sections if they don't exist.

        Args:
            *keys: Path to the section (e.g., "experiment", "dataset")
            value: Value to set at the specified path

        Returns:
            True if successful, False otherwise

        Examples:
            >>> manager.update_section("experiment", "dataset", value=dataset_config)
            >>> manager.update_section("experiment", "metrics", 0, value=new_metric)
            >>> manager.update_section(*SECTION_DATASET, value=dataset_config)
        """
        config = self.read()
        if config is None:
            return False

        # Navigate to parent of target
        current = config
        for key in keys[:-1]:
            if isinstance(key, int):
                # For list indices, we need the list to exist
                if not isinstance(current, list):
                    return False
            else:
                # Create intermediate dicts if needed
                if key not in current:
                    current[key] = {}
                current = current[key]

        # Set the value
        final_key = keys[-1]
        if isinstance(final_key, int):
            if isinstance(current, list) and 0 <= final_key < len(current):
                current[final_key] = value
            else:
                return False
        else:
            current[final_key] = value

        return self.write(config)

    @staticmethod
    def quote_string(s: str) -> DoubleQuotedScalarString:
        """Wrap string in quotes for YAML output.

        This ensures strings are quoted in the output YAML file,
        matching the evee config.yaml style.

        Args:
            s: String to quote

        Returns:
            Quoted string object for ruamel.yaml
        """
        return DoubleQuotedScalarString(s)

    # Domain-specific helper methods

    def get_dataset(self) -> dict[str, Any] | None:
        """Get dataset configuration.

        Returns:
            Dataset config dict or None if not found
        """
        return self.read_section(*SECTION_DATASET)

    def update_dataset(self, name: str, dataset_type: str, data_path: str, version: str = "1.0.0") -> bool:
        """Update dataset configuration.

        Args:
            name: Dataset name
            dataset_type: Dataset type (csv, jsonl)
            data_path: Path to dataset file
            version: Dataset version (default: "1.0.0")

        Returns:
            True if successful, False otherwise
        """
        dataset_config = {
            "name": self.quote_string(name),
            "type": self.quote_string(dataset_type),
            "version": self.quote_string(version),
            "args": {"data_path": self.quote_string(data_path)},
        }
        return self.update_section(*SECTION_DATASET, value=dataset_config)

    def get_models(self) -> list[dict[str, Any]] | None:
        """Get all models configuration.

        Returns:
            List of model configs or None if not found
        """
        return self.read_section(*SECTION_MODELS)

    def get_model(self, index: int) -> dict[str, Any] | None:
        """Get specific model configuration by index.

        Args:
            index: Model index in the list

        Returns:
            Model config dict or None if not found
        """
        return self.read_section(*SECTION_MODELS, index)

    def add_model(self, model_config: dict[str, Any]) -> bool:
        """Add a new model to the configuration.

        Args:
            model_config: Model configuration dictionary

        Returns:
            True if the model was added successfully, False otherwise
        """
        models = self.get_models() or []
        models.append(model_config)
        return self.update_section(*SECTION_MODELS, value=models)

    def update_model(self, name: str, model_config: dict[str, Any]) -> bool:
        """Update an existing model by name.

        Args:
            name: Name of the model to update
            model_config: New model configuration dictionary

        Returns:
            True if the model was updated successfully, False otherwise
        """
        models = self.get_models() or []
        for idx, entry in enumerate(models):
            if isinstance(entry, Mapping) and entry.get("name") == name:
                models[idx] = model_config
                break
        else:
            models.append(model_config)

        return self.update_section(*SECTION_MODELS, value=models)

    def get_metrics(self) -> list[dict[str, Any]] | None:
        """Get all metrics configuration.

        Returns:
            List of metric configs or None if not found
        """
        return self.read_section(*SECTION_METRICS)

    def get_metric(self, index: int) -> dict[str, Any] | None:
        """Get specific metric configuration by index.

        Args:
            index: Metric index in the list

        Returns:
            Metric config dict or None if not found
        """
        return self.read_section(*SECTION_METRICS, index)

    def add_metric(self, metric_config: dict[str, Any]) -> bool:
        """Add a new metric to the configuration.

        Args:
            metric_config: Metric configuration dictionary

        Returns:
            True if successful, False otherwise
        """
        config = self.read()
        if config is None:
            return False

        # Navigate to experiment section and metrics
        try:
            experiment = config.get("experiment")
            if not experiment:
                return False

            # Get or create metrics list
            if "metrics" not in experiment:
                experiment["metrics"] = CommentedSeq()

            metrics_section = experiment["metrics"]

            # Add the new metric (no spacing before it)
            metrics_section.append(metric_config)

            # Ensure blank line after metrics section (before next section)
            if "connections" in experiment:
                experiment.yaml_set_comment_before_after_key("connections", before="\n")

            return self.write(config)

        except Exception:
            # Fallback to simple append if spacing fails
            metrics = self.get_metrics() or []
            metrics.append(metric_config)
            return self.update_section(*SECTION_METRICS, value=metrics)

    def get_connections(self) -> list[dict[str, Any]] | None:
        """Get all connections configuration.

        Returns:
            List of connection configs or None if not found
        """
        return self.read_section(*SECTION_CONNECTIONS)

    def get_compute_backend(self) -> dict[str, Any] | None:
        """Get compute backend configuration.

        Returns:
            Compute backend config dict or None if not found
        """
        return self.read_section(*SECTION_COMPUTE_BACKEND)

    def update_compute_backend(self, config: dict[str, Any]) -> bool:
        """Update compute backend configuration.

        Args:
            config: Complete compute backend configuration dictionary

        Returns:
            True if successful, False otherwise
        """
        return self.update_section(*SECTION_COMPUTE_BACKEND, value=config)

    def get_tracking_backend(self) -> dict[str, Any] | None:
        """Get tracking backend configuration.

        Returns:
            Tracking backend config dict or None if not found
        """
        return self.read_section(*SECTION_TRACKING_BACKEND)

    def update_tracking_backend(self, config: dict[str, Any]) -> bool:
        """Update tracking backend configuration.

        Args:
            config: Complete tracking backend configuration dictionary

        Returns:
            True if successful, False otherwise
        """
        return self.update_section(*SECTION_TRACKING_BACKEND, value=config)
