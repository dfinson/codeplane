"""Helper functions for metric CLI commands."""

import json
from pathlib import Path
from typing import Any

from evee.cli.constants import (
    METRIC_FILE_SUFFIX,
)
from evee.cli.utils.config_manager import ConfigManager


def load_azure_evaluators() -> dict[str, Any]:
    """
    Load Azure AI evaluator metadata from JSON file.

    Returns:
        Dictionary mapping evaluator names to their metadata
    """
    # Get the JSON file path (in same directory as this module)
    json_path = Path(__file__).parent.parent / "azure_evaluators.json"

    if not json_path.exists():
        return {}

    try:
        with open(json_path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_azure_evaluator_names() -> list[str]:
    """
    Get list of available Azure AI evaluator names.

    Returns:
        Sorted list of evaluator names
    """
    evaluators = load_azure_evaluators()
    return sorted(evaluators.keys())


def get_azure_evaluator_info(evaluator_name: str) -> dict[str, Any] | None:
    """
    Get metadata for a specific Azure AI evaluator.

    Args:
        evaluator_name: Name of the evaluator (e.g., "F1ScoreEvaluator")

    Returns:
        Evaluator metadata dict or None if not found
    """
    evaluators = load_azure_evaluators()
    return evaluators.get(evaluator_name)


def format_init_params(evaluator_info: dict[str, Any]) -> tuple[str, str, str, str]:
    """
    Format Azure evaluator __init__ parameters for template rendering.
    Only includes simple parameters (int, float, str, bool) in __init__ signature.
    Complex parameters (model_config, credential, etc.) are documented as TODOs.

    Note: This function handles initialization parameters only.
    For callable/compute parameters, use format_callable_params_for_template().

    Args:
        evaluator_info: Evaluator metadata from azure_evaluators.json

    Returns:
        Tuple of (init_params, init_params_doc, init_args, complex_params_todo) for template placeholders
    """
    params = evaluator_info.get("parameters", [])

    if not params:
        return ("", "", "", "")

    # Separate simple and complex parameters
    simple_params = []
    complex_params = []

    for param in params:
        category = param.get("category", "complex")
        if category == "simple":
            simple_params.append(param)
        else:
            complex_params.append(param)

    # Build init signature for simple parameters only
    init_params_list = []
    init_doc_list = []
    init_args_list = []

    for param in simple_params:
        name = param["name"]
        required = param.get("required", True)
        default = param.get("default")
        param_type = param.get("type", "Any")

        # Build parameter signature
        if required:
            init_params_list.append(f"{name}: {param_type}")
        else:
            default_val = default if default else "None"
            init_params_list.append(f"{name}: {param_type} = {default_val}")

        # Build docstring
        doc_line = f"        {name}: "
        if "type" in param:
            doc_line += f"{param_type} - "
        if not required and default:
            doc_line += f"Optional, default: {default}"
        else:
            doc_line += "Required parameter"
        init_doc_list.append(doc_line)

        # Build constructor call arguments
        init_args_list.append(f"{name}={name}")

    # Build TODO comments for complex parameters
    complex_todo_lines = []
    if complex_params:
        complex_todo_lines.append("# TODO: Complex parameters need to be set up:")
        for param in complex_params:
            name = param["name"]
            category = param.get("category", "complex")

            if category == "model_config":
                complex_todo_lines.append(f"        # - {name}: Create from context.connections_registry")
                complex_todo_lines.append("        #   Example:")
                complex_todo_lines.append("        #   chat_connection = context.connections_registry[chat_connection_name]")
                complex_todo_lines.append("        #   model_config = create_model_config(chat_connection)")
                # Add as a separate comment line, not in the args list
                complex_todo_lines.append(f"        # Pass {name} to the evaluator once created")
            elif category == "credential":
                complex_todo_lines.append(f"        # - {name}: Azure credential object")
                complex_todo_lines.append("        #   See Azure authentication documentation")
                complex_todo_lines.append(f"        # Pass {name} to the evaluator once created")
            else:
                complex_todo_lines.append(f"        # - {name}: Complex parameter (type unknown)")
                complex_todo_lines.append(f"        # Pass {name} to the evaluator once implemented")

    init_params = ", " + ", ".join(init_params_list) if init_params_list else ""
    init_params_doc = "\n" + "\n".join(init_doc_list) if init_doc_list else ""
    init_args = ", ".join(init_args_list) if init_args_list else ""
    complex_params_todo = "\n        " + "\n        ".join(complex_todo_lines) + "\n" if complex_todo_lines else ""

    return (init_params, init_params_doc, init_args, complex_params_todo)


def format_callable_params_for_template(evaluator_info: dict[str, Any]) -> tuple[str, str, str, str]:
    """
    Generate all callable parameter-related template placeholders in a single pass.

    This consolidates the formatting of:
    - compute() method signature parameters
    - compute() method docstring
    - TODO comments explaining parameter mapping
    - Example evaluator call

    Args:
        evaluator_info: Evaluator metadata from azure_evaluators.json

    Returns:
        Tuple of (compute_params, compute_params_doc, callable_params_comment, example_call)
        for use in metric template placeholders
    """
    callable_params = evaluator_info.get("callable_params", [])

    if not callable_params:
        return ("", "", "#   (No callable parameters documented - check Azure AI documentation)", "# result = self.evaluator()  # Check Azure docs for required parameters")

    # Build all outputs in a single loop
    params_list = []
    doc_list = []
    comment_lines = []
    example_args = []

    for param in callable_params:
        name = param["name"]
        required = param.get("required", True)

        # 1. Compute method signature: parameters come from config mapping, use str type
        params_list.append(f"{name}: str")

        # 2. Compute method docstring
        req_str = "Required" if required else "Optional"
        doc_list.append(f"            {name}: {req_str} parameter for the evaluator")

        # 3. TODO comment explaining parameter mapping
        req_str_upper = "REQUIRED" if required else "optional"
        comment_lines.append(f"#   - {name} ({req_str_upper}): maps to the {name} parameter in compute()")

        # 4. Example evaluator call
        example_args.append(f"{name}={name}")

    compute_params = ", " + ", ".join(params_list) if params_list else ""
    compute_params_doc = "\n" + "\n".join(doc_list) if doc_list else ""
    callable_params_comment = "\n        ".join(comment_lines)
    example_call = f"result = self.evaluator(\n            {',\n            '.join(example_args)}\n        )"

    return (compute_params, compute_params_doc, callable_params_comment, example_call)


def read_metrics_from_config(config_path: Path) -> list[dict[str, Any]] | None:
    """
    Read metrics configuration from config.yaml.

    Args:
        config_path: Path to config.yaml

    Returns:
        List of metric configurations or None if not found
    """
    if not config_path.exists():
        return None

    try:
        manager = ConfigManager(config_path)
        return manager.get_metrics()
    except Exception:
        return None


def add_metric_to_config(
    config_path: Path,
    name: str,
    **kwargs: Any,
) -> bool:
    """
    Add a metric to config.yaml.

    Args:
        config_path: Path to config.yaml
        name: Metric name
        **kwargs: Additional metric-specific configuration (simple params, mapping, etc.)

    Returns:
        True if successful, False otherwise
    """
    if not config_path.exists():
        return False

    try:
        manager = ConfigManager(config_path)

        # Build metric config with mapping at the end
        # Extract mapping from kwargs if it exists
        mapping = kwargs.pop("mapping", None)

        # Build metric config starting with name
        metric_config: dict[str, Any] = {
            "name": manager.quote_string(name),
        }

        # Add any additional kwargs (except mapping)
        for key, value in kwargs.items():
            if isinstance(value, str):
                metric_config[key] = manager.quote_string(value)
            else:
                metric_config[key] = value

        # Add mapping last
        if mapping is not None:
            metric_config["mapping"] = mapping

        return manager.add_metric(metric_config)
    except Exception:
        return False


def metric_exists_in_config(config_path: Path, name: str) -> bool:
    """
    Check if a metric already exists in config.yaml.

    Args:
        config_path: Path to config.yaml
        name: Metric name to check

    Returns:
        True if metric exists, False otherwise
    """
    metrics = read_metrics_from_config(config_path)
    if not metrics:
        return False

    return any(m.get("name") == name for m in metrics)


def get_metric_file_path(metrics_dir: Path, name: str) -> Path:
    """
    Get the expected file path for a metric.

    Args:
        metrics_dir: Directory where metrics are stored
        name: Metric name (can be in PascalCase or snake_case)

    Returns:
        Path to the metric file
    """
    # Convert PascalCase to snake_case for filename
    # e.g., "F1ScoreEvaluator" -> "f1_score_evaluator"
    import re

    snake_name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name).lower()
    return metrics_dir / f"{snake_name}{METRIC_FILE_SUFFIX}"


def snake_to_pascal(snake_str: str) -> str:
    """
    Convert snake_case to PascalCase.

    Args:
        snake_str: String in snake_case

    Returns:
        String in PascalCase

    Examples:
        >>> snake_to_pascal("f1_score")
        'F1Score'
        >>> snake_to_pascal("my_custom_metric")
        'MyCustomMetric'
    """
    components = snake_str.split("_")
    return "".join(x.title() for x in components)
