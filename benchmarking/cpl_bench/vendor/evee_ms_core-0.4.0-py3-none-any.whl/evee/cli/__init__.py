"""CLI package for EVEE - Simplifying model evaluation.

The main CLI entry point is in evee.cli.main and should be run via:
    python -m evee.cli.main
or via the installed 'evee' command.
"""

# This file is intentionally minimal to avoid sys.modules conflicts
# when running 'python -m evee.cli.main'.
