"""Pydantic configuration models for Evee.

This module provides strongly-typed configuration models with validation
and automatic environment variable binding via pydantic-settings.
"""

import os
import re
from typing import Annotated, Any, Self

import yaml
from pydantic import BaseModel, BeforeValidator, ConfigDict, Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic_settings.sources import PydanticBaseSettingsSource


def _empty_str_to_none(v: Any) -> Any:
    """Coerce empty string to None, pass through other values unchanged."""
    return None if v == "" else v


# For optional int fields bound to env vars: coerce "" to None before validation (pydantic-settings reads unset vars as "")
EmptyStrToNoneInt = Annotated[int | None, BeforeValidator(_empty_str_to_none)]

# POSIX-style env var pattern: ${VAR}, ${VAR:-default}, ${VAR-default}
_ENV_VAR_PATTERN = re.compile(r"\$\{(?P<name>[A-Za-z_][A-Za-z0-9_]*)(?:(?P<op>:-|-)(?P<arg>.*?))?\}")


def _resolve_env_vars(value: str) -> str:
    """Replace POSIX-style env var references in a string.

    Supported syntax:
        ${VAR}          - Required (error if unset)
        ${VAR:-default} - Use default if VAR is unset or empty
        ${VAR-default}  - Use default only if VAR is unset

    Args:
        value: String potentially containing env var references.

    Returns:
        String with env vars resolved.

    Raises:
        ValueError: If a required env var is missing.
    """

    def _replace(m: re.Match[str]) -> str:
        name = m.group("name")
        op = m.group("op")
        arg = m.group("arg") or ""

        is_set = name in os.environ
        v = os.environ.get(name, "")

        if op is None:
            if not is_set:
                raise ValueError(f"Missing required env var: {name}")
            return v
        if op == ":-":
            return v if (is_set and v != "") else arg
        if op == "-":
            return v if is_set else arg

        return m.group(0)

    return _ENV_VAR_PATTERN.sub(_replace, value)


def _interpolate_env_vars(value: Any) -> Any:
    """Recursively interpolate env vars in a config structure.

    Args:
        value: A config value (string, dict, list, or primitive).

    Returns:
        The value with environment variables interpolated.
    """
    if isinstance(value, str):
        return _resolve_env_vars(value)
    if isinstance(value, dict):
        return {k: _interpolate_env_vars(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_interpolate_env_vars(item) for item in value]
    return value


class ExtrasConsumingModel(BaseModel):
    """
    Base for config models that are constructed from another model's extras.

    Use this as a base class for typed configuration models that need to
    parse their fields from a permissive model (one with extra="allow").
    """

    @classmethod
    def from_extras(cls, source: BaseModel) -> Self:
        """
        Construct this model from another model's extras and matching attributes.

        Behavior:
        - If the consumer model has extra="allow", all extras are passed through.
        - Otherwise, only fields defined on the consumer model are copied.
        - Explicit attributes on the source override extras (except None values).
        - Nested Pydantic models are converted to dicts for re-validation.
        """
        extras = getattr(source, "model_extra", None) or {}
        field_names = set(cls.model_fields)

        data: dict[str, Any] = {}

        # Dynamic behavior based on consumer's extra policy
        if cls.model_config.get("extra") == "allow":
            data.update(extras)
        else:
            for k, v in extras.items():
                if k in field_names:
                    data[k] = v

        # Overlay explicit attributes from the source model
        for name in field_names:
            if hasattr(source, name):
                val = getattr(source, name)
                if val is not None:
                    # Convert nested Pydantic models to dicts for re-validation
                    if isinstance(val, BaseModel):
                        data[name] = val.model_dump()
                    else:
                        data[name] = val

        return cls.model_validate(data)


class ConnectionConfig(BaseModel):
    """Configuration for a single AI model connection (e.g., Azure OpenAI endpoint)."""

    model_config = ConfigDict(extra="allow")

    name: str


class DatasetConfig(BaseModel):
    """Dataset configuration."""

    model_config = ConfigDict(extra="allow")

    name: str
    type: str
    version: str = "1.0.0"
    args: dict[str, Any] = Field(default_factory=dict)


class MetricConfig(BaseModel):
    """Configuration for a single metric.

    Uses extra="allow" to support metric-specific fields like rouge_type,
    chat_connection_name, etc.
    """

    model_config = ConfigDict(extra="allow")

    name: str
    mapping: dict[str, str] = Field(default_factory=dict)


class ModelVariantConfig(BaseModel):
    """Configuration for a model variant with hyperparameter grid.

    The args field contains a list of dictionaries, where each dictionary
    maps parameter names to lists of values for grid search.
    """

    model_config = ConfigDict(extra="allow")

    name: str
    args: list[dict[str, list[Any]]] = Field(default_factory=list)


class WorkspaceConfig(BaseModel):
    """Azure ML workspace configuration."""

    tenant_id: str
    name: str
    resource_group: str
    subscription_id: str
    client_id: str | None = None


class ComputeTargetConfig(BaseModel):
    """Azure ML compute target configuration."""

    name: str
    size: str = "STANDARD_DS3_v2"
    location: str = "swedencentral"
    min_instances: int = 0
    max_instances: int = 4
    idle_time_before_scale_down: int = 3600
    tier: str = "Dedicated"


class EnvironmentConfig(BaseModel):
    """Azure ML environment configuration.

    Uses extra="allow" to support backend-specific fields like auto_version
    that can be accessed via ExtrasConsumingModel.from_extras().
    """

    model_config = ConfigDict(extra="allow")

    name: str
    version: str = "1.0.0"


class ExecutionConfig(BaseModel):
    """Custom execution configuration for compute backends."""

    model_config = ConfigDict(extra="allow")

    setup_command: str | None = None
    run_prefix: str | None = None


class ComputeBackendConfig(BaseModel):
    """Compute backend configuration."""

    model_config = ConfigDict(extra="allow")

    type: str = "local"
    workspace: WorkspaceConfig | None = None
    pyproject_file: str = "pyproject.toml"
    stream_remote_logs: bool = False
    compute_target: ComputeTargetConfig | None = None
    environment: EnvironmentConfig | None = None
    working_directory: str | None = None
    execution: ExecutionConfig | None = None


class TrackingBackendConfig(BaseModel):
    """Tracking backend configuration."""

    model_config = ConfigDict(extra="allow")

    type: str | None = None
    enabled: bool = True
    workspace: WorkspaceConfig | None = None
    tracking_uri: str | None = None
    log_metadata_as_tags: bool = True
    experiment_name: str | None = None
    telemetry_enabled: bool = True


class RuntimeConfig(BaseModel):
    """Runtime environment configuration.

    Controls how the experiment runtime environment is detected and used.
    """

    python_executable: str | None = Field(
        default=None,
        description=(
            "Optional path to the Python interpreter to use when running the experiment. "
            "If unset, Evee will auto-detect the runtime environment (e.g., project .venv, "
            "venv, or system Python). Set this when you need to force a specific Python "
            "executable instead of relying on auto-detection. Both absolute and relative "
            "paths are supported; relative paths are resolved from the project directory. "
            "Environment variable substitution is supported using POSIX-style syntax: "
            "${VAR}, ${VAR:-default}, ${VAR-default}."
        ),
    )


class ExperimentConfig(BaseModel):
    """Experiment configuration section.

    This contains all experiment-related settings including models,
    datasets, metrics, and backend configurations.
    """

    model_config = ConfigDict(extra="allow")

    name: str
    version: str = "1.0"
    description: str = ""
    output_path: str = "experiment/output"
    max_workers: EmptyStrToNoneInt = None
    telemetry_enabled: bool = True

    runtime: RuntimeConfig = Field(default_factory=RuntimeConfig)
    tracking_backend: TrackingBackendConfig = Field(default_factory=TrackingBackendConfig)
    compute_backend: ComputeBackendConfig = Field(default_factory=ComputeBackendConfig)
    models: list[ModelVariantConfig] = Field(default_factory=list)
    dataset: DatasetConfig | None = None
    metrics: list[MetricConfig] = Field(default_factory=list)
    connections: list[ConnectionConfig] = Field(default_factory=list)


class Config(BaseSettings):
    """Root configuration container with environment variable support.

    Environment variables are automatically bound using the EVEE_ prefix
    with double-underscore as nested delimiter.

    Examples:
        EVEE_EXPERIMENT__NAME="My Experiment"
        EVEE_EXPERIMENT__MAX_WORKERS=8
        EVEE_EXPERIMENT__TRACKING_BACKEND__ENABLED=false

    For connections that need secrets, use environment variables:
        AZURE_OPENAI_ENDPOINT="https://..."
        AZURE_OPENAI_API_KEY="sk-..."
    """

    model_config = SettingsConfigDict(
        env_prefix="EVEE_",
        env_nested_delimiter="__",
        extra="allow",
    )

    experiment: ExperimentConfig

    @classmethod
    def settings_customise_sources(
        cls,
        _settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        """Customize settings sources to prioritize environment variables.

        This ensures env vars override values from YAML/dict, which is the
        expected behavior for configuration management.

        Priority (highest to lowest):
            1. Environment variables
            2. Init kwargs (from YAML/dict)
            3. Dotenv files
            4. Secret files
        """
        return (env_settings, init_settings, dotenv_settings, file_secret_settings)

    @classmethod
    def from_yaml(cls, path: str) -> Self:
        """Load configuration from a YAML file.

        Supports POSIX-style environment variable interpolation:
            ${VAR}          - Required (error if unset)
            ${VAR:-default} - Use default if VAR is unset or empty
            ${VAR-default}  - Use default if VAR is unset

        Additionally, any config value can be overridden via environment
        variables using the EVEE_ prefix with __ as nested delimiter:
            EVEE_EXPERIMENT__NAME="Override Name"

        Args:
            path: Path to the YAML configuration file.

        Returns:
            Validated Config instance.

        Raises:
            FileNotFoundError: If the config file doesn't exist.
            ValidationError: If the config doesn't match the schema.
            ValueError: If a required env var is missing or if the YAML file is empty.
        """
        with open(path) as f:
            data = yaml.safe_load(f)
        if data is None:
            raise ValueError(f"Configuration file '{path}' is empty or contains only comments")
        data = _interpolate_env_vars(data)
        return cls(**data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Self:
        """Load configuration from a dictionary.

        Useful for testing and programmatic config creation.

        Args:
            data: Configuration dictionary.

        Returns:
            Validated Config instance.
        """
        return cls(**data)

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary.

        Returns:
            Dictionary representation of the configuration.
        """
        return self.model_dump()

    @model_validator(mode="after")
    def propagate_experiment_name(self) -> Self:
        """Propagate experiment name to tracking backend if not set."""
        if self.experiment.tracking_backend.experiment_name is None:
            self.experiment.tracking_backend.experiment_name = self.experiment.name
        if hasattr(self.experiment, "telemetry_enabled"):
            self.experiment.tracking_backend.telemetry_enabled = self.experiment.telemetry_enabled
        return self


# Backward compatibility alias
EveeConfig = Config
