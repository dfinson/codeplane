"""Dataset factory for creating dataset instances based on type."""

from typing import Any

from ..core.base_dataset import DATASET_REGISTRY, BaseDataset
from ..core.execution_context import ExecutionContext
from ..logging.logger import setup_logger
from . import BUILTIN_DATASET_TYPES


class DatasetFactory:
    """Factory class for creating dataset instances."""

    def __init__(self):
        """Initialize the dataset factory."""
        self.logger = setup_logger(self.__class__.__module__)

    def create_dataset(
        self,
        dataset_type: str,
        args: dict[str, Any] | None = None,
        context: ExecutionContext | None = None,
        dataset_name: str | None = None,
    ) -> BaseDataset:
        """Create a dataset instance by looking up the dataset type in the registry.

        Args:
            dataset_type: Type of the dataset (e.g., 'csv', 'jsonl', 'custom')
            args: Configuration arguments for the dataset
            context: Optional execution context with experiment info
            dataset_name: Registry name of the dataset (used for custom datasets)
        """
        args = args or {}

        # For built-in types, look up by type; for custom datasets, look up by name
        if dataset_type in BUILTIN_DATASET_TYPES:
            lookup_key = dataset_type
        elif dataset_type == "custom":
            if not dataset_name:
                raise ValueError(f"'dataset_name' is required for custom dataset type '{dataset_type}'. Built-in types are: {sorted(BUILTIN_DATASET_TYPES)}.")
            lookup_key = dataset_name
        else:
            raise ValueError(f"Unsupported dataset type '{dataset_type}'. Built-in types are: {sorted(BUILTIN_DATASET_TYPES)}.")

        dataset_class = DATASET_REGISTRY.get(lookup_key)
        if not dataset_class:
            available_datasets = list(DATASET_REGISTRY.keys())
            raise ValueError(f"Dataset '{lookup_key}' not found in registry. Available datasets: {available_datasets}. Ensure the dataset is decorated with @dataset(name='{lookup_key}') and imported.")

        return dataset_class(args, context)
