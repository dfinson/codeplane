from . import csv_dataset, jsonl_dataset  # noqa: F401

BUILTIN_DATASET_TYPES = frozenset({"csv", "jsonl"})
