"""JSONL dataset implementation using pandas."""

from collections.abc import Iterator
from pathlib import Path

import pandas as pd

from ..core.base_dataset import dataset
from ..logging.logger import setup_logger


@dataset(name="jsonl")
class JSONLDataset:
    """JSONL dataset loader using pandas."""

    def __init__(self, data_path: str):
        """Initialize JSONL dataset.

        Args:
            data_path: Path to JSONL file
        """
        self.logger = setup_logger(self.__class__.__module__)
        self.path = data_path

        try:
            if not Path(self.path).exists():
                raise FileNotFoundError(f"JSONL file not found: {self.path}")
            self._df = pd.read_json(self.path, lines=True)
            self.logger.debug(f"Loaded {len(self._df)} records from {self.path}")
        except Exception:
            self.logger.exception(f"Failed to load JSONL: {self.path}")
            raise

    def __iter__(self) -> Iterator[dict]:
        """Yield records as dictionaries."""
        for row in self._df.itertuples(index=False):
            yield row._asdict()

    def __len__(self) -> int:
        """Return number of records."""
        return len(self._df)
