from importlib.metadata import entry_points

from dotenv import load_dotenv

from evee.compute.backend import JobInfo, RunContext
from evee.config import ComputeBackendConfig, Config
from evee.execution.preflight import run_preflight_checks
from evee.logging.logger import setup_logger


class ExperimentRunner:
    def __init__(self):
        self.logger = setup_logger(self.__class__.__module__)

    def run(
        self,
        config_path: str,
        env_path: str = None,
        dataset_path: str = None,
        remote_compute: bool = False,
        tracking_enabled: bool = True,
        interactive: bool = True,
        stream_remote_logs: bool = False,
        download_path: str | None = None,
        model_filter: list[str] | None = None,
        **kwargs,
    ) -> JobInfo:
        if env_path:
            load_dotenv(dotenv_path=env_path, override=True)

        run_preflight_checks(config_path, tracking_enabled, interactive, remote_compute, model_filter)

        config = Config.from_yaml(config_path)
        backend_config = None

        if remote_compute:
            backend_config = getattr(getattr(config, "experiment", None), "compute_backend", None)
            backend_type = getattr(backend_config, "type", None)

            if not backend_config or backend_type == "local":
                raise ValueError("Remote execution requested (--remote), but no remote compute backend is configured. Configure a remote backend (e.g., 'azureml') under 'compute_backend' in your config.yaml.")

            self.logger.info(f"Using configured remote compute backend: {backend_config.type}")
        else:
            # Default to local execution
            self.logger.debug("Running locally.")
            backend_config = ComputeBackendConfig(type="local")

        backend_type = backend_config.type
        backend_class = self._get_backend_class(backend_type)

        backend = backend_class(config=config)

        context = RunContext(
            config_path=config_path,
            env_path=env_path,
            dataset_path=dataset_path,
            tracking_enabled=tracking_enabled,
            stream_remote_logs=stream_remote_logs,
            download_path=download_path,
            model_filter=model_filter,
        )

        return backend.submit(context, **kwargs)

    def _get_backend_class(self, backend_type: str):
        eps = entry_points(group="evee.compute_backends")
        for ep in eps:
            if ep.name == backend_type:
                return ep.load()
        raise ValueError(f"Compute backend type '{backend_type}' not found. Is the correct evee extension package installed?")
