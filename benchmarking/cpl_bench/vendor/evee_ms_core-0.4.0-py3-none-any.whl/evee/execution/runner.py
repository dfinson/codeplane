"""Generic execution runner for evee commands in project-specific environments."""

import codecs
import contextlib
import logging
import os
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass

from .environment import EnvironmentResolver

logger = logging.getLogger(__name__)

# Constants for process management
PROCESS_TERMINATION_TIMEOUT_SECONDS = 5
"""Time to wait for graceful SIGTERM shutdown before sending SIGKILL."""

PTY_READ_BUFFER_SIZE = 4096
"""Buffer size for reading from PTY/pipes."""

PTY_POLL_TIMEOUT_SECONDS = 0.1
"""Timeout for select() when polling PTY for data."""

# Check for PTY support (not available on Windows)
try:
    import fcntl
    import pty
    import select
    import struct
    import termios

    HAS_PTY_SUPPORT = True
except ImportError:
    HAS_PTY_SUPPORT = False


@dataclass
class StreamingResult:
    """Result from streaming execution, compatible with subprocess.CompletedProcess interface.

    This provides a consistent interface whether execution used PTY or pipes.
    """

    returncode: int
    stdout: str
    stderr: str


class ExecutionResult:
    """Result of executing an evee command."""

    def __init__(
        self,
        returncode: int,
        stdout: str,
        stderr: str,
        duration: float,
        command: list[str],
    ):
        """Initialize execution result.

        Args:
            returncode: Process exit code (0 for success)
            stdout: Standard output from the process
            stderr: Standard error from the process
            duration: Execution time in seconds
            command: The command that was executed
        """
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        self.duration = duration
        self.command = command

    @property
    def success(self) -> bool:
        """Check if execution was successful."""
        return self.returncode == 0

    def __repr__(self) -> str:
        return f"ExecutionResult(returncode={self.returncode}, duration={self.duration:.2f}s, success={self.success})"


class ExecutionRunner:
    """Execute evee commands in project-specific Python environments.

    This runner provides a GENERIC interface - it doesn't know about specific
    commands like 'evaluate', 'validate', etc. It just runs:

        python -m evee.cli.main <cli_args>

    in the detected project environment. This design ensures zero runner changes
    when adding new CLI commands.

    Examples:
        runner = ExecutionRunner()

        # Run any evee command generically
        result = runner.execute('/path/to/project', ['--help'])
        result = runner.execute('/path/to/project', ['--version'])
        result = runner.execute('/path/to/project', ['evaluate', '--config', 'config.yaml'])
        result = runner.execute('/path/to/project', ['validate', 'config.yaml'])

        # Stream output in real-time (for CLI)
        def on_output(line: str):
            print(line, end='')

        result = runner.execute(
            '/path/to/project',
            ['evaluate', '--config', 'config.yaml'],
            output_callback=on_output
        )
    """

    def __init__(self, resolver: EnvironmentResolver | None = None):
        """Initialize the execution runner.

        Args:
            resolver: Environment resolver instance. If None, creates a new one.
        """
        self.resolver = resolver or EnvironmentResolver()

    def execute(
        self,
        project_path: str,
        cli_args: list[str],
        output_callback: Callable[[str], None] | None = None,
        env_vars: dict[str, str] | None = None,
        config_path: str | None = None,
        config_explicit: bool = False,
        timeout: float | None = None,
    ) -> ExecutionResult:
        """Execute an evee CLI command in the project's Python environment.

        This is the GENERIC execution method - it doesn't know about specific
        commands. It just runs: python -m evee.cli.main <cli_args>

        Args:
            project_path: Absolute path to the project directory
            cli_args: CLI arguments to pass (e.g., ['--help'], ['evaluate', '--config', 'config.yaml'])
            output_callback: Optional callback for streaming output line-by-line (enables streaming mode)
            env_vars: Optional environment variables to set for execution
            config_path: Optional path to config file for python_executable override (can be relative to project_path)
            config_explicit: Whether --config was explicitly provided (fail loudly on parse errors)
            timeout: Optional timeout in seconds for command execution (blocking mode only)

        Returns:
            ExecutionResult with returncode, stdout, stderr, and duration

        Raises:
            ProjectEnvironmentError: If environment detection or validation fails
        """
        project_path = os.path.abspath(project_path)

        # Convert relative config_path to absolute (relative to project_path)
        # This is needed because detect_python checks os.path.isfile(config_path)
        abs_config_path = None
        if config_path:
            abs_config_path = config_path if os.path.isabs(config_path) else os.path.join(project_path, config_path)

        # Detect Python executable for this project
        python_exe = self.resolver.detect_python(project_path, config_path=abs_config_path, config_explicit=config_explicit)

        # Validate evee is installed in the detected environment
        self.resolver.validate_evee_installation(python_exe)

        # Build the command: python -m evee.cli.main <cli_args>
        command = [python_exe, "-m", "evee.cli.main", *cli_args]

        logger.debug(f"Executing command in project environment: {' '.join(command[:3])} ...")
        logger.debug(f"Working directory: {project_path}")

        start_time = time.time()

        # Prepare environment variables
        env = os.environ.copy()
        if env_vars:
            env.update(env_vars)

        # Default to direct execution mode to prevent CLI from re-delegating,
        # but allow callers/environment to override EVEE_EXECUTION_MODE if needed.
        env.setdefault("EVEE_EXECUTION_MODE", "direct")

        # Use streaming mode if output_callback is provided, otherwise blocking mode
        if output_callback:  # noqa: SIM108 - explicit if/else is more readable than ternary here
            if timeout is not None:
                logger.warning("Timeout parameter is ignored in streaming mode; timeout currently applies only in blocking mode.")
            result = self._execute_streaming(command, project_path, output_callback, env)
        else:
            result = self._execute_blocking(command, project_path, env, timeout)

        duration = time.time() - start_time

        if result.returncode == 0:
            logger.debug(f"Command completed successfully in {duration:.2f}s")
        else:
            logger.warning(f"Command failed with exit code {result.returncode} after {duration:.2f}s")

        return ExecutionResult(
            returncode=result.returncode,
            stdout=result.stdout or "",
            stderr=result.stderr or "",
            duration=duration,
            command=command,
        )

    def _execute_blocking(self, command: list[str], cwd: str, env: dict[str, str], timeout: float | None = None) -> subprocess.CompletedProcess[str]:
        """Execute command in blocking mode (wait for completion).

        Used by MCP server and other non-interactive clients that want
        the full output after the command completes.

        Args:
            command: Command and arguments to execute
            cwd: Working directory for the command
            env: Environment variables for the subprocess
            timeout: Optional timeout in seconds (None for no timeout)

        Returns:
            CompletedProcess with returncode, stdout, and stderr
        """
        return subprocess.run(
            command,
            cwd=cwd,
            capture_output=True,
            text=True,
            env=env,
            timeout=timeout,
        )

    def _execute_streaming(
        self,
        command: list[str],
        cwd: str,
        output_callback: Callable[[str], None] | None,
        env: dict[str, str],
    ) -> StreamingResult:
        """Execute command with streaming output.

        Uses PTY on Unix for proper terminal emulation (tqdm progress bars, etc.),
        with automatic fallback to pipes on Windows or when PTY is unavailable.

        Args:
            command: Command and arguments to execute
            cwd: Working directory for the command
            output_callback: Callback invoked for each chunk of output
            env: Environment variables for the subprocess

        Returns:
            StreamingResult with returncode, stdout, and stderr
        """
        if HAS_PTY_SUPPORT:
            try:
                return self._execute_with_pty(command, cwd, output_callback, env)
            except OSError as e:
                logger.debug(f"PTY execution failed, falling back to pipes: {e}")

        # Fallback to pipe-based execution (Windows or PTY failure)
        return self._execute_with_pipes(command, cwd, output_callback, env)

    def _execute_with_pty(
        self,
        command: list[str],
        cwd: str,
        output_callback: Callable[[str], None] | None,
        env: dict[str, str],
    ) -> StreamingResult:
        """Execute using PTY for proper terminal emulation.

        PTY (pseudo-terminal) allows commands like tqdm to detect they're
        running in a terminal and use carriage returns for progress bar updates.

        Args:
            command: Command and arguments to execute
            cwd: Working directory for the command
            output_callback: Callback invoked for each chunk of output
            env: Environment variables for the subprocess

        Returns:
            StreamingResult with combined stdout (stderr merged via PTY)
        """
        # Create a pseudo-terminal pair
        master_fd, slave_fd = pty.openpty()

        # Set PTY size to match parent terminal (avoid wrapping at 80 columns)
        try:
            # Get current terminal size from stdout
            size = os.get_terminal_size()
            # Set the PTY window size using TIOCSWINSZ ioctl
            # Format: struct winsize { unsigned short ws_row, ws_col, ws_xpixel, ws_ypixel }
            winsize = struct.pack("HHHH", size.lines, size.columns, 0, 0)
            fcntl.ioctl(master_fd, termios.TIOCSWINSZ, winsize)
        except (OSError, AttributeError):
            # Failed to get/set terminal size - continue with defaults
            pass

        try:
            process = subprocess.Popen(
                command,
                cwd=cwd,
                stdin=slave_fd,  # Connect stdin to PTY for interactive prompts
                stdout=slave_fd,
                stderr=slave_fd,  # Merge stderr into stdout via PTY
                env=env,
                close_fds=True,
            )

            # Close slave FD in parent - only child process needs it
            os.close(slave_fd)
            slave_fd = None  # Mark as closed to avoid double-close in finally

            output_lines: list[str] = []

            # Use an incremental decoder to handle multi-byte UTF-8 sequences
            decoder = codecs.getincrementaldecoder("utf-8")("replace")

            try:
                # Read from PTY and forward stdin until process completes
                while True:
                    if process.poll() is not None:
                        # Process finished - drain any remaining output
                        self._drain_fd(master_fd, output_lines, output_callback, decoder)
                        break

                    # Wait for data from PTY and optionally stdin (for interactive prompts)
                    # Only monitor stdin if we're in an interactive terminal
                    fds_to_read = [master_fd]
                    if sys.stdin.isatty():
                        fds_to_read.append(0)  # 0 is sys.stdin

                    readable, _, _ = select.select(fds_to_read, [], [], PTY_POLL_TIMEOUT_SECONDS)

                    if master_fd in readable:
                        try:
                            raw = os.read(master_fd, PTY_READ_BUFFER_SIZE)
                            if not raw:
                                break  # EOF
                            data = decoder.decode(raw)
                            if data:
                                output_lines.append(data)
                                if output_callback:
                                    output_callback(data)
                        except OSError:
                            # PTY closed - process likely exited
                            break

                    if 0 in readable:
                        # User typed something - forward it to the subprocess
                        try:
                            user_input = os.read(0, PTY_READ_BUFFER_SIZE)
                            if user_input:
                                os.write(master_fd, user_input)
                        except OSError:
                            pass  # stdin closed or other issue

            except KeyboardInterrupt:
                self._terminate_process(process)
                raise
            finally:
                os.close(master_fd)
                # Flush any partial UTF-8 bytes the decoder is still holding,
                # regardless of how the loop exited (poll, EOF, or OSError).
                remaining = decoder.decode(b"", final=True)
                if remaining:
                    output_lines.append(remaining)
                    if output_callback:
                        output_callback(remaining)

            # Ensure returncode is populated even if the loop exited via
            # EOF/OSError before poll() observed the exit.
            process.wait()

            return StreamingResult(
                returncode=process.returncode,
                stdout="".join(output_lines),
                stderr="",  # Merged into stdout via PTY
            )

        except Exception:
            # Clean up file descriptors on error
            with contextlib.suppress(OSError):
                os.close(master_fd)
            if slave_fd is not None:
                with contextlib.suppress(OSError):
                    os.close(slave_fd)
            raise

    def _drain_fd(
        self,
        fd: int,
        output_lines: list[str],
        output_callback: Callable[[str], None] | None,
        decoder: codecs.IncrementalDecoder,
    ) -> None:
        """Drain remaining data from a file descriptor.
        Args:
            fd: File descriptor to read from
            output_lines: List to append output to
            output_callback: Optional callback for each chunk
            decoder: Incremental UTF-8 decoder for handling split multi-byte sequences
        """
        try:
            while True:
                raw = os.read(fd, PTY_READ_BUFFER_SIZE)
                if not raw:
                    break  # EOF
                data = decoder.decode(raw)
                if data:
                    output_lines.append(data)
                    if output_callback:
                        output_callback(data)
        except OSError:
            pass  # EOF or FD closed

    def _execute_with_pipes(
        self,
        command: list[str],
        cwd: str,
        output_callback: Callable[[str], None] | None,
        env: dict[str, str],
    ) -> StreamingResult:
        """Execute using pipes (fallback for Windows and tests).

        This method provides streaming output without PTY support.
        Note: Progress bars using carriage returns won't display correctly.

        Uses threading to read from stdout and stderr concurrently to avoid deadlock
        when one pipe's buffer fills up while waiting to read from the other.

        Args:
            command: Command and arguments to execute
            cwd: Working directory for the command
            output_callback: Callback invoked for each line of output
            env: Environment variables for the subprocess

        Returns:
            StreamingResult with stdout and stderr captured separately
        """
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,  # Line buffered
            env=env,
        )

        stdout_lines: list[str] = []
        stderr_lines: list[str] = []

        def read_stdout():
            """Read stdout in a separate thread to avoid deadlock."""
            if process.stdout:
                for line in process.stdout:
                    stdout_lines.append(line)
                    if output_callback:
                        output_callback(line)

        def read_stderr():
            """Read stderr in a separate thread to avoid deadlock."""
            if process.stderr:
                for line in process.stderr:
                    stderr_lines.append(line)
                    if output_callback:
                        output_callback(line)

        # Create threads to read from both pipes concurrently
        # Non-daemon threads ensure they complete reading before process exit
        # Using non-daemon threads prevents loss of output when process terminates
        # but requires explicit cleanup on interruption to avoid orphaned threads
        stdout_thread = threading.Thread(target=read_stdout, daemon=False)
        stderr_thread = threading.Thread(target=read_stderr, daemon=False)

        try:
            # Start both reading threads
            stdout_thread.start()
            stderr_thread.start()

            # Wait for process to complete
            process.wait()

            # Wait for both threads to finish reading
            stdout_thread.join()
            stderr_thread.join()

        except KeyboardInterrupt:
            self._terminate_process(process)
            # Wait for threads to finish after termination
            # Use timeout to avoid hanging forever, but ensure cleanup
            stdout_thread.join(timeout=1)
            stderr_thread.join(timeout=1)

            # If threads are still alive, close pipes to force them to exit
            # This prevents orphaned threads and resource leaks
            if stdout_thread.is_alive() or stderr_thread.is_alive():
                if process.stdout:
                    process.stdout.close()
                if process.stderr:
                    process.stderr.close()
                # Give threads a moment to exit after pipe closure
                stdout_thread.join(timeout=0.5)
                stderr_thread.join(timeout=0.5)

                # If threads are still alive after pipe closure and additional wait,
                # log a warning so operators are aware of potential orphaned threads.
                stdout_alive = stdout_thread.is_alive()
                stderr_alive = stderr_thread.is_alive()
                if stdout_alive or stderr_alive:
                    logger.warning(
                        "Reader threads did not terminate after KeyboardInterrupt cleanup; stdout_alive=%s, stderr_alive=%s",
                        stdout_alive,
                        stderr_alive,
                    )
            raise
        finally:
            # Ensure pipes are always closed for proper cleanup
            # Safe to call multiple times (idempotent)
            if process.stdout:
                process.stdout.close()
            if process.stderr:
                process.stderr.close()

        return StreamingResult(
            returncode=process.returncode or 0,
            stdout="".join(stdout_lines),
            stderr="".join(stderr_lines),
        )

    def _terminate_process(self, process: subprocess.Popen) -> None:
        """Gracefully terminate a process.

        First sends SIGTERM and waits for graceful shutdown.
        If the process doesn't terminate within the timeout, sends SIGKILL.

        Args:
            process: The subprocess to terminate
        """
        if process.poll() is not None:
            return  # Already terminated

        try:
            # Send SIGTERM for graceful shutdown
            process.terminate()

            # Wait for process to exit gracefully
            try:
                process.wait(timeout=PROCESS_TERMINATION_TIMEOUT_SECONDS)
            except subprocess.TimeoutExpired:
                # Force kill if still running after timeout
                logger.debug("Process did not terminate gracefully, sending SIGKILL")
                process.kill()
                process.wait()
        except Exception as e:
            # Best effort cleanup - log but don't raise
            logger.debug(f"Error during process termination: {e}")

    # ========================================================================
    # MCP Server Helper Methods
    # ========================================================================
    # These are convenience wrappers around execute() for the MCP server.
    # They call the generic execute() method with appropriate CLI arguments.

    def run_evaluation(
        self,
        project_path: str,
        config_path: str = "experiment/config.yaml",
        env_path: str = ".env",
        dataset_path: str | None = None,
        stream_output: bool = False,
        output_callback: Callable[[str], None] | None = None,
        env_vars: dict[str, str] | None = None,
    ) -> dict:
        """Run an evaluation workflow.

        Args:
            project_path: Absolute path to the project directory
            config_path: Path to config file relative to project_path
            env_path: Path to .env file relative to project_path
            dataset_path: Optional path to dataset file (overrides config)
            stream_output: Whether to stream output in real-time
            output_callback: Optional callback for streaming output
            env_vars: Optional dictionary of environment variables to set for the subprocess execution
            output_callback: Optional callback for streaming output

        Returns:
            Evaluation result dictionary

        Raises:
            ProjectEnvironmentError: If environment detection fails
        """
        # Detect the evee version from the project environment before execution
        evee_version = self._get_project_evee_version(project_path, config_path)

        # Build CLI arguments for 'evee run' command
        cli_args = ["run", "--config", config_path, "--env", env_path]
        if dataset_path:
            cli_args.extend(["--dataset", dataset_path])

        # Execute the command
        result = self.execute(
            project_path=project_path,
            cli_args=cli_args,
            output_callback=output_callback if stream_output else None,
            config_path=config_path,
            env_vars=env_vars,
        )

        # Parse and return result
        if result.success:
            # Try to parse JSON output from stdout
            try:
                import json

                parsed = json.loads(result.stdout)
                parsed["evee_version"] = evee_version
                return parsed
            except json.JSONDecodeError:
                # If not JSON, return as plain text result
                return {
                    "status": "success",
                    "message": result.stdout,
                    "duration_seconds": result.duration,
                    "evee_version": evee_version,
                }
        else:
            return {
                "status": "error",
                "error_type": "execution",
                "message": result.stderr or result.stdout,
                "returncode": result.returncode,
                "evee_version": evee_version,
            }

    def _get_project_evee_version(self, project_path: str, config_path: str | None = None) -> str:
        """Get the evee version installed in the project's Python environment.

        This detects the version from the project's venv, not the global/MCP
        server environment, so users can verify which evee version actually ran.

        Args:
            project_path: Absolute path to the project directory
            config_path: Optional path to config file for python_executable override (can be relative to project_path)

        Returns:
            Version string (e.g., "0.1.3") or "unknown" if detection fails
        """
        try:
            # Convert relative config_path to absolute (relative to project_path)
            abs_config_path = None
            if config_path:
                abs_config_path = config_path if os.path.isabs(config_path) else os.path.join(project_path, config_path)

            python_exe = self.resolver.detect_python(project_path, config_path=abs_config_path)
            return self.resolver._get_evee_version(python_exe)
        except Exception as e:
            logger.debug(f"Failed to detect project evee version: {e}")
            return "unknown"

    def validate_config(
        self,
        project_path: str,
        config_path: str = "experiment/config.yaml",
        env_path: str = ".env",
    ) -> dict:
        """Validate experiment configuration.

        Args:
            project_path: Absolute path to the project directory
            config_path: Path to config file relative to project_path
            env_path: Path to .env file relative to project_path

        Returns:
            Validation result dictionary with 'valid', 'errors', 'warnings', etc.

        Raises:
            ProjectEnvironmentError: If environment detection fails
        """
        # Build CLI arguments for 'evee validate' command with JSON output
        cli_args = ["validate", config_path, "--env", env_path, "--json"]

        # Execute the command
        result = self.execute(
            project_path=project_path,
            cli_args=cli_args,
            config_path=config_path,
        )

        # Parse and return result
        if result.success:
            try:
                import json

                return json.loads(result.stdout)
            except json.JSONDecodeError:
                # If not JSON, assume valid if command succeeded
                return {
                    "valid": True,
                    "errors": [],
                    "warnings": [],
                    "message": result.stdout,
                }
        else:
            return {
                "valid": False,
                "errors": [result.stderr or result.stdout],
                "warnings": [],
            }

    def discover_components(
        self,
        project_path: str,
        component_type: str = "all",
    ) -> dict:
        """Discover models, metrics, and datasets via decorator scanning.

        Args:
            project_path: Absolute path to the project directory
            component_type: Type of components to discover ('all', 'models', 'metrics', 'datasets')

        Returns:
            Dictionary with 'models', 'metrics', 'datasets' lists and optional 'discovery_warnings'

        Raises:
            ProjectEnvironmentError: If environment detection fails
        """
        # Build CLI arguments for 'evee list' command with JSON output
        cli_args = ["list", "--json"]
        if component_type != "all":
            cli_args.extend(["--type", component_type])

        # Execute the command
        result = self.execute(
            project_path=project_path,
            cli_args=cli_args,
        )

        # Parse and return result
        if result.success:
            try:
                import json

                return json.loads(result.stdout)
            except json.JSONDecodeError:
                # If not JSON, return empty lists
                return {
                    "models": [],
                    "metrics": [],
                    "datasets": [],
                    "discovery_warnings": ["Failed to parse component list output"],
                }
        else:
            return {
                "models": [],
                "metrics": [],
                "datasets": [],
                "discovery_warnings": [result.stderr or result.stdout],
            }
