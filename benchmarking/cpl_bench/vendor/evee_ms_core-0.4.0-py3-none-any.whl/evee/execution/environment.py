"""Environment detection and validation for project-specific Python environments."""

import logging
import os
import re
import subprocess
import sys
from typing import TypedDict

import yaml

logger = logging.getLogger(__name__)

# POSIX-style env var pattern for lightweight extraction
_ENV_VAR_PATTERN = re.compile(r"\$\{(?P<name>[A-Za-z_][A-Za-z0-9_]*)(?:(?P<op>:-|-)(?P<arg>.*?))?\}")

# Constants for environment detection
VENV_DIRECTORY_NAMES = (".venv", "venv", "env")
"""Virtual environment directory names to check, in priority order."""

SUBPROCESS_TIMEOUT_SECONDS = 5
"""Timeout for subprocess calls (e.g., checking Python version)."""


class EnvironmentInfo(TypedDict):
    """Type definition for environment information dictionary."""

    python_version: str
    evee_version: str
    env_type: str
    path: str


class ProjectEnvironmentError(Exception):
    """Raised when environment detection or validation fails."""

    pass


class EnvironmentResolver:
    """Auto-detect and validate Python environments for evee projects.

    Detection order:
    1. Explicit config override (if config_path provided -> runtime.python_executable)
    2. Project venv directories (.venv, venv, env)
    3. System Python (fallback)
    """

    def __init__(self):
        """Initialize the environment resolver."""
        self._warned_system_fallback = False

    def detect_python(self, project_path: str, config_path: str | None = None, config_explicit: bool = False) -> str:
        """Detect the Python executable for a project.

        Args:
            project_path: Absolute path to the project directory
            config_path: Optional absolute path to config file for python_executable override
            config_explicit: Whether --config was explicitly provided (fail loudly on parse errors)

        Returns:
            Absolute path to the Python executable

        Raises:
            ProjectEnvironmentError: If no valid Python environment is found
        """
        project_path = os.path.abspath(project_path)

        # Try detection strategies in order
        python_exe = (
            self._check_config_override(config_path, config_explicit)  # Use provided config path
            or self._check_venv_dirs(project_path)
            or self._fallback_system_python()
        )

        # Note: python_exe is never None because _fallback_system_python() always returns sys.executable
        # Validate the executable exists
        if not os.path.isfile(python_exe):
            raise ProjectEnvironmentError(f"Detected Python executable does not exist: {python_exe}")

        # Log environment type
        env_type = self._determine_env_type(project_path, python_exe)
        logger.debug(f"Detected Python environment: {env_type} ({python_exe})")

        return python_exe

    def validate_evee_installation(self, python_exe: str) -> None:
        """Validate that evee is installed in the given Python environment.

        Args:
            python_exe: Path to Python executable to check

        Raises:
            ProjectEnvironmentError: If evee is not installed or cannot be imported
        """
        try:
            result = subprocess.run(
                [python_exe, "-c", "import evee; print(evee.__version__)"],
                capture_output=True,
                text=True,
                timeout=SUBPROCESS_TIMEOUT_SECONDS,
            )
            if result.returncode != 0:
                raise ProjectEnvironmentError(f"evee is not installed in the Python environment at {python_exe}.")
        except subprocess.TimeoutExpired:
            raise ProjectEnvironmentError(f"Timeout while checking evee installation in {python_exe}") from None
        except ProjectEnvironmentError:
            raise  # Re-raise our own exceptions
        except Exception as e:
            raise ProjectEnvironmentError(f"Failed to validate evee installation: {e}") from e

    def get_environment_info(self, project_path: str, config_path: str | None = None, config_explicit: bool = False) -> EnvironmentInfo:
        """Get detailed information about the detected environment.

        Args:
            project_path: Absolute path to the project directory
            config_path: Optional path to config file for python_executable override
            config_explicit: Whether --config was explicitly provided (fail loudly on parse errors)

        Returns:
            EnvironmentInfo dictionary with:
            - python_version: Python version (e.g., "3.12.1")
            - evee_version: Evee version (e.g., "0.1.3")
            - env_type: Type of environment ("config", "venv", or "system")
            - path: Path to the Python executable
        """
        python_exe = self.detect_python(project_path, config_path=config_path, config_explicit=config_explicit)

        # Get Python version
        python_version = self._get_python_version(python_exe)

        # Get evee version
        evee_version = self._get_evee_version(python_exe)

        # Determine environment type - check if from config first
        # Note: config_explicit=False here since we already validated in detect_python
        config_python = self._check_config_override(config_path, config_explicit=False)
        env_type = "config" if config_python and config_python == python_exe else self._determine_env_type(project_path, python_exe)

        return EnvironmentInfo(
            python_version=python_version,
            evee_version=evee_version,
            env_type=env_type,
            path=python_exe,
        )

    def _get_python_version(self, python_exe: str) -> str:
        """Get the Python version from an executable.

        Args:
            python_exe: Path to Python executable

        Returns:
            Version string (e.g., "3.12.1") or "unknown" on error
        """
        try:
            result = subprocess.run(
                [python_exe, "--version"],
                capture_output=True,
                text=True,
                timeout=SUBPROCESS_TIMEOUT_SECONDS,
            )
            return result.stdout.strip().replace("Python ", "")
        except Exception as e:
            logger.debug(f"Failed to get Python version: {e}")
            return "unknown"

    def _get_evee_version(self, python_exe: str) -> str:
        """Get the evee version from a Python environment.

        Args:
            python_exe: Path to Python executable

        Returns:
            Version string (e.g., "0.1.3"), "not installed", or "unknown"
        """
        try:
            result = subprocess.run(
                [python_exe, "-c", "import evee; print(evee.__version__)"],
                capture_output=True,
                text=True,
                timeout=SUBPROCESS_TIMEOUT_SECONDS,
            )
            return result.stdout.strip() if result.returncode == 0 else "not installed"
        except Exception as e:
            logger.debug(f"Failed to get evee version: {e}")
            return "unknown"

    def _resolve_env_var(self, value: str) -> str:
        """Resolve POSIX-style env var references in a string.

        Supports: ${VAR}, ${VAR:-default}, ${VAR-default}

        Args:
            value: String potentially containing env var references.

        Returns:
            String with env vars resolved.

        Raises:
            ValueError: If a required env var (${VAR}) is missing.
        """

        def _replace(m: re.Match[str]) -> str:
            name = m.group("name")
            op = m.group("op")
            arg = m.group("arg") or ""

            is_set = name in os.environ
            v = os.environ.get(name, "")

            if op is None:
                if not is_set:
                    raise ValueError(f"Missing required env var: {name}")
                return v
            if op == ":-":
                return v if (is_set and v != "") else arg
            if op == "-":
                return v if is_set else arg

            return m.group(0)

        return _ENV_VAR_PATTERN.sub(_replace, value)

    def _check_config_override(self, config_path: str | None, config_explicit: bool = False) -> str | None:
        """Check for explicit Python executable in config file.

        Uses lightweight YAML parsing to extract only runtime.python_executable
        without full config validation. This allows environment detection to work
        even when other config fields have unset required environment variables.

        Args:
            config_path: Absolute path to config file, or None to skip check
            config_explicit: Whether --config was explicitly provided by user

        Returns:
            Path to Python executable if found and valid, None otherwise

        Raises:
            ProjectEnvironmentError: If python_executable is configured but doesn't exist,
                                    or if config was explicit and parsing failed
        """
        if not config_path or not os.path.isfile(config_path):
            return None

        try:
            # Lightweight YAML parsing - only extract python_executable
            with open(config_path) as f:
                data = yaml.safe_load(f)

            if not data:
                return None

            # Navigate to experiment.runtime.python_executable
            experiment = data.get("experiment", {})
            runtime = experiment.get("runtime", {})
            python_exe_raw = runtime.get("python_executable")

            if not python_exe_raw:
                return None

            # Resolve env vars in the python_executable path
            try:
                python_exe = self._resolve_env_var(python_exe_raw)
            except ValueError as e:
                raise ProjectEnvironmentError(f"Failed to resolve environment variables in 'experiment.runtime.python_executable': {e}. Please check the setting in {config_path}") from e

            if os.path.isfile(python_exe):
                logger.debug(f"Using Python executable from config override: {python_exe}")
                return python_exe
            else:
                raise ProjectEnvironmentError(f"Configured Python executable at '{python_exe}' does not exist. Please check the 'experiment.runtime.python_executable' setting in {config_path}")

        except ProjectEnvironmentError:
            raise
        except Exception as e:
            # YAML parsing errors, malformed structure, etc.
            if config_explicit:
                # User explicitly provided --config, fail loudly
                raise ProjectEnvironmentError(f"Failed to parse config file '{config_path}': {e}. Please check for YAML syntax errors or malformed structure.") from e
            else:
                # Auto-detected config, warn and fall back to other detection methods
                logger.warning(f"Could not parse config '{config_path}': {e}. Falling back to auto-detection.")

        return None

    def _check_venv_dirs(self, project_path: str) -> str | None:
        """Check for common venv directory names.

        Checks directories in priority order: .venv, venv, env.
        Logs a warning if multiple virtual environments are found.

        Args:
            project_path: Path to the project directory

        Returns:
            Path to Python executable in first valid venv, or None
        """
        found_venvs: list[tuple[str, str]] = []

        for venv_name in VENV_DIRECTORY_NAMES:
            venv_path = os.path.join(project_path, venv_name)
            if os.path.isdir(venv_path):
                python_exe = self._get_venv_python(venv_path)
                if python_exe and os.path.isfile(python_exe):
                    found_venvs.append((venv_name, python_exe))

        if not found_venvs:
            return None

        # Log warning if multiple venvs exist
        if len(found_venvs) > 1:
            venv_names = ", ".join(name for name, _ in found_venvs)
            logger.warning(f"Multiple virtual environments found in {project_path}: {venv_names}. Using {found_venvs[0][0]}.")

        return found_venvs[0][1]

    def _get_venv_python(self, venv_path: str) -> str | None:
        """Get Python executable path from a venv directory.

        Checks both Windows (Scripts/python.exe) and Unix (bin/python) paths.

        Args:
            venv_path: Path to the virtual environment directory

        Returns:
            Path to Python executable if found, None otherwise
        """
        # Check Windows path first
        python_exe = os.path.join(venv_path, "Scripts", "python.exe")
        if os.path.isfile(python_exe):
            return python_exe

        # Check Unix path
        python_exe = os.path.join(venv_path, "bin", "python")
        if os.path.isfile(python_exe):
            return python_exe

        return None

    def _fallback_system_python(self) -> str:
        """Fallback to the system Python (current interpreter).

        Returns:
            Path to the current Python executable (sys.executable)
        """
        if not self._warned_system_fallback:
            logger.warning("No project environment detected; using system Python. Set runtime.python_executable in config or create a venv to use a specific environment.")
            self._warned_system_fallback = True
        return sys.executable

    def _determine_env_type(self, project_path: str, python_exe: str) -> str:
        """Determine the type of environment based on the Python executable path.

        Args:
            project_path: Path to the project directory
            python_exe: Path to the detected Python executable

        Returns:
            Environment type: "venv" if in a project venv, "system" otherwise
        """
        # Check if it's a venv in the project
        for venv_name in VENV_DIRECTORY_NAMES:
            venv_path = os.path.join(project_path, venv_name)
            if python_exe.startswith(venv_path):
                return "venv"

        return "system"
