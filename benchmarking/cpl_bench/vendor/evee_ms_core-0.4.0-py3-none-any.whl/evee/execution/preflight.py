import os
import re
import sys
import tomllib
from collections.abc import Generator
from dataclasses import dataclass
from enum import Enum, auto
from pathlib import Path

from rich.prompt import Confirm

from evee.evaluation.model_evaluator import ModelEvaluator
from evee.logging.logger import setup_logger

MODEL_COUNT_WARNING_THRESHOLD = int(os.getenv("EVEE_MODEL_COUNT_WARNING_THRESHOLD", "100"))
logger = setup_logger(__name__)

# Only check for inline @ file:// URLs in dependencies.
# We intentionally do NOT check [tool.uv.sources] paths because:
# - Remote execution (Azure ML) uses `uv sync --no-sources` which ignores [tool.uv.sources]
# - This allows local development with path sources while still working on remote compute
# - The remote build uses --find-links evee_wheels/ to resolve packages from uploaded wheels
_LOCAL_PATH_PATTERNS = [
    re.compile(r"@\s*file://", re.IGNORECASE),  # @ file:// inline URL
]


def _check_local_path_dependencies(pyproject_path: Path | None = None) -> list[str]:
    """Check pyproject.toml for local path dependencies that won't work on remote.

    Args:
        pyproject_path: Path to pyproject.toml. Defaults to ./pyproject.toml.

    Returns:
        List of evee dependency names that have local path references.
    """
    if pyproject_path is None:
        pyproject_path = Path("pyproject.toml")

    if not pyproject_path.exists():
        return []

    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return []

    local_deps = []

    # Check [project.dependencies] for inline @ file:// URLs
    dependencies = data.get("project", {}).get("dependencies", [])
    for dep in dependencies:
        if not isinstance(dep, str):
            continue
        # Only check evee-related packages
        if not dep.lower().startswith("evee-"):
            continue
        for pattern in _LOCAL_PATH_PATTERNS:
            if pattern.search(dep):
                # Extract package name from dependency string
                pkg_name = dep.split()[0].split("@")[0].split(">")[0].split("<")[0].split("=")[0].split("[")[0]
                local_deps.append(pkg_name)
                break

    return local_deps


class CheckStatus(Enum):
    PASS = auto()
    WARN = auto()
    FAIL = auto()


@dataclass
class CheckResult:
    name: str
    status: CheckStatus
    message: str


def run_preflight_checks(config_path: str, tracking_enabled: bool, interactive: bool, use_remote: bool = False, model_filter: list[str] | None = None) -> None:
    """
    Run pre-flight checks and prompt user for confirmation if necessary.

    Args:
        config_path: Path to the configuration file.
        tracking_enabled: Whether tracking is enabled.
        interactive: Whether to prompt the user for confirmation.
        use_remote: Whether the experiment is running on a remote compute target.
        model_filter: Optional list of model names to include. If None, all models are included.

    Raises:
        SystemExit: If checks fail or user declines confirmation.
    """
    model_evaluator = ModelEvaluator(config_path, load_config_only=True)

    # Display Model Counts (respecting model_filter if provided)
    total_count = 0
    configured_model_names = []
    invalid_model_names = []

    if hasattr(model_evaluator.config, "experiment") and hasattr(model_evaluator.config.experiment, "models"):
        # Collect configured model names
        configured_model_names = [getattr(model, "name", "Unknown") for model in model_evaluator.config.experiment.models]

        # Check for invalid model names in filter
        if model_filter is not None:
            invalid_model_names = [name for name in model_filter if name not in configured_model_names]

        logger.info("Model Combinations:")
        for model in model_evaluator.config.experiment.models:
            name = getattr(model, "name", "Unknown")

            # Skip models not in filter (if filter is provided)
            if model_filter is not None and name not in model_filter:
                continue

            model_combinations = model_evaluator.generate_args_combinations(model)
            count = len(model_combinations)
            total_count += count

            logger.info(f"  - {name}: {count}")
        logger.info(f"Total: {total_count}")

    def _generate_checks() -> Generator[CheckResult, None, None]:
        # Check 1: Configuration
        yield CheckResult("Configuration", CheckStatus.PASS, f"Loaded {config_path}")

        # Check 2: Tracking
        if not tracking_enabled:
            yield CheckResult("Tracking", CheckStatus.WARN, "Disabled (Artifacts may be lost if not captured by backend)")
        else:
            yield CheckResult("Tracking", CheckStatus.PASS, "Enabled")

        # Check 3: Model Count (Warning only)
        # Only warn about high model count if running remotely (cost/time implication)
        if use_remote and total_count > MODEL_COUNT_WARNING_THRESHOLD:
            yield CheckResult("Model Count", CheckStatus.WARN, f"High count: {total_count} combinations (Remote)")

        if invalid_model_names:
            yield CheckResult("Model Filter", CheckStatus.WARN, f"Invalid model names in filter: {', '.join(invalid_model_names)}")

        if total_count == 0:
            yield CheckResult("Model Count", CheckStatus.FAIL, "No model combinations found. Check configuration and filters.")

        # Check 4: Local path dependencies (only for remote runs)
        if use_remote:
            local_path_deps = _check_local_path_dependencies()
            if local_path_deps:
                yield CheckResult(
                    "Dependencies",
                    CheckStatus.FAIL,
                    f"Local path dependencies detected for evee packages: {', '.join(local_path_deps)}. These won't resolve on remote compute. Use git-based sources or provide wheels in evee_wheels/.",
                )

    # Collect results
    results = list(_generate_checks())

    # Filter out PASS results
    visible_results = [r for r in results if r.status != CheckStatus.PASS]

    warning_count = sum(1 for r in visible_results if r.status == CheckStatus.WARN)
    error_count = sum(1 for r in visible_results if r.status == CheckStatus.FAIL)

    if visible_results:
        logger.info("Pre-flight Checks:")
        for result in visible_results:
            if result.status == CheckStatus.WARN:
                logger.warning(f"WARN {result.name}: {result.message}")
            else:
                logger.error(f"FAIL {result.name}: {result.message}")

    if error_count > 0:
        logger.error(f"Pre-flight checks failed with {error_count} error(s). Aborting.")
        sys.exit(1)

    if interactive and warning_count > 0:
        prompt = f"Do you want to proceed despite {warning_count} warning(s)?"
        if not Confirm.ask(prompt, default=True):
            logger.info("Evaluation cancelled by user.")
            sys.exit(130)  # Standard exit code for user cancellation (128 + SIGINT)
