"""Base dataset class for creating custom datasets."""

import inspect
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator
from typing import TypeVar

from .decorator_helpers import (
    get_missing_config_params,
    get_parameters_from_config,
    validate_required_methods,
)
from .execution_context import ExecutionContext

T = TypeVar("T", bound="BaseDataset")

# Global registry for datasets
DATASET_REGISTRY: dict[str, type] = {}


def dataset(name: str | None = None) -> Callable[[type[T]], type["BaseDataset"]]:
    """Class decorator for creating datasets.

    Args:
        name: Unique identifier for this dataset. Used for discovery in config files.
             If not provided, uses the class name.
    """

    def decorator(cls: type[T]) -> type["BaseDataset"]:
        # Use class name if name not provided
        dataset_name = name if name is not None else cls.__name__

        # Register the dataset by name
        if dataset_name in DATASET_REGISTRY:
            raise ValueError(f"Dataset '{dataset_name}' is already registered. Each dataset must have a unique name.")

        validate_required_methods(cls, BaseDataset, ["__iter__", "__len__"])

        class DatasetWrapper(BaseDataset):
            def __init__(self, config: dict, context: ExecutionContext | None = None):
                super().__init__(context)

                sig = inspect.signature(cls.__init__)
                missing = get_missing_config_params(sig, config)
                if missing:
                    raise ValueError(f"Missing required init parameters for dataset '{cls.__name__}': {', '.join(sorted(missing))}.")

                init_params = get_parameters_from_config(sig, config)

                if "connections_registry" in sig.parameters:
                    init_params["connections_registry"] = self.context.connections_registry if self.context else {}
                if "context" in sig.parameters:
                    init_params["context"] = self.context

                self.inner = cls(**init_params)

            def __iter__(self) -> Iterator[dict]:
                return iter(self.inner)

            def __len__(self) -> int:
                return len(self.inner)

        DatasetWrapper.__name__ = cls.__name__
        DatasetWrapper.__doc__ = cls.__doc__
        DatasetWrapper.__module__ = cls.__module__
        DatasetWrapper.__qualname__ = cls.__qualname__

        # Add to registry after wrapper is created
        DATASET_REGISTRY[dataset_name] = DatasetWrapper

        return DatasetWrapper  # type: ignore[return-value]

    return decorator


class BaseDataset(ABC):
    """Base class for dataset implementations."""

    def __init__(self, context: ExecutionContext | None = None):
        self.context = context

    @abstractmethod
    def __iter__(self) -> Iterator[dict]:
        """Yield record dictionaries from the dataset."""
        ...

    @abstractmethod
    def __len__(self) -> int:
        """Return number of records in the dataset."""
        ...
