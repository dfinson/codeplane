"""
Shared helper functions for decorator implementations.
"""

import inspect
from typing import TypeVar

T = TypeVar("T")


def get_missing_config_params(signature: inspect.Signature, config: dict, ignore=None) -> set:
    """
    Returns set of required parameters that are missing from the config.
    Parameters with default values and **kwargs are ignored.

    Args:
        signature: Function signature to check against
        config: Config
        ignore : Optional list of parameter names to ignore
    """
    if ignore is None:
        ignore = ["connections_registry", "context"]
    required_params = [
        param
        for param, info in signature.parameters.items()
        if param not in ["self", "return", "args", "kwargs", *ignore]
        and info.default == inspect.Parameter.empty  # skip parameters with default values
        and info.kind != inspect.Parameter.VAR_KEYWORD  # skip **kwargs
    ]

    config_params = set(config.keys())
    return set(required_params) - config_params


def get_parameters_from_config(signature: inspect.Signature, config: dict) -> dict:
    """
    Returns dictionary of parameters that exist in both function signature and config.

    Args:
        signature: Function signature to check against
        config: Config
    """
    config_params = set(config.keys())
    method_params = set(signature.parameters.keys())

    params = config_params.intersection(method_params)
    return {param: config[param] for param in params}


def validate_required_methods[T](cls: type[T], base_cls: type, required_methods: list[str]) -> None:
    """
    Validates that a class implements all required methods.

    Args:
        cls: The class to validate
        base_cls: The base class to check against
        required_methods: List of method names that must be implemented

    Raises:
        NotImplementedError: If any required method is not implemented
    """
    for method_name in required_methods:
        if not hasattr(cls, method_name) or getattr(cls, method_name) == getattr(base_cls, method_name):
            raise NotImplementedError(f"Class '{cls.__name__}' must implement the '{method_name}' method")
