"""Execution context for experiment components."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ExecutionContext:
    """Context provided to experiment components during execution.

    Encapsulates the execution environment information that models, metrics,
    and datasets can use during an experiment run.

    Attributes:
        connections_registry: Registry of configured connections available to components.
        experiment_name: Name of the experiment from configuration.
        experiment_version: Version string of the experiment from configuration.
        experiment_dir: Resolved path to the current experiment run output directory.
        output_path: Configured base output path from experiment configuration.
        tracking_enabled: Whether tracking backend is enabled for this run.
        model_variant_id: Unique identifier for this model variant within the experiment.
            Automatically set by the framework when registering model argument combinations.
            Empty string when context is shared or before model registration.
    """

    connections_registry: dict[str, Any] = field(default_factory=dict)
    experiment_name: str = ""
    experiment_version: str = ""
    experiment_dir: Path | None = None
    output_path: str = ""
    tracking_enabled: bool = True
    model_variant_id: str = ""
