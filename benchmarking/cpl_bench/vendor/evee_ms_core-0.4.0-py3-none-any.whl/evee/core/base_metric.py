"""
Base class and decorator for implementing metrics.
"""

import inspect
import re
from abc import ABC, abstractmethod
from collections.abc import Callable
from numbers import Number
from typing import Any, TypeVar, cast

from .decorator_helpers import (
    get_missing_config_params,
    get_parameters_from_config,
    validate_required_methods,
)
from .execution_context import ExecutionContext
from .models.inference_output import InferenceOutput

T = TypeVar("T", bound="BaseMetric")

# Global registry for metrics
METRIC_REGISTRY: dict[str, type] = {}


def metric(name: str | None = None) -> Callable[[type[T]], type[T]]:
    """Class decorator for creating metrics.

    Args:
        name: Unique identifier for this metric. Used for discovery in config files.
             If not provided, uses the class name.
    """

    def decorator(cls: type[T]) -> type[T]:
        # Use class name if name not provided
        metric_name = name if name is not None else cls.__name__

        # Register the metric by name
        if metric_name in METRIC_REGISTRY:
            raise ValueError(f"Metric '{metric_name}' is already registered. Each metric must have a unique name.")

        validate_required_methods(cls, BaseMetric, ["compute", "aggregate"])

        class MetricWrapper(BaseMetric):
            def __init__(self, config: dict, context: ExecutionContext | None = None):
                super().__init__(config, context)

                validate_metric_definition(config, cls)

                # Inject init params to the metric class
                cls_signature = inspect.signature(cls.__init__)
                init_params = get_parameters_from_config(cls_signature, config)
                if "connections_registry" in cls_signature.parameters:
                    init_params["connections_registry"] = self.context.connections_registry if self.context else {}
                if "context" in cls_signature.parameters:
                    init_params["context"] = self.context

                self.inner = cls(**init_params)

            def compute(self, inference_output: dict) -> dict[str, Any]:
                """Delegate compute to inner metric instance."""
                # Get mapped fields and compute metric
                fields = self._get_mapped_fields(inference_output)
                return self.inner.compute(**fields)

            def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, Number]:
                """Delegate aggregation to inner metric instance."""
                return self.inner.aggregate(scores)

        MetricWrapper.__name__ = cls.__name__
        MetricWrapper.__doc__ = cls.__doc__
        MetricWrapper.__module__ = cls.__module__
        MetricWrapper.__qualname__ = cls.__qualname__

        def validate_metric_definition(config: dict, cls: type) -> None:
            # Validate config values
            missing_init_params = get_missing_config_params(inspect.signature(cls.__init__), config)
            if missing_init_params:
                raise ValueError(f"Missing required init parameters for metric '{config['name']}': {', '.join(missing_init_params)}. Please review your config file.")

            # Validate config mapping
            missing_mapping_fields = get_missing_config_params(inspect.signature(cls.compute), config["mapping"])
            if missing_mapping_fields:
                raise ValueError(f"{config['name']} metric mapping must include fields for compute method: {missing_mapping_fields}. Please review your config file.")

            # Validate mapping format (model.X or dataset.X)
            valid_sources = ["model", "dataset"]
            pattern = re.compile(rf"^({'|'.join(valid_sources)})\.[^\.]+$")
            for field, mapping in config["mapping"].items():
                if not pattern.match(mapping):
                    raise ValueError(f"'{mapping}' is an invalid mapping for field '{field}' in metric '{config['name']}': expected format 'model.X' or 'dataset.X', depending on the source of the value.")

        # Add to registry after wrapper is created
        METRIC_REGISTRY[metric_name] = MetricWrapper

        return cast(type[T], MetricWrapper)

    return decorator


class BaseMetric(ABC):
    """Base class for all metrics."""

    def __init__(self, config: dict, context: ExecutionContext | None = None):
        """Initialize metric with config.

        Args:
            config: Dictionary containing metric configuration
            context: Optional execution context with experiment info

        Raises:
            ValueError: If config is invalid
        """
        self.name = config["name"]
        self.context = context
        if "mapping" not in config:
            raise ValueError(f"{self.name} metric requires 'mapping' configuration")
        self.mapping = config["mapping"]

    @abstractmethod
    def compute(self, inference_output: dict) -> dict[str, Any]:
        """Calculate metric.

        Args:
            inference_output: Dictionary containing model inference results

        Returns:
            Dictionary containing metric results
        """
        ...

    @abstractmethod
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, Number]:
        """
        Aggregate a list of score dictionaries into a single dictionary.

        Combines the outputs of the `compute` method into an overall aggregated score.
        Subclasses must implement this method to define how multiple individual scores should
        be combined (e.g., averaging, summing, etc.).

        Args:
            scores: A list of dictionaries, each returned from the `compute` method for a single data record.

        Returns:
            A dictionary containing the aggregated score.
        """
        ...

    def _get_mapped_fields(self, inference_output: InferenceOutput) -> dict:
        """Maps fields from inference output to metric inputs.

        Args:
            inference_output: Dictionary containing model inference results

        Returns:
            Dictionary with mapped fields

        Raises:
            KeyError: If a required field is missing in the specified source
        """
        data = inference_output.to_dict()
        sources = {"model": data.get("output", {}), "dataset": data.get("record", {})}

        mapped_fields = {}
        for param, mapping in self.mapping.items():
            source, field = mapping.split(".", 1)
            try:
                mapped_fields[param] = sources[source][field]
            except KeyError as e:
                raise KeyError(f"Field '{field}' not found in '{source}'. Please verify the mapping in the configuration for metric '{self.name}'") from e

        return mapped_fields
