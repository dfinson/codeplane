import asyncio
import inspect
from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any, TypeVar, cast

from dotenv import load_dotenv

from ..logging.logger import setup_logger
from .decorator_helpers import (
    get_missing_config_params,
    get_parameters_from_config,
    validate_required_methods,
)
from .execution_context import ExecutionContext

T = TypeVar("T", bound="BaseModel")

# Global registry for models
MODEL_REGISTRY: dict[str, type] = {}


def model(name: str | None = None) -> Callable[[type[T]], type[T]]:
    """Class decorator for creating models.

    Automatically detects if the model's infer method is async or sync
    and provides both sync and async interfaces.

    Args:
        name: Unique identifier for this model. Used for discovery in config files.
             If not provided, uses the class name.
    """

    def decorator(cls: type[T]) -> type[T]:
        # Use class name if name not provided
        model_name = name if name is not None else cls.__name__

        # Register the model by name
        if model_name in MODEL_REGISTRY:
            raise ValueError(f"Model '{model_name}' is already registered. Each model must have a unique name.")

        validate_required_methods(cls, BaseModel, ["infer"])

        # Detect if the user's infer method is async
        is_async = inspect.iscoroutinefunction(cls.infer)

        class ModelWrapper(BaseModel):
            def __init__(self, config: dict, context: ExecutionContext | None = None):
                super().__init__(context)

                # Validate required parameters are present
                cls_signature = inspect.signature(cls.__init__)
                missing_init_params = get_missing_config_params(cls_signature, config)
                if missing_init_params:
                    raise ValueError(f"Missing required init parameters for model '{cls.__name__}': {', '.join(missing_init_params)}. Please review your config file.")

                # Inject init params to the model class
                init_params = get_parameters_from_config(cls_signature, config)
                if "connections_registry" in cls_signature.parameters:
                    init_params["connections_registry"] = self.context.connections_registry if self.context else {}
                if "context" in cls_signature.parameters:
                    init_params["context"] = self.context

                self.inner = cls(**init_params)
                self._is_async = is_async
                self._has_close = hasattr(cls, "close") and callable(cls.close)
                self._close_is_async = self._has_close and inspect.iscoroutinefunction(cls.close)

            def infer(self, input: dict[str, Any]) -> dict[str, Any]:
                """Sync interface for model inference.

                Works for both sync and async models:
                - Sync models: Direct call
                - Async models: Runs in new event loop
                """
                if self._is_async:
                    # Run async model in sync context
                    return asyncio.run(self.inner.infer(input))
                return self.inner.infer(input)

            async def infer_async(self, input: dict[str, Any]) -> dict[str, Any]:
                """Async interface for model inference.

                Works for both sync and async models:
                - Async models: Direct await
                - Sync models: Runs in thread pool executor
                """
                if self._is_async:
                    # Async model - await directly
                    return await self.inner.infer(input)
                # Sync model - run in executor to not block event loop
                loop = asyncio.get_running_loop()
                return await loop.run_in_executor(None, self.inner.infer, input)

            def close(self) -> None:
                """Sync interface for model cleanup.

                Works for both sync and async close methods:
                - Sync close: Direct call
                - Async close: Runs in new event loop
                """
                if not self._has_close:
                    return
                if self._close_is_async:
                    asyncio.run(self.inner.close())
                else:
                    self.inner.close()

            async def close_async(self) -> None:
                """Async interface for model cleanup.

                Works for both sync and async close methods:
                - Async close: Direct await
                - Sync close: Direct call (sync is safe to call from async)
                """
                if not self._has_close:
                    return
                if self._close_is_async:
                    await self.inner.close()
                else:
                    self.inner.close()

        ModelWrapper.__name__ = cls.__name__
        ModelWrapper.__doc__ = cls.__doc__
        ModelWrapper.__module__ = cls.__module__
        ModelWrapper.__qualname__ = cls.__qualname__

        # Add to registry after wrapper is created
        MODEL_REGISTRY[model_name] = ModelWrapper

        return cast(type[T], ModelWrapper)

    return decorator


class BaseModel(ABC):
    def __init__(self, context: ExecutionContext | None = None):
        """
        Initialize the BaseModel.
        """
        # Load environment variables from .env file
        load_dotenv(verbose=True)

        self.context = context

        # Set up the logger for this class
        self.logger = setup_logger(self.__class__.__module__)

    @abstractmethod
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        """
        An abstract method for performing inference using a model, based on the given input and optional parameters.

        Returns:
            dict: Inference result.
        """
        ...

    def close(self) -> None:  # noqa: B027
        """Optional cleanup method. Override to release resources (HTTP clients, connections, etc.).

        Can be implemented as sync or async:
        - `def close(self)` for sync resources
        - `async def close(self)` for async resources (or mixed sync+async)

        The @model decorator's wrapper will handle sync/async bridging automatically.
        """
        pass

    async def close_async(self) -> None:  # noqa: B027
        """Async interface for cleanup. Called by evaluator for async cleanup."""
        pass
