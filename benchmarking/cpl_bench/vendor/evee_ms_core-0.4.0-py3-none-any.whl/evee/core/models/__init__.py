"""Core models module containing data structures."""

from .evaluation_output import EvaluationOutput
from .inference_output import InferenceOutput

__all__ = ["InferenceOutput", "EvaluationOutput"]
