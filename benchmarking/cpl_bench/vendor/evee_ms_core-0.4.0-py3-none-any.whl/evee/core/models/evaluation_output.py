from dataclasses import dataclass
from typing import Any

from .inference_output import InferenceOutput


@dataclass
class EvaluationOutput:
    """Class to represent the output of a model evaluation process."""

    run_id: str
    inference_output: InferenceOutput
    metrics: dict[str, dict[str, Any]]
    system_metrics: dict[str, dict[str, Any]]
    model_display_name: str
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Convert the EvaluationOutput instance to a dictionary."""
        output_dict = {**self.inference_output.to_dict(), "run_id": self.run_id, "metrics": self.metrics, "system_metrics": self.system_metrics, "model_display_name": self.model_display_name, "metadata": self.metadata}

        return output_dict
