from dataclasses import dataclass
from typing import Any


@dataclass
class InferenceOutput:
    """Class to represent the output of a model inference process."""

    output: Any  # Model output
    model_name: str  # Name of the model used
    record: dict[str, Any]  # The input record
    args: dict[str, Any]  # Additional arguments used

    def to_dict(self) -> dict[str, Any]:
        """Convert the InferenceOutput instance to a dictionary."""
        return {
            "output": self.output,
            "model_name": self.model_name,
            "record": self.record,
            "args": self.args,
        }
