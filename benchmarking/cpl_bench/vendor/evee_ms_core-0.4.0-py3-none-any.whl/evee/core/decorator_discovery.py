"""Auto-discovery module for loading decorated components."""

import ast
import importlib
from pathlib import Path

from ..logging.logger import setup_logger

logger = setup_logger(__name__)

# Module-level cache to track discovered directories and imported modules
_DISCOVERED_DIRECTORIES: set[Path] = set()
_IMPORTED_MODULES: set[str] = set()


def discover_components(force: bool = False) -> None:
    """Discover and import all components to populate registries.

    This function recursively scans the current working directory for Python modules
    and imports them, which triggers the execution of decorators and populates the
    component registries (MODEL_REGISTRY, METRIC_REGISTRY, DATASET_REGISTRY).

    The discovery is based on the current working directory, so when running from
    a specific project directory, all decorated components in that directory tree
    will be discovered.

    Note: Python's import system ensures modules are only loaded once, so repeated
    calls to this function will not re-execute decorator code. Additionally, this
    function caches the directories it has scanned to avoid redundant filesystem
    operations.

    Args:
        force: If True, forces discovery even if the directory has been scanned before.
               Defaults to False.
    """
    base_dir = Path.cwd()

    # Check if we've already discovered this directory
    if not force and base_dir in _DISCOVERED_DIRECTORIES:
        logger.debug(f"Skipping discovery - already scanned: {base_dir}")
        return

    logger.debug(f"Starting component discovery in: {base_dir}")
    from .base_dataset import DATASET_REGISTRY
    from .base_metric import METRIC_REGISTRY
    from .base_model import MODEL_REGISTRY

    # Track counts before discovery
    initial_models = len(MODEL_REGISTRY)
    initial_metrics = len(METRIC_REGISTRY)
    initial_datasets = len(DATASET_REGISTRY)

    _discover_in_directory(base_dir)

    # Mark this directory as discovered
    _DISCOVERED_DIRECTORIES.add(base_dir)

    # Log discovery results
    models_found = len(MODEL_REGISTRY) - initial_models
    metrics_found = len(METRIC_REGISTRY) - initial_metrics
    datasets_found = len(DATASET_REGISTRY) - initial_datasets

    logger.debug(f"Discovery complete: {models_found} models, {metrics_found} metrics, {datasets_found} datasets")
    logger.debug(f"Discovered models: {list(MODEL_REGISTRY.keys())}")
    logger.debug(f"Discovered metrics: {list(METRIC_REGISTRY.keys())}")
    logger.debug(f"Discovered datasets: {list(DATASET_REGISTRY.keys())}")


def _contains_decorator_syntax(content: str, target_decorators: set[str]) -> bool:
    """Fast text-based pre-filter to check if decorator syntax appears in file.

    This is an optimization that avoids expensive AST parsing for files that
    definitely don't contain our decorators. May have false positives (e.g.,
    decorators in comments), but those are filtered out by subsequent AST parsing.

    Args:
        content: File content as string
        target_decorators: Set of decorator names to search for (e.g., {'model', 'metric'})

    Returns:
        True if any decorator syntax (@name) appears in the file content
    """
    return any(f"@{name}" in content for name in target_decorators)


def _has_decorator_on_class(tree: ast.AST, target_decorators: set[str]) -> bool:
    """Verify that target decorators are applied to class definitions in the AST.

    Examines the AST to find decorators applied to classes (not functions).
    Supports both bare decorators (@model) and call decorators (@model(...)).
    Uses early termination for performance.

    Args:
        tree: Parsed AST tree of the Python file
        target_decorators: Set of decorator names to search for (e.g., {'model', 'metric'})

    Returns:
        True if any target decorator is found on a class definition
    """
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for decorator in node.decorator_list:
                # Extract decorator name from both @decorator and @decorator(...) forms
                decorator_name = None
                if isinstance(decorator, ast.Name):
                    decorator_name = decorator.id
                elif isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Name):
                    decorator_name = decorator.func.id

                if decorator_name in target_decorators:
                    return True
    return False


def _discover_in_directory(directory: Path) -> None:
    """Recursively discover and import Python modules containing evee decorators.

    This function performs a two-phase discovery process:
    1. File scanning: Recursively walks through the directory tree to find Python files
    2. AST parsing: Analyzes each file's abstract syntax tree to detect evee decorators

    Only modules containing at least one evee decorator (@model, @metric, @dataset) on
    a class definition are imported. This selective importing minimizes overhead and
    prevents unnecessary module loading.

    Files are skipped if they:
    - Are located in excluded directories (e.g., .venv, __pycache__, node_modules)
    - Have names starting with underscore (private modules like __init__.py)
    - Don't contain any evee decorators on class definitions
    - Have syntax errors that prevent AST parsing
    - Cannot be read due to file system errors

    The decorator detection works by:
    1. Parsing the file into an AST without executing any code
    2. Walking through all class definitions (ast.ClassDef nodes only)
    3. Checking each class's decorators for @model, @metric, or @dataset
    4. Supporting both @decorator and @decorator(...) forms

    Note: Functions decorated with these class-only decorators are intentionally
    ignored to prevent importing modules with incorrectly decorated functions.

    Args:
        directory: Directory to scan for Python modules. Must be a valid Path object.
    """
    # Directories to exclude from scanning
    exclude_dirs = {".venv", "venv", "env", ".env", "__pycache__", ".pytest_cache", ".git", "node_modules", ".tox", ".mypy_cache", "build", "dist", ".eggs", ".DS_Store", "output", "logs"}

    # Decorator names to look for
    target_decorators = {"model", "metric", "dataset"}

    # Pre-compile directory exclusion set for O(1) lookups
    exclude_dirs_frozen = frozenset(exclude_dirs)

    def _is_excluded_path(path: Path) -> bool:
        """Check if a path contains any excluded directory."""
        return any(excluded in path.parts for excluded in exclude_dirs_frozen)

    try:
        # Use os.walk instead of rglob for efficient directory pruning
        # This allows us to skip entire directory trees without traversing them
        import os

        python_files = []
        for root, dirs, files in os.walk(directory):
            root_path = Path(root)

            # Prune excluded directories from traversal
            dirs[:] = [d for d in dirs if d not in exclude_dirs_frozen]

            # Collect Python files (excluding private modules)
            for file in files:
                if file.endswith(".py") and not file.startswith("_"):
                    file_path = root_path / file
                    # Verify path doesn't contain any excluded directories
                    if not _is_excluded_path(file_path):
                        python_files.append(file_path)

        # Process files
        for file_path in python_files:
            # Convert file path to module path early to check cache
            try:
                relative_path = file_path.relative_to(Path.cwd())
                module_path = ".".join(relative_path.with_suffix("").parts)
            except ValueError:
                # File is not relative to cwd, skip it
                continue

            # Skip if already imported
            if module_path in _IMPORTED_MODULES:
                logger.debug(f"Skipping already imported: {module_path}")
                continue

            # Two-phase decorator detection: fast text search, then AST validation
            try:
                content = file_path.read_text(encoding="utf-8")

                # Phase 1: Fast pre-filter using text search
                if not _contains_decorator_syntax(content, target_decorators):
                    logger.debug(f"Skipping {file_path.name} - no decorator syntax found")
                    continue

                # Phase 2: Parse and validate decorators are on classes
                try:
                    tree = ast.parse(content, filename=str(file_path))
                except SyntaxError:
                    logger.debug(f"Skipping {file_path.name} - syntax error")
                    continue

                if not _has_decorator_on_class(tree, target_decorators):
                    logger.debug(f"Skipping {file_path.name} - no decorators on classes")
                    continue

            except Exception as e:
                logger.debug(f"Error reading {file_path}: {e}")
                continue

            # Import the module
            try:
                logger.debug(f"Importing module with decorators: {module_path}")
                importlib.import_module(module_path)
                _IMPORTED_MODULES.add(module_path)
                logger.debug(f"Successfully imported: {module_path}")
            except Exception as e:
                logger.warning(f"Failed to import {module_path}: {e}")
                # Continue with other modules even if one fails

    except Exception as e:
        logger.warning(f"Error discovering modules in {directory}: {e}")


def import_builtin_datasets() -> None:
    """Import built-in dataset implementations to populate registry."""
    logger.debug("Importing built-in datasets...")
    try:
        from .. import datasets  # noqa: F401 — triggers registration via datasets/__init__.py
        from .base_dataset import DATASET_REGISTRY

        logger.debug(f"Built-in datasets imported: {list(DATASET_REGISTRY.keys())}")
    except Exception as e:
        logger.warning(f"Failed to import built-in datasets: {e}")
