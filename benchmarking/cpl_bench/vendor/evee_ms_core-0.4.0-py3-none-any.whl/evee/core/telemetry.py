"""Telemetry utilities for Azure partner tracking."""

from logging import Logger

PARTNER_ATTRIBUTION_ID = "pid-acce1e78-4dcd-4727-825f-ee96f650273a"


def get_user_agent(logger: Logger, telemetry_enabled: bool = True) -> str | None:
    """Get the user agent string for Azure partner tracking.

    This function checks the telemetry_enabled parameter to determine
    whether to include the partner attribution ID in the user agent string.

    Args:
        logger: Logger instance for logging telemetry status
        telemetry_enabled: Whether telemetry is enabled (from config). Defaults to True.

    Returns:
        The partner attribution ID if telemetry is enabled, None otherwise
    """
    if telemetry_enabled:
        logger.debug("Telemetry enabled")
        return PARTNER_ATTRIBUTION_ID
    logger.info("Telemetry disabled via telemetry_enabled config setting")
    return None
