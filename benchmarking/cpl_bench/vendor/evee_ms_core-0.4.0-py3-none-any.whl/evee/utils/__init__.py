"""Utility functions for Evee."""

from evee.utils.environment import is_rich_compatible_environment

__all__ = ["is_rich_compatible_environment"]
