"""Environment detection utilities."""

import os


def is_mcp_mode() -> bool:
    """Check if the current process is running in MCP mode.

    Returns:
        True if EVEE_MCP_MODE is set to true.
    """
    return os.getenv("EVEE_MCP_MODE", "false").lower() == "true"


def is_rich_compatible_environment() -> bool:
    """Check if the current environment supports Rich formatting.

    Returns False (Rich incompatible) if:
    - EVEE_DISABLE_RICH_LOGGING is set to true
    - Running in Azure ML (IS_AZURE_ML is set to true)
    - Running in MCP mode (EVEE_MCP_MODE is set to true)

    Returns:
        True if Rich formatting should be used, False otherwise.
    """
    if os.getenv("EVEE_DISABLE_RICH_LOGGING", "false").lower() == "true":
        return False
    if is_mcp_mode():
        return False
    return os.getenv("IS_AZURE_ML", "false").lower() != "true"
