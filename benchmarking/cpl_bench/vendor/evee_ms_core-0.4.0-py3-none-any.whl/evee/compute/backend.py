from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class JobStatus(StrEnum):
    """Status of a submitted job."""

    SUBMITTED = "submitted"
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class JobInfo:
    """Information about a submitted job."""

    job_id: str
    status: JobStatus
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RunContext:
    """Context for running an evaluation job.

    Encapsulates all the parameters needed to submit a job to a compute backend.
    """

    config_path: str
    env_path: str | None = None
    dataset_path: str | None = None
    tracking_enabled: bool = True
    stream_remote_logs: bool = False
    download_path: str | None = None
    model_filter: list[str] | None = None


class ComputeBackend(ABC):
    @abstractmethod
    def submit(self, context: RunContext, **kwargs: Any) -> JobInfo:
        pass
