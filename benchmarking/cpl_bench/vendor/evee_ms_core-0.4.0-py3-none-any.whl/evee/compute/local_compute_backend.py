from evee.compute.backend import ComputeBackend, JobInfo, JobStatus, RunContext
from evee.config import Config
from evee.evaluation.evaluate import main as evaluate_main
from evee.logging.logger import setup_logger


class LocalComputeBackend(ComputeBackend):
    """Run the evaluation synchronously in the current process."""

    def __init__(self, config: Config) -> None:
        self.logger = setup_logger(self.__class__.__module__)
        self.config = config
        self.logger.debug("Initializing LocalComputeBackend")

    def submit(self, context: RunContext, **_kwargs) -> JobInfo:
        self.logger.info(f"Starting local evaluation with config: {context.config_path}")

        try:
            summary = evaluate_main(
                config_path=context.config_path,
                dataset_path=context.dataset_path,
                env_path=context.env_path,
                tracking_enabled=context.tracking_enabled,
                model_filter=context.model_filter,
            )

            return JobInfo(
                job_id="local",
                status=JobStatus.COMPLETED,
                metadata={"execution_type": "local_process", **(summary or {})},
            )
        except Exception as e:
            self.logger.exception("Local evaluation failed")
            return JobInfo(
                job_id="local",
                status=JobStatus.FAILED,
                metadata={"error": str(e), "execution_type": "local_process"},
            )
