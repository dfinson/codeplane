"""Utilities for compute backends."""
