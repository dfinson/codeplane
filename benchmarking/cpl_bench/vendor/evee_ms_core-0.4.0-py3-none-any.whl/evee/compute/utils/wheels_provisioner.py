"""Utilities for resolving evee package dependencies for remote environments.

Helpers for remote compute backends to provision evee wheel files for
environments that don't have direct access to GitHub source installs.
"""

from __future__ import annotations

import re
import subprocess
import tempfile
import urllib.parse
import urllib.request
from pathlib import Path

from packaging.requirements import Requirement

from evee.logging.logger import setup_logger

logger = setup_logger(__name__)

_RELEASE_TAG_RE = re.compile(r"^v?(\d+\.\d+\.\d+)$")
_GIT_URL_RE = re.compile(r"^git\+(?P<url>https?://[^@#]+)(?:@(?P<ref>[^#]+))?(?:#subdirectory=(?P<subdir>.+))?$")

_EVEE_PKG_PREFIX = "evee-ms-"


def _get_pkg_subdir(pkg_name: str) -> str:
    suffix = pkg_name.removeprefix(_EVEE_PKG_PREFIX)
    return "." if suffix == "core" else f"packages/evee-{suffix}"


def _wheel_dist_name(pkg_name: str) -> str:
    return pkg_name.replace("-", "_")


def _parse_dep_spec(dep: str) -> tuple[str, dict] | None:
    req = Requirement(dep)
    if not req.name.startswith(_EVEE_PKG_PREFIX):
        return None

    if not req.url:
        return req.name, {"type": "bare", "specifier": str(req.specifier)}

    url = req.url.strip()

    if m := _GIT_URL_RE.match(url):
        repo_url = m.group("url")
        ref = m.group("ref") or "main"
        subdir = m.group("subdir")

        if t := _RELEASE_TAG_RE.match(ref):
            return req.name, {"type": "git_release", "url": repo_url, "version": t.group(1)}

        return req.name, {"type": "git_ref", "url": repo_url, "ref": ref, "subdir": subdir}

    parsed = urllib.parse.urlparse(url)
    if parsed.scheme == "file":
        # url2pathname handles platform-specific decoding
        path = Path(urllib.request.url2pathname(parsed.path))
        return req.name, {"type": "file", "path": str(path)}

    raise RuntimeError(f"Unsupported URL for {req.name}: {url} (expected git+https://... or file://...)")


def _parse_uv_source(source: dict, project_dir: Path) -> dict | None:
    """Parse a [tool.uv.sources] entry into our internal format."""
    if "path" in source:
        # Local path reference
        path = (project_dir / source["path"]).resolve()
        return {"type": "file", "path": str(path)}

    if "git" in source:
        repo_url = source["git"]
        ref = source.get("rev") or source.get("tag") or source.get("branch") or "main"
        subdir = source.get("subdirectory")

        if t := _RELEASE_TAG_RE.match(ref):
            return {"type": "git_release", "url": repo_url, "version": t.group(1)}

        return {"type": "git_ref", "url": repo_url, "ref": ref, "subdir": subdir}

    return None


def parse_evee_dependencies(pyproject_path: Path) -> dict[str, dict]:
    import tomllib  # Python 3.11+

    data = tomllib.loads(pyproject_path.read_text())
    project = data.get("project", {})
    deps = list(project.get("dependencies", []))

    opt = project.get("optional-dependencies", {}) or {}
    for group_deps in opt.values():
        deps.extend(group_deps)

    # Get uv.sources for fallback
    uv_sources = data.get("tool", {}).get("uv", {}).get("sources", {})
    project_dir = pyproject_path.parent

    out: dict[str, dict] = {}
    for dep in deps:
        parsed = _parse_dep_spec(dep)
        if parsed:
            name, info = parsed
            # If bare dependency, check uv.sources
            if info["type"] == "bare" and name in uv_sources:
                uv_info = _parse_uv_source(uv_sources[name], project_dir)
                if uv_info:
                    info = uv_info
            out[name] = info
    return out


def provision_wheels(project_dir: Path, dest_dir: Path, pyproject_file: str = "pyproject.toml") -> Path:
    project_dir = Path(project_dir)
    dest_dir = Path(dest_dir)
    pyproject_path = project_dir / pyproject_file

    if not pyproject_path.exists():
        raise FileNotFoundError(f"Project manifest not found: {pyproject_path}")

    # Clear old wheels to avoid accumulation
    if dest_dir.exists():
        for f in dest_dir.glob("*.whl"):
            f.unlink()
        for f in dest_dir.glob("*.tar.gz"):
            f.unlink()

    dest_dir.mkdir(parents=True, exist_ok=True)
    deps = parse_evee_dependencies(pyproject_path)

    if not deps:
        raise RuntimeError(f"No evee-ms-* dependencies found in {pyproject_path}")

    for pkg_name, info in deps.items():
        t = info["type"]

        if t == "bare":
            raise RuntimeError(f"{pkg_name} must specify a source (git URL or file path). Got: {info.get('specifier') or '(none)'}")

        if t == "git_release":
            _download_release_wheel(dest_dir, pkg_name, info["version"], info["url"])
        elif t == "git_ref":
            _build_from_git(dest_dir, pkg_name, info["url"], info["ref"], info.get("subdir"))
        elif t == "file":
            _build_from_path(dest_dir, pkg_name, Path(info["path"]))
        else:
            raise RuntimeError(f"Unknown dependency type for {pkg_name}: {t}")

    return dest_dir


def _download_release_wheel(dest_dir: Path, pkg_name: str, version: str, repo_url: str) -> None:
    """Download a wheel from GitHub releases using gh CLI.

    Requires gh CLI to be installed and authenticated (e.g., via `gh auth login`).
    """
    # Extract owner/repo from URL (e.g., https://github.com/microsoft/evee -> microsoft/evee)
    base_url = repo_url.rstrip("/").removesuffix(".git")
    parsed = urllib.parse.urlparse(base_url)
    repo_nwo = parsed.path.lstrip("/")  # name-with-owner: "owner/repo"

    wheel = _wheel_dist_name(pkg_name)
    filename = f"{wheel}-{version}-py3-none-any.whl"
    tag = f"v{version}"

    logger.info(f"Downloading {pkg_name} {tag} wheel from GitHub releases via gh CLI")
    try:
        res = subprocess.run(
            ["gh", "release", "download", tag, "--pattern", filename, "--dir", str(dest_dir), "--repo", repo_nwo],
            capture_output=True,
            text=True,
        )
        if res.returncode != 0:
            msg = (res.stderr or res.stdout or "").strip()
            raise RuntimeError(f"gh release download failed: {msg}")
    except FileNotFoundError as e:
        raise RuntimeError("gh CLI not found. Install it from https://cli.github.com/ and authenticate with `gh auth login`.") from e
    except Exception as e:
        raise RuntimeError(f"Failed to download {pkg_name} {tag} from {repo_nwo}: {e}") from e


def _build_from_git(dest_dir: Path, pkg_name: str, repo_url: str, ref: str, subdir_override: str | None) -> None:
    logger.info(f"Building {pkg_name} from git ref: {ref}")

    with tempfile.TemporaryDirectory() as tmp:
        repo_path = Path(tmp) / "repo"

        # Shallow fetch pattern (more robust than clone --branch for non-branches)
        subprocess.run(["git", "init", str(repo_path)], check=True, capture_output=True, text=True)
        subprocess.run(["git", "-C", str(repo_path), "remote", "add", "origin", repo_url], check=True, capture_output=True, text=True)

        try:
            subprocess.run(
                ["git", "-C", str(repo_path), "fetch", "--depth", "1", "origin", ref],
                check=True,
                capture_output=True,
                text=True,
            )
            subprocess.run(
                ["git", "-C", str(repo_path), "checkout", "--detach", "FETCH_HEAD"],
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError:
            # fallback: full clone + checkout (handles edge cases)
            repo_path = Path(tmp) / "full_repo"
            subprocess.run(["git", "clone", repo_url, str(repo_path)], check=True, capture_output=True, text=True)
            subprocess.run(["git", "-C", str(repo_path), "checkout", ref], check=True, capture_output=True, text=True)

        subdir = subdir_override or _get_pkg_subdir(pkg_name)
        _build_wheel(dest_dir, pkg_name, repo_path / subdir)


def _build_from_path(dest_dir: Path, pkg_name: str, source_path: Path) -> None:
    logger.info(f"Building {pkg_name} from local source: {source_path}")

    if not source_path.exists():
        raise RuntimeError(f"Source path not found: {source_path}")

    _build_wheel(dest_dir, pkg_name, source_path)


def _build_wheel(dest_dir: Path, pkg_name: str, pkg_path: Path) -> None:
    if not (pkg_path / "pyproject.toml").exists():
        raise RuntimeError(f"No pyproject.toml found at {pkg_path}")

    res = subprocess.run(
        ["uv", "build", str(pkg_path), "--out-dir", str(dest_dir), "--wheel"],
        capture_output=True,
        text=True,
    )
    if res.returncode != 0:
        msg = (res.stderr or res.stdout or "").strip()
        raise RuntimeError(f"Failed to build {pkg_name} from {pkg_path}: {msg}")

    logger.info(f"Built: {pkg_name}")
