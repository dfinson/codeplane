"""evee - Evaluation Engine for LLM Models.

This package uses lazy imports to improve CLI startup time. Heavy dependencies
like mlflow, OpenAI SDK, and evaluation components are only loaded when actually
needed.
"""

from importlib.metadata import PackageNotFoundError, version

# Lazy imports - only import when actually used, not at package import time
# This dramatically improves CLI startup time

try:
    __version__ = version("evee-ms-core")
except PackageNotFoundError:
    import os
    import re

    pyproject_path = os.path.join(os.path.dirname(__file__), "..", "..", "pyproject.toml")
    try:
        with open(pyproject_path) as f:
            content = f.read()
            match = re.search(r'version\s*=\s*"([^"]+)"', content)
            __version__ = match.group(1) if match else "0.0.0"
    except (OSError, FileNotFoundError):
        __version__ = "0.0.0"


# Public API - exported attributes available via lazy loading
__all__ = ["ModelEvaluator", "Config", "BaseModel", "model", "metric", "dataset", "setup_logger", "ExecutionContext"]


def __getattr__(name: str):
    """Lazy import handler - loads modules only when first accessed.

    This prevents loading heavy dependencies (mlflow, OpenAI SDK, etc.) until
    they're actually needed.

    Args:
            name: Attribute name being imported from the package

    Returns:
            The requested module attribute, cached in globals for subsequent access

    Raises:
            AttributeError: If name is not in the public API
    """
    # Import the actual modules/functions and let Python resolve the paths
    # This is more robust than hardcoded string paths
    if name == "ModelEvaluator":
        from .evaluation.model_evaluator import ModelEvaluator

        globals()[name] = ModelEvaluator
        return ModelEvaluator
    elif name == "Config":
        from .config import Config

        globals()[name] = Config
        return Config
    elif name == "BaseModel":
        from .core.base_model import BaseModel

        globals()[name] = BaseModel
        return BaseModel
    elif name == "model":
        from .core.base_model import model

        globals()[name] = model
        return model
    elif name == "metric":
        from .core.base_metric import metric

        globals()[name] = metric
        return metric
    elif name == "dataset":
        from .core.base_dataset import dataset

        globals()[name] = dataset
        return dataset
    elif name == "setup_logger":
        from .logging.logger import setup_logger

        globals()[name] = setup_logger
        return setup_logger
    elif name == "ExecutionContext":
        from .core.execution_context import ExecutionContext

        globals()[name] = ExecutionContext
        return ExecutionContext

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
