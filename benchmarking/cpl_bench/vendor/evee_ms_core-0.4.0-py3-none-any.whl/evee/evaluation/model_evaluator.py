"""
Core evaluator class for model evaluation.
"""

import asyncio
import hashlib
import json
import os
import re
import time
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import replace as dataclasses_replace
from datetime import datetime
from itertools import product
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from tqdm import TqdmExperimentalWarning

from ..config import Config, DatasetConfig, ModelVariantConfig
from ..core.base_dataset import BaseDataset
from ..core.base_metric import METRIC_REGISTRY
from ..core.base_model import MODEL_REGISTRY, BaseModel
from ..core.decorator_discovery import discover_components, import_builtin_datasets
from ..core.execution_context import ExecutionContext
from ..core.models.evaluation_output import EvaluationOutput
from ..core.models.inference_output import InferenceOutput
from ..datasets.dataset_factory import DatasetFactory
from ..logging.local_metrics_logger import LocalMetricsLogger
from ..logging.logger import get_console, setup_logger
from ..tracking import (
    ArtifactGeneratedEvent,
    ExperimentCompletedEvent,
    ExperimentStartEvent,
    InferenceCompletedEvent,
    InferenceStartEvent,
    ModelRunCompletedEvent,
    ModelRunStartEvent,
    OperationStatus,
    ResultsAnalyzedEvent,
    TrackingBackend,
    create_tracking_backend,
)
from .metrics_aggregator import MetricsAggregator
from .progress_tracker import ProgressTracker


class ModelEvaluator:
    """Main evaluator class for assessing AI models."""

    _FILE_NAME_LENGTH_LIMIT = 240
    tracking_backend: TrackingBackend

    def __init__(self, config_path: str = "config.yaml", env_path: str = ".env", load_config_only: bool = False, tracking_enabled: bool = True, model_filter: list[str] | None = None) -> None:
        """Initialize the evaluator with optional config path.

        Args:
            config_path: Path to configuration YAML file
            env_path: Path to .env file
            load_config_only: Whether to only load the configuration
            tracking_enabled: Whether to enable tracking backend
            model_filter: Optional list of model names to include. If None, all models are evaluated.
        """
        warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
        load_dotenv(dotenv_path=env_path, verbose=True)

        self.console = get_console()
        self.logger = setup_logger(self.__class__.__module__, console=self.console)
        self.model_filter = model_filter

        # Auto-discover and import all decorated components
        self.logger.debug("Discovering components...")
        import_builtin_datasets()  # Import built-in datasets first
        discover_components()  # Discover user-defined components from current working directory
        self.logger.debug("Component discovery complete")

        self.config = self._load_config(config_path)

        if load_config_only:
            return

        # Initialize tracking backend early so the environment is ready for user models upon instantiation
        self._current_dir = Path(os.getcwd())
        self._current_experiment_dir = self._create_experiment_dir()

        self.tracking_backend = create_tracking_backend(config=self.config, tracking_enabled=tracking_enabled)
        self.tracking_backend.on_startup()

        if hasattr(self.tracking_backend, "execution_id"):
            self.logger.info(f"Execution ID: {self.tracking_backend.execution_id}")

        # register connections
        self.connections_registry = {}
        self.logger.debug("Initializing model evaluator with connections")
        if not self.config.experiment.connections:
            self.logger.warning("No connections found in configuration. Proceeding without connections.")
        else:
            for connection in self.config.experiment.connections:
                self.connections_registry[connection.name] = connection

        # Build execution context for components
        self.execution_context = ExecutionContext(
            connections_registry=self.connections_registry,
            experiment_name=self.config.experiment.name,
            experiment_version=self.config.experiment.version,
            experiment_dir=self._current_experiment_dir,
            output_path=self.config.experiment.output_path,
            tracking_enabled=tracking_enabled,
        )

        # register models (filtered if model_filter is provided)
        self.models_registry = {}
        self.logger.debug("Initializing model evaluator with configuration")
        if not self.config.experiment.models:
            self.logger.warning("No models found in configuration. Proceeding without models.")
        else:
            self._register_models_with_filter()

        # register metrics
        self.metrics_registry = {}
        self.logger.debug("Registering metrics")
        if not self.config.experiment.metrics:
            self.logger.warning("No metrics found in configuration. Proceeding without metrics.")
        else:
            for metric in self.config.experiment.metrics:
                self._register_metric(metric)

        self.metrics_logger = LocalMetricsLogger(output_dir=self._current_experiment_dir)
        self.metrics_aggregator = MetricsAggregator(self.metrics_registry)
        self.dataset_factory = DatasetFactory()

    def _register_models_with_filter(self) -> None:
        """Register models from configuration, applying filter if specified.

        If model_filter is provided, only models whose names match the filter are registered.
        Non-matching filter entries are logged as warnings.
        """
        configured_model_names = [model.name for model in self.config.experiment.models]

        if self.model_filter is not None:
            # Warn about non-existent models in filter
            for filter_name in self.model_filter:
                if filter_name not in configured_model_names:
                    self.logger.warning(f"Model '{filter_name}' specified in model filter not found in configuration. Available models: {configured_model_names}")

            # Only register models that match the filter
            for model in self.config.experiment.models:
                if model.name in self.model_filter:
                    self._register_model(model)
                else:
                    self.logger.debug(f"Skipping model '{model.name}' (not in model filter)")

            if not self.models_registry:
                self.logger.warning("No models matched the filter. No models will be evaluated.")
        else:
            # No filter - register all models
            for model in self.config.experiment.models:
                self._register_model(model)

    def _register_metric(self, metric: dict) -> None:
        """Register a metric from configuration.

        Args:
            metric: Metric configuration dictionary
        """
        try:
            metric_dict = metric.model_dump()
            metric_name = metric_dict["name"]
            self.logger.debug(f"Registering metric: {metric_name}")

            if self.metrics_registry.get(metric_name):
                raise ValueError(f"Metric {metric_name} is already registered. Each metric must have a unique name.")

            # Look up metric from registry
            metric_class = METRIC_REGISTRY.get(metric_name)
            if not metric_class:
                available_metrics = list(METRIC_REGISTRY.keys())
                raise ValueError(f"Metric '{metric_name}' not found in registry. Available metrics: {available_metrics}. Ensure the metric is decorated with @metric(name='{metric_name}') and imported.")

            # Add metric to registry
            metric_instance = metric_class(metric_dict, self.execution_context)
            self.metrics_registry[metric_name] = metric_instance
            self.logger.debug(f"Metric {metric_name} registered successfully")
        except Exception:
            self.logger.exception(f"Failed to register metric {getattr(metric, 'name', 'unknown')}")
            raise

    def _load_config(self, config_path: str) -> Config:
        """Load configuration from YAML file.

        Args:
            config_path: Path to configuration file

        Returns:
            Config object containing configuration
        """
        self.logger.info(f"Loading configuration from {config_path}")

        if not Path(config_path).exists():
            err_msg = f"Configuration file {config_path} does not exist"
            self.logger.error(err_msg)
            raise FileNotFoundError(err_msg)

        self.logger.debug("Configuration loaded successfully")
        return Config.from_yaml(config_path)

    def _register_model(self, model: ModelVariantConfig) -> None:
        """Register a model and its argument combinations in the models registry.

        Loads the model class from MODEL_REGISTRY, generates all argument combinations,
        and stores each combination in self.models_registry.

        Args:
            model: Model configuration containing name and args

        Raises:
            ValueError: If model name is not found in MODEL_REGISTRY
        """
        model_name = model.name
        self.logger.debug(f"Registering model: {model_name}")

        # Look up model from registry
        model_class = MODEL_REGISTRY.get(model_name)
        if not model_class:
            available_models = list(MODEL_REGISTRY.keys())
            raise ValueError(f"Model '{model_name}' not found in registry. Available models: {available_models}. Ensure the model is decorated with @model(name='{model_name}') and imported.")

        # Generate all combinations of arguments for the model
        arg_combinations = self.generate_args_combinations(model)

        # Add model combinations to self.models_registry
        combination_by_name = self._simplify_combination_names(model_name, arg_combinations)
        for simplified_name, args in combination_by_name.items():
            variant_context = dataclasses_replace(self.execution_context, model_variant_id=simplified_name)
            loaded_model = model_class(args, variant_context)
            self.models_registry[simplified_name] = {"model": loaded_model, "config": model, "args": args}
            self.logger.debug(f"Model {simplified_name} registered successfully")

    def _cleanup_models(self) -> None:
        """Cleanup all registered models by calling their close() method if available.

        This releases resources like HTTP clients, connections, file handles, etc.
        Models without a close() method are silently skipped.
        """
        for model_name, model_data in self.models_registry.items():
            model_instance = model_data["model"]
            try:
                if hasattr(model_instance, "_has_close") and model_instance._has_close:
                    self.logger.debug(f"Cleaning up model: {model_name}")
                    model_instance.close()
            except Exception:
                self.logger.exception(f"Error cleaning up model '{model_name}'")

    def generate_args_combinations(self, model_config: ModelVariantConfig) -> list[dict[str, Any]]:
        """Generate all combinations of arguments for the model.

        Args:
            model_config: Model variant configuration containing name and args

        Returns:
            List of dictionaries containing all combinations of arguments (Cartesian product)

        Raises:
            ValueError: If any arg dict is empty or has multiple keys
        """
        # Convert args to list of dictionaries
        arg_dicts = []
        for arg in model_config.args:
            if len(arg) != 1:
                raise ValueError(f"Each arg in model_config.args must have exactly one key, got {len(arg)} keys: {list(arg.keys())}")
            key = list(arg)[0]
            values = arg[key]
            arg_dicts.append({key: values})

        # Get all keys and corresponding value lists
        keys = [list(d.keys())[0] for d in arg_dicts]
        value_lists = [list(d.values())[0] for d in arg_dicts]

        # Generate Cartesian product of all values
        combinations = []
        for values in product(*value_lists):
            combination = dict(zip(keys, values, strict=False))
            combinations.append(combination)

        return combinations

    def _flatten_dict_values(self, d):
        """
        Recursively flattens a dict's values and joins them with underscores.

        Example:
        {"a": {"x": "foo", "y": "bar"}, "b": "baz"} -> "foo_bar_baz"
        """

        def extract_values(obj):
            if not isinstance(obj, dict):
                return [str(obj)]
            values = []
            for key in sorted(obj.keys()):
                values.extend(extract_values(obj[key]))
            return values

        return "_".join(extract_values(d))

    def _simplify_combination_names(self, model_name, args_combinations):
        """
        Generates a unique, simplified name for each config combination based on the values that differ between them.

        Example:
        Given the following args_combinations:
            {"prompt": "prompt1", "temp": 1, "limit": 100}
            {"prompt": "prompt2", "temp": 1, "limit": 100}

        And model_name = "baseline",
        The method will return a dictionary with simplified names as keys and the args_combinations as values:
            {
                "baseline_prompt1": {"prompt": "prompt1", "temp": 1, "limit": 100},
                "baseline_prompt2": {"prompt": "prompt2", "temp": 1, "limit": 100}
            }

        In this case, the only field that differs between the combinations is "prompt," so the simplified names are based on that field.

        Returns:
            Dict[str, Dict]: Dictionary where keys are simplified names and values are the corresponding args combinations.
        """
        if not args_combinations:
            return {}

        # Identify keys that vary across configs
        varying_keys = set()
        for key in args_combinations[0]:
            values = set()
            for args in args_combinations:
                value = args.get(key)
                value = value if not isinstance(value, dict) else self._flatten_dict_values(value)
                values.add(value)
            if len(values) > 1:
                varying_keys.add(key)

        # Generate identifiers and create result dictionary
        result = {}
        for args in args_combinations:
            values = []
            for key in sorted(varying_keys):
                value = args.get(key)
                value = str(value) if not isinstance(value, dict) else self._flatten_dict_values(value)
                values.append(value)
            suffix = "_".join(values)

            simplified_name = f"{model_name}__{suffix}" if suffix else model_name
            result[simplified_name] = args

        return result

    def _create_experiment_dir(self) -> Path:
        """Create and return the experiment directory name with version and timestamp.

        Returns:
            Directory name for this experiment run
        """
        encoded_experiment_name = self._encode_experiment_name(self.config.experiment.name)
        version = self.config.experiment.version
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        experiment_dir = f"{encoded_experiment_name}_v{version}__{timestamp}"

        # Create the experiment directory
        output_path = self._current_dir / self.config.experiment.output_path / experiment_dir
        output_path.mkdir(parents=True, exist_ok=True)

        return output_path

    def _evaluate_record(self, record: dict[str, Any], run_id: str, model_name: str, model_display_name: str, model: Any, **kwargs) -> EvaluationOutput:
        """Infer output for a record and compute its metrics.

        Args:
            record: Record to evaluate
            run_id: Run ID (backend UUID if tracking enabled, otherwise descriptive name)
            model_name: Name of the model to use
            model: Model to use for evaluation (object)
            kwargs: Additional arguments for the model

        Returns:
            EvaluationOutput containing model inference output and computed metrics
        """
        # Notify tracking backend about inference start (enables autolog tracing)
        record_id = record.get("id", str(hash(str(record))))
        self.logger.debug(f"Inference started for run '{run_id}', record '{record_id}'")
        self.tracking_backend.on_inference_started(InferenceStartEvent(run_id=run_id, record_id=record_id, input_data=record))

        try:
            start_time = time.perf_counter()
            model_output = self._infer_record(record, model_name, model, **kwargs)
            response_time_ms = (time.perf_counter() - start_time) * 1000

            model_config = self.models_registry[model_display_name]["config"]
            metrics = self._compute_metrics(model_output, model_config)
            system_metrics = {"response_time": {"response_time_ms": response_time_ms}}

            # Notify tracking backend about inference completion
            self.logger.debug(f"Inference completed for run '{run_id}', record '{record_id}' in {response_time_ms:.2f}ms")
            self.tracking_backend.on_inference_completed(InferenceCompletedEvent(run_id=run_id, record_id=record_id, output_data={"output": model_output.output}, duration_ms=response_time_ms, status=OperationStatus.SUCCESS))

            return EvaluationOutput(run_id=run_id, inference_output=model_output, metrics=metrics, system_metrics=system_metrics, model_display_name=model_display_name, metadata={"experiment_version": self.config.experiment.version})
        except Exception as e:
            # Notify tracking backend about inference failure (don't let tracking errors mask the original)
            try:
                self.tracking_backend.on_inference_completed(InferenceCompletedEvent(run_id=run_id, record_id=record_id, output_data={"error": str(e)}, duration_ms=0.0, status=OperationStatus.FAILED))
            except Exception:
                self.logger.warning(f"Failed to notify tracking backend of inference failure for record '{record_id}'")
            raise

    def _generate_unique_run_id(self, model_name: str, args: dict[str, Any]) -> str:
        """Generate a unique run ID for the evaluation.

        Returns:
            Unique run ID
        """
        name_too_long = len(model_name) > self._FILE_NAME_LENGTH_LIMIT
        if name_too_long:
            base_name = model_name.split("__")[0] if "__" in model_name else model_name
            trimmed_name = base_name[: self._FILE_NAME_LENGTH_LIMIT - 10]  # reserve space for '__' and 8 char hash
            json_str = json.dumps(args, sort_keys=True, separators=(",", ":"))
            hashed_suffix = hashlib.sha256(json_str.encode()).hexdigest()[:8]
            model_name = f"{trimmed_name}__{hashed_suffix}"

        # clean to ensure valid file name
        return re.sub(r'[/:*?"<>| ]', "_", model_name)

    def _encode_experiment_name(self, experiment_name: str) -> str:
        """Encode the experiment name to be used in the file name.

        Args:
            experiment_name: Name of the experiment
        Returns:
            Encoded experiment name
        """
        # Replace spaces with underscores and remove special characters
        return re.sub(r'[/\\:*?"<>|\s]', "_", experiment_name.lower())

    def _create_output_path(self, model_name: str, args: dict[str, Any]) -> Path:
        unique_run_id = self._generate_unique_run_id(model_name=model_name, args=args)
        output_path = self._current_experiment_dir / f"{unique_run_id}.jsonl"

        # ensure the output directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)
        return output_path

    def _save_evaluation_result(self, evaluation_output: EvaluationOutput, output_path: Path) -> None:
        """Save the evaluation results to a file.

        Args:
            evaluation_output: Evaluation output object containing the model inference result and metrics
        """
        # Save the result to a file
        self.metrics_logger.log_inference_result(evaluation_output, output_path)

    def _compute_metrics(self, inference_output: InferenceOutput, model_config: ModelVariantConfig) -> dict[str, dict[str, Any]]:
        """Compute metrics for a model inference output.

        Args:
            inference_output: The inference output to compute metrics for
            model_config: The model variant configuration containing optional metrics specification

        Returns:
            Dictionary of metric results {'metric_name': {'score': value, ...}}
        """
        self.logger.debug(f"Computing metrics for model inference output: {inference_output.to_dict()}")

        # Determine which metrics to compute
        metrics_to_compute = self._get_metrics_for_model(model_config)
        self.logger.debug(f"Computing metrics: {list(metrics_to_compute.keys())}")

        metric_results = {}

        for metric_name, metric in metrics_to_compute.items():
            try:
                self.logger.debug(f"Computing metric: {metric_name}")
                result = metric.compute(inference_output)
                metric_results[metric_name] = result
            except Exception:
                metric_results[metric_name] = None
                self.logger.exception(f"Failed to compute metric {metric_name} for model inference output: {inference_output.to_dict()}")

        return metric_results

    def _get_metrics_for_model(self, model_config: ModelVariantConfig) -> dict[str, Any]:
        """Get the metrics that should be computed for a specific model.

        Args:
            model_config: The model variant configuration with optional metrics list

        Returns:
            Dictionary of metric name to metric instance for the specified model
        """
        # Check if model has custom metrics specified
        model_config_dict = model_config.model_dump()
        specified_metrics = model_config_dict.get("metrics")

        if specified_metrics is None:
            # If no metrics specified, use all registered metrics
            self.logger.debug("No metrics specified for model, using all registered metrics")
            return self.metrics_registry

        # Validate that specified metrics exist in the registry
        metrics_to_compute = {}
        for metric_name in specified_metrics:
            if metric_name not in self.metrics_registry:
                error = f"Metric '{metric_name}' specified in model config but not found in metrics registry."
                self.logger.error(error)
                raise ValueError(error)
            metrics_to_compute[metric_name] = self.metrics_registry[metric_name]

        if not metrics_to_compute:
            error = f"No valid metrics found for model '{model_config.name}'. Make sure the specified metrics are registered in the config."
            self.logger.error(error)
            raise ValueError(error)

        return metrics_to_compute

    def _infer_record(self, record: dict[str, Any], model_name: str, model: BaseModel, **kwargs) -> dict[str, Any]:
        """Evaluate a single record using the specified model and args combination.

        Args:
            record: Record to evaluate
            model_name: Name of the model to use
            model: Model to use for evaluation (object)
            kwargs: Additional arguments for the model
        Returns:
            Evaluation result for the record
        """
        try:
            output = model.infer(input=record)
            self.logger.debug(f"Model output: {output}")
        except Exception:
            self.logger.exception(f"Inference failed for '{model_name}' with args {kwargs}")
            raise

        return InferenceOutput(output=output, model_name=model_name, record=record, args=kwargs)

    async def _infer_record_async(self, record: dict[str, Any], model_name: str, model: BaseModel, **kwargs) -> InferenceOutput:
        """Async version: Evaluate a single record using the specified model and args combination.

        Args:
            record: Record to evaluate
            model_name: Name of the model to use
            model: Model to use for evaluation (object)
            kwargs: Additional arguments for the model
        Returns:
            Evaluation result for the record
        """
        try:
            output = await model.infer_async(input=record)
            self.logger.debug(f"Model output: {output}")
        except Exception:
            self.logger.exception(f"Inference failed for '{model_name}' with args {kwargs}")
            raise

        return InferenceOutput(output=output, model_name=model_name, record=record, args=kwargs)

    async def _evaluate_record_async(self, record: dict[str, Any], run_id: str, model_name: str, model_display_name: str, model: Any, **kwargs) -> EvaluationOutput:
        """Async version: Infer output for a record and compute its metrics.

        Args:
            record: Record to evaluate
            run_id: Run ID (backend UUID if tracking enabled, otherwise descriptive name)
            model_name: Name of the model to use
            model_display_name: Display name for the model
            model: Model to use for evaluation (object)
            kwargs: Additional arguments for the model

        Returns:
            EvaluationOutput containing model inference output and computed metrics
        """
        # Notify tracking backend about inference start (enables autolog tracing)
        record_id = record.get("id", str(hash(str(record))))
        self.logger.debug(f"Inference started for run '{run_id}', record '{record_id}'")
        self.tracking_backend.on_inference_started(InferenceStartEvent(run_id=run_id, record_id=record_id, input_data=record))

        try:
            start_time = time.perf_counter()
            model_output = await self._infer_record_async(record, model_name, model, **kwargs)
            response_time_ms = (time.perf_counter() - start_time) * 1000

            model_config = self.models_registry[model_display_name]["config"]
            # Run CPU-intensive metric computation in executor to not block event loop
            loop = asyncio.get_running_loop()
            metrics = await loop.run_in_executor(None, self._compute_metrics, model_output, model_config)
            system_metrics = {"response_time": {"response_time_ms": response_time_ms}}

            # Notify tracking backend about inference completion
            self.logger.debug(f"Inference completed for run '{run_id}', record '{record_id}' in {response_time_ms:.2f}ms")
            self.tracking_backend.on_inference_completed(InferenceCompletedEvent(run_id=run_id, record_id=record_id, output_data={"output": model_output.output}, duration_ms=response_time_ms, status=OperationStatus.SUCCESS))

            return EvaluationOutput(run_id=run_id, inference_output=model_output, metrics=metrics, system_metrics=system_metrics, model_display_name=model_display_name, metadata={"experiment_version": self.config.experiment.version})
        except Exception as e:
            # Notify tracking backend about inference failure (don't let tracking errors mask the original)
            try:
                self.tracking_backend.on_inference_completed(InferenceCompletedEvent(run_id=run_id, record_id=record_id, output_data={"error": str(e)}, duration_ms=0.0, status=OperationStatus.FAILED))
            except Exception:
                self.logger.warning(f"Failed to notify tracking backend of inference failure for record '{record_id}'")
            raise

    def load_dataset(self, dataset_config: DatasetConfig | None = None, dataset_path: str | None = None) -> BaseDataset:
        """Load dataset from configuration.

        Args:
            dataset_config: Dataset configuration
            dataset_path: Optional path override

        Returns:
            BaseDataset instance
        """

        try:
            if dataset_path is not None:
                self.logger.info(f"Loading dataset from path: {dataset_path}")
                dataset_instance = self.dataset_factory.create_dataset(
                    dataset_type=dataset_path.split(".")[-1].lower(),
                    args={"data_path": dataset_path},
                    context=self.execution_context,
                )
                self.logger.info("Successfully loaded dataset")
            else:
                self.logger.info(f"Loading dataset: {dataset_config.name} type: {dataset_config.type}")
                dataset_instance = self.dataset_factory.create_dataset(
                    dataset_type=dataset_config.type,
                    args=dataset_config.args or {},
                    context=self.execution_context,
                    dataset_name=dataset_config.name,
                )
                self.logger.info(f"Successfully loaded dataset {dataset_config.name}")
            return dataset_instance
        except Exception:
            self.logger.exception("Failed to load dataset")
            raise

    async def _evaluate_model_async(self, dataset: BaseDataset, model_name: str, model_data: dict, tracker: ProgressTracker, output_path: Path) -> int:
        """Async evaluation of a single model using asyncio.as_completed for concurrent execution.

        Args:
            dataset: Dataset containing records to evaluate
            model_name: Name of the model
            model_data: Model data dictionary
            tracker: Progress tracker for tracking
            output_path: Path to save results

        Returns:
            Number of failed records.
        """
        model_instance = model_data["model"]
        model_args = model_data["args"]
        model_config = model_data["config"]
        model_config_name = model_config.name

        # Generate user-friendly run name
        run_name = self._generate_unique_run_id(model_name=model_name, args=model_args)

        # Start tracking run and use backend's UUID as run_id
        self.logger.debug(f"Starting run '{run_name}' for model '{model_name}'")
        run_id = self.tracking_backend.start_run(ModelRunStartEvent(run_id=run_name, model_name=model_name))

        # If no tracking backend, use run_name as run_id
        if run_id is None:
            run_id = run_name

        async def evaluate(record: dict) -> EvaluationOutput:
            """Evaluate a single record"""
            result = await self._evaluate_record_async(run_id=run_id, record=record, model_name=model_config_name, model_display_name=model_name, model=model_instance, **model_args)
            return result

        # Start model progress tracking
        total_tasks = len(dataset)
        tracker.begin_progress(model_name, total_tasks)

        # Create all tasks upfront so they start running concurrently
        tasks = []
        for record in dataset:
            task = asyncio.create_task(evaluate(record))
            tasks.append(task)

        # Evaluate all records concurrently
        failed_count = 0
        for task in asyncio.as_completed(tasks):
            try:
                evaluation_output = await task
                self._save_evaluation_result(evaluation_output, output_path)
            except Exception as e:
                failed_count += 1
                self.logger.exception(f"Error during async evaluation: {e}")
            finally:
                tracker.advance_progress()

        try:
            self.logger.debug(f"Analyzing and logging results for model: {model_name}")
            analyzed_results = self.metrics_aggregator.analyze_results(output_path)
            results_json_path = self.metrics_logger.log_results(analyzed_results, output_path)

            # Fire tracking events for results and artifacts
            self.tracking_backend.on_results_analyzed(ResultsAnalyzedEvent(run_id=run_id, metrics=analyzed_results.aggregated_metrics, tags=analyzed_results.tags))
            self.logger.debug(f"Artifact generated for run '{run_id}': {output_path}")
            self.tracking_backend.on_artifact_generated(ArtifactGeneratedEvent(run_id=run_id, artifact_path=output_path, artifact_type="jsonl"))
            self.tracking_backend.on_artifact_generated(ArtifactGeneratedEvent(run_id=run_id, artifact_path=results_json_path, artifact_type="json"))
            self.tracking_backend.on_run_completed(ModelRunCompletedEvent(run_id=run_id, status=OperationStatus.SUCCESS))
        except Exception as e:
            self.logger.exception(f"Error analyzing and logging results for model: {model_name}")
            self.tracking_backend.on_run_completed(ModelRunCompletedEvent(run_id=run_id, status=OperationStatus.FAILED, error=str(e)))

        tracker.finish_progress()
        return failed_count

    def evaluate(self, dataset: BaseDataset) -> dict:
        """Evaluate models on dataset records.

        Automatically routes sync models to ThreadPoolExecutor and async models to asyncio.as_completed
        for optimal performance. Uses simple logging instead of Rich progress bars when running in
        non-interactive environments like Azure ML.

        Args:
            dataset: Dataset to evaluate

        Returns:
            Summary dict with status, output_path, total_records, and failed_records count.
        """
        self.logger.info(f"Starting evaluation with tracking backend: {type(self.tracking_backend).__name__}")
        self.tracking_backend.on_experiment_started(ExperimentStartEvent(experiment_name=self.config.experiment.name, config=self.config.to_dict()))

        total_models = len(self.models_registry)
        total_records = len(dataset) * total_models

        with ProgressTracker(self.logger, total_models, self.console) as tracker:
            failed_records = self._run_evaluation_loop(dataset, tracker)

        self.logger.info("Evaluation completed successfully")

        # Cleanup models (close HTTP clients, connections, etc.)
        self._cleanup_models()

        # Notify tracking backend that experiment is complete
        self.tracking_backend.on_experiment_completed(ExperimentCompletedEvent(experiment_name=self.config.experiment.name))
        self.tracking_backend.on_shutdown()

        has_failures = failed_records > 0
        return {
            "status": "completed_with_errors" if has_failures else "completed",
            "output_path": str(self._current_experiment_dir),
            "total_records": total_records,
            "failed_records": failed_records,
            "models_evaluated": total_models,
        }

    def _run_evaluation_loop(self, dataset: BaseDataset, tracker: ProgressTracker) -> int:
        """Run the evaluation loop for all models.

        Args:
            dataset: Dataset to evaluate
            tracker: Progress tracker for tracking

        Returns:
            Total number of failed records across all models.
        """
        total_failed = 0
        for model_display_name, model_data in self.models_registry.items():
            model_instance = model_data["model"]
            model_args = model_data["args"]

            # Create output path for the model evaluation results
            output_path = self._create_output_path(model_name=model_display_name, args=model_args)
            output_path.parent.mkdir(parents=True, exist_ok=True)

            # Check if model is async and route to appropriate evaluation method
            if getattr(model_instance, "_is_async", False):
                total_failed += asyncio.run(self._evaluate_model_async(dataset=dataset, model_name=model_display_name, model_data=model_data, tracker=tracker, output_path=output_path))
            else:
                total_failed += self._evaluate_model_sync(dataset=dataset, model_name=model_display_name, model_data=model_data, tracker=tracker, output_path=output_path)
        return total_failed

    def _evaluate_model_sync(self, dataset: BaseDataset, model_name: str, model_data: dict, tracker: ProgressTracker, output_path: Path) -> int:
        """Sync evaluation of a single model using ThreadPoolExecutor.

        Args:
            dataset: Dataset containing records to evaluate
            model_name: Name of the model
            model_data: Model data dictionary
            tracker: Progress tracker for tracking
            output_path: Path to save results

        Returns:
            Number of failed records.
        """
        model_instance = model_data["model"]
        model_args = model_data["args"]
        model_config = model_data["config"]
        model_config_name = model_config.name

        # Generate user-friendly run name
        run_name = self._generate_unique_run_id(model_name=model_name, args=model_args)

        # Start tracking run and use backend's UUID as run_id
        self.logger.debug(f"Starting run '{run_name}' for model '{model_name}'")
        run_id = self.tracking_backend.start_run(ModelRunStartEvent(run_id=run_name, model_name=model_name))

        # If no tracking backend, use run_name as run_id
        if run_id is None:
            run_id = run_name

        # Initialize list to store all futures
        all_futures = []

        # Start model progress tracking
        total_tasks = len(dataset)
        tracker.begin_progress(model_name, total_tasks)

        max_workers = self.config.experiment.max_workers  # None = auto-calculate based on CPU count

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            for record in dataset:
                self.logger.debug(f"Submitting evaluation task for record with model: {model_name}, and args: {model_args}")
                future = executor.submit(self._evaluate_record, run_id=run_id, record=record, model_name=model_config_name, model_display_name=model_name, model=model_instance, **model_args)
                all_futures.append(future)

            # Wait for all futures to complete with progress tracking
            failed_count = 0
            for future in as_completed(all_futures):
                try:
                    evaluation_output = future.result()
                    self.logger.debug(f"Evaluation result: {evaluation_output}")
                    self._save_evaluation_result(evaluation_output, output_path)
                except Exception:
                    failed_count += 1
                    self.logger.exception("Error during evaluation")
                finally:
                    tracker.advance_progress()

        try:
            self.logger.debug(f"Analyzing and logging results for model: {model_name}")
            analyzed_results = self.metrics_aggregator.analyze_results(output_path)
            results_json_path = self.metrics_logger.log_results(analyzed_results, output_path)

            # Fire tracking events for results and artifacts
            self.tracking_backend.on_results_analyzed(ResultsAnalyzedEvent(run_id=run_id, metrics=analyzed_results.aggregated_metrics, tags=analyzed_results.tags))
            self.logger.debug(f"Artifact generated for run '{run_id}': {output_path}")
            self.tracking_backend.on_artifact_generated(ArtifactGeneratedEvent(run_id=run_id, artifact_path=output_path, artifact_type="jsonl"))
            self.tracking_backend.on_artifact_generated(ArtifactGeneratedEvent(run_id=run_id, artifact_path=results_json_path, artifact_type="json"))
            self.tracking_backend.on_run_completed(ModelRunCompletedEvent(run_id=run_id, status=OperationStatus.SUCCESS))
        except Exception as e:
            self.logger.exception(f"Error analyzing and logging results for model: {model_name}")
            self.tracking_backend.on_run_completed(ModelRunCompletedEvent(run_id=run_id, status=OperationStatus.FAILED, error=str(e)))

        tracker.finish_progress()
        return failed_count
