"""Progress tracking for model evaluation."""

from __future__ import annotations

from logging import Logger
from typing import Any

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)

from evee.utils.environment import is_rich_compatible_environment


class ProgressTracker:
    """Unified progress tracker that works in both interactive and non-interactive environments.

    In interactive mode (local), uses Rich progress bars.
    In non-interactive mode (Azure ML), uses simple logging.
    """

    def __init__(self, logger: Logger, total_models: int, console: Console | None = None):
        """Initialize the progress tracker.

        Args:
            logger: Logger instance for non-interactive output
            total_models: Total number of models to evaluate
            console: Rich console for interactive output
        """
        self._logger = logger
        self._total_models = total_models
        self._console = console
        self._is_interactive = is_rich_compatible_environment()

        # Rich progress state
        self._progress: Progress | None = None
        self._models_task: Any = None
        self._current_task: Any = None

        # Simple progress state
        self._completed_models = 0
        self._current_model = ""
        self._total_records = 0
        self._completed_records = 0

    def __enter__(self) -> ProgressTracker:
        """Enter the progress context."""
        if self._is_interactive:
            self._progress = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TextColumn("records:"),
                MofNCompleteColumn(),
                TextColumn("elapsed:"),
                TimeElapsedColumn(),
                TextColumn("remaining:"),
                TimeRemainingColumn(),
                console=self._console,
            )
            self._progress.__enter__()
            self._models_task = self._progress.add_task("Evaluating models", total=self._total_models)
        else:
            self._logger.info("Running in non-interactive mode (Azure ML), using simple progress logging")
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit the progress context."""
        if self._progress:
            self._progress.__exit__(*args)

    def begin_progress(self, model_name: str, total_records: int) -> None:
        """Begin tracking progress for a task.

        Args:
            model_name: Name of the model being evaluated
            total_records: Total number of records to process
        """
        self._current_model = model_name
        self._total_records = total_records
        self._completed_records = 0

        if self._is_interactive and self._progress:
            self._current_task = self._progress.add_task(f"Evaluating model {model_name}", total=total_records)
        else:
            self._logger.info(f"Starting model {self._completed_models + 1}/{self._total_models}: {model_name} ({total_records} records)")

    def advance_progress(self) -> None:
        """Advance progress after processing a record."""
        self._completed_records += 1

        if self._is_interactive and self._progress:
            self._progress.update(self._current_task, advance=1)
        else:
            # Log at ~10% intervals to avoid flooding logs for large datasets
            # For 100k records this logs ~10 times, for 10 records logs every record
            interval = max(1, self._total_records // 10)
            if self._completed_records % interval == 0 or self._completed_records == self._total_records:
                if self._total_records <= 0:
                    # Avoid division by zero when total records is unknown or zero
                    self._logger.info(f"  Progress: {self._completed_records} records (total unknown)")
                else:
                    pct = (self._completed_records / self._total_records) * 100
                    self._logger.info(f"  Progress: {self._completed_records}/{self._total_records} records ({pct:.1f}%)")

    def finish_progress(self) -> None:
        """Mark progress tracking as complete."""
        self._completed_models += 1

        if self._is_interactive and self._progress:
            self._progress.update(self._models_task, advance=1)
        else:
            self._logger.info(f"Completed {self._current_model} ({self._completed_records}/{self._total_records} records)")
            self._logger.info(f"Overall: {self._completed_models}/{self._total_models} models completed")
