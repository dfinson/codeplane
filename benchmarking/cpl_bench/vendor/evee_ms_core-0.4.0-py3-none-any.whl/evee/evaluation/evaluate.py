import click
from dotenv import load_dotenv

from evee.cli.utils.validators import parse_models
from evee.evaluation.model_evaluator import ModelEvaluator
from evee.logging.logger import setup_logger


def main(config_path: str, dataset_path: str = None, env_path: str = None, tracking_enabled: bool = True, model_filter: list[str] | None = None) -> dict:
    logger = setup_logger("evaluate")

    if env_path:
        logger.info("Starting model evaluation, loading environment variables file.")
        load_dotenv(dotenv_path=env_path, verbose=True, override=True)
    else:
        logger.info("Starting model evaluation, using system environment variables.")

    evaluator = ModelEvaluator(config_path=config_path, tracking_enabled=tracking_enabled, model_filter=model_filter)

    # If dataset_path is provided (e.g. from Azure ML mount), it overrides config
    dataset_config = evaluator.config.experiment.dataset
    dataset = evaluator.load_dataset(dataset_config=dataset_config, dataset_path=dataset_path)

    return evaluator.evaluate(dataset)


@click.command()
@click.option("--config", "-c", required=True, help="Path to config file")
@click.option("--dataset", "-d", required=False, help="Path to dataset file (optional, will be loaded from config if not provided)")
@click.option("--env", "-e", default=".env", help="Path to .env file (default: .env)")
@click.option("--no-tracking", is_flag=True, help="Disable tracking backend")
@click.option("--models", "-m", required=False, help="Comma-separated list of model names to evaluate (e.g., 'model_a,model_b'). If not specified, all models are evaluated.")
def cli(config, dataset, env, no_tracking, models):
    """
    Entry point for the evaluation script.

    This CLI is primarily used by compute backends (like Azure ML) to execute the evaluation
    logic on a remote target. It is NOT the primary user-facing CLI (which is `evee run`).
    """
    model_filter = parse_models(models)
    main(config, dataset, env, tracking_enabled=not no_tracking, model_filter=model_filter)


if __name__ == "__main__":
    cli()
