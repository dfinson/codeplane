import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import PosixPath
from typing import Any

from ..core.base_metric import BaseMetric
from ..logging.logger import setup_logger


@dataclass
class AggregatedMetrics:
    run_id: str
    aggregated_metrics: dict[str, Any]
    tags: dict[str, str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "aggregated_metrics": self.aggregated_metrics,
            "tags": self.tags,
        }


class MetricsAggregator:
    """Handles evaluation and aggregation of metrics from results files."""

    def __init__(self, metrics_registry: dict[str, BaseMetric]):
        """
        Args:
            metrics_registry: Registry mapping metric names to metric instances
        """
        self.metrics_registry = metrics_registry
        self.logger = setup_logger(self.__class__.__module__)

    def _add_metric_prefix(self, metric_name: str, aggregated_values: dict) -> dict:
        """Add metric name prefix to aggregated values.

        Args:
            metric_name: Name of the metric
            aggregated_values: Dictionary of aggregated values from the metric

        Returns:
            Dictionary with metric name prefixed to each key
        """
        return {
            f"{metric_name} - {key}": value
            for key, value in aggregated_values.items()
            if isinstance(value, int | float)  # Skip non-numeric values
        }

    def analyze_results(self, results_path: PosixPath) -> AggregatedMetrics:
        """Evaluate and aggregate metrics from a results file.

        Args:
            results_path: Path to the results file to evaluate

        Returns:
            AggregatedMetrics: containing aggregated metrics and tags

        Raises:
            Exception: If there's an error processing the results file
        """
        try:
            metric_results = {}
            metric_failures = defaultdict(int)
            record_count = 0
            tags = {}
            total_response_time = 0

            with open(results_path) as f:
                for line in f:
                    evaluation_dict = json.loads(line)
                    record_count += 1

                    # Set tags from first record
                    if record_count == 1:
                        run_id = evaluation_dict["run_id"]
                        tags = {**evaluation_dict["args"], **evaluation_dict["metadata"], "model_name": evaluation_dict["model_name"]}

                    # Group metrics
                    for metric_name, scores in evaluation_dict["metrics"].items():
                        if scores is None:
                            metric_failures[metric_name] += 1
                            continue
                        metric_results.setdefault(metric_name, []).append(scores)

                    # Accumulate response time
                    total_response_time += evaluation_dict["system_metrics"]["response_time"]["response_time_ms"]

            # Filter in only metrics with failures
            failures_to_report = {f"{metric_name} - Fail count": fail_count for metric_name, fail_count in metric_failures.items() if fail_count > 0}

            all_metrics = {
                "number_of_records": record_count,
                "average_response_time_ms": int(total_response_time / record_count) if record_count > 0 else 0,
                **failures_to_report,
            }

            # Let each metric aggregate its own results
            for metric_name, scores in metric_results.items():
                if metric_name not in self.metrics_registry:
                    self.logger.warning(f"Metric {metric_name} was not found in registry. Skipping.")
                    continue
                metric_instance = self.metrics_registry[metric_name]
                try:
                    aggregated = metric_instance.aggregate(scores)
                except Exception:
                    self.logger.exception(f"Failed to aggregate metric '{metric_name}'")
                    aggregated = {"Aggregation Failed": -1}
                prefixed = self._add_metric_prefix(metric_name, aggregated)
                all_metrics.update(prefixed)

            return AggregatedMetrics(
                run_id=run_id,
                aggregated_metrics=all_metrics,
                tags=tags,
            )

        except Exception:
            self.logger.exception(f"Failed to evaluate results. file: '{results_path}'")
            raise
