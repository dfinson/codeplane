"""Evee MCP Server implementation using FastMCP.

This module implements the Model Context Protocol server for Evee,
providing tools and resources for AI assistants to interact with
evaluation workflows.

The server uses FastMCP with a modular architecture:
    - Resources: Static reference information (evaluators, patterns, schemas)
    - Tools: Execution capabilities (run experiment, validate, discover)

Usage:
    # As a module
    python -m evee.mcp.server

    # Programmatically
    from evee.mcp.server import mcp
    mcp.run(transport="stdio")
"""

import json
import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent

from evee.execution.environment import EnvironmentResolver
from evee.execution.runner import ExecutionRunner
from evee.logging.logger import setup_logger
from evee.mcp.constants import SERVER_NAME, MimeTypes, ResourceURIs

logger = setup_logger(__name__)

# =============================================================================
# FastMCP Server Instance
# =============================================================================

mcp = FastMCP(SERVER_NAME)

# =============================================================================
# Execution Components (lazy initialized)
# =============================================================================

_resolver: EnvironmentResolver | None = None
_runner: ExecutionRunner | None = None


def get_runner() -> ExecutionRunner:
    """Get or create the execution runner."""
    global _resolver, _runner
    if _runner is None:
        _resolver = EnvironmentResolver()
        _runner = ExecutionRunner(_resolver)
    return _runner


# =============================================================================
# Resource URIs and MIME Types
# =============================================================================

# Path to built HTML for results viewer (shared UI component)
RESULTS_VIEWER_DIST = Path(__file__).parent.parent / "ui" / "results-viewer" / "dist"


# =============================================================================
# Resources
# =============================================================================


@mcp.resource(ResourceURIs.AZURE_EVALUATORS, mime_type=MimeTypes.JSON)
async def azure_evaluators_resource() -> str:
    """Azure AI Evaluation evaluators reference."""
    from evee.mcp.resources.evaluators import AzureEvaluatorsResource

    resource = AzureEvaluatorsResource()
    return await resource.read()


@mcp.resource(ResourceURIs.DECORATOR_PATTERNS, mime_type=MimeTypes.MARKDOWN)
async def decorator_patterns_resource() -> str:
    """Evee decorator patterns reference."""
    from evee.mcp.resources.patterns import DecoratorPatternsResource

    resource = DecoratorPatternsResource()
    return await resource.read()


@mcp.resource(ResourceURIs.CONFIG_SCHEMA, mime_type=MimeTypes.MARKDOWN)
async def config_schema_resource() -> str:
    """Configuration schema reference."""
    from evee.mcp.resources.config import ConfigSchemaResource

    resource = ConfigSchemaResource()
    return await resource.read()


@mcp.resource(ResourceURIs.CONNECTIONS, mime_type=MimeTypes.MARKDOWN)
async def connections_resource() -> str:
    """Connection configuration and usage patterns."""
    from evee.mcp.resources.connections import ConnectionsResource

    resource = ConnectionsResource()
    return await resource.read()


@mcp.resource(ResourceURIs.MODEL_PATTERNS, mime_type=MimeTypes.MARKDOWN)
async def model_patterns_resource() -> str:
    """Model implementation patterns reference."""
    from evee.mcp.resources.model_patterns import ModelPatternsResource

    resource = ModelPatternsResource()
    return await resource.read()


@mcp.resource(ResourceURIs.METRIC_PATTERNS, mime_type=MimeTypes.MARKDOWN)
async def metric_patterns_resource() -> str:
    """Metric implementation patterns reference."""
    from evee.mcp.resources.metric_patterns import MetricPatternsResource

    resource = MetricPatternsResource()
    return await resource.read()


@mcp.resource(
    ResourceURIs.RESULTS_VIEWER_APP,
    mime_type=MimeTypes.MCP_APP_HTML,
    meta={"ui": {"csp": {"resourceDomains": ["https://unpkg.com"]}}},
)
async def results_viewer_resource() -> str:
    """Results viewer MCP App HTML."""
    html_path = RESULTS_VIEWER_DIST / "index.html"

    if not html_path.exists():
        logger.warning(f"Results viewer app not built at: {html_path}")
        return _get_fallback_html()

    return html_path.read_text(encoding="utf-8")


def _get_fallback_html() -> str:
    """Fallback HTML when app is not built."""
    return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light dark">
    <title>Results Viewer - Not Built</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            padding: 20px;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.6;
        }
        code {
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 4px;
        }
        @media (prefers-color-scheme: dark) {
            body { background: #1a1a1a; color: #fff; }
            code { background: #333; }
        }
    </style>
</head>
<body>
    <h1>Results Viewer App Not Built</h1>
    <p>The results viewer UI has not been built yet.</p>
    <p>To build it, run:</p>
    <pre><code>cd src/evee/ui/results-viewer
npm install
npm run build</code></pre>
    <p>Then restart the MCP server.</p>
</body>
</html>"""


def _format_experiment_result(result) -> str:
    """Format experiment ToolResult as clean JSON with only essential fields."""
    data = result.to_dict()

    if not result.success:
        return json.dumps(data, indent=2)

    # Return only the fields that matter
    output = {
        "status": data.get("status", "unknown"),
        "output_path": data.get("output_path"),
        "total_records": data.get("total_records"),
        "failed_records": data.get("failed_records"),
        "models_evaluated": data.get("models_evaluated"),
        "evee_mcp_version": data.get("evee_mcp_version"),
        "evee_project_version": data.get("evee_project_version"),
    }

    if data.get("message"):
        output["message"] = data["message"]

    return json.dumps(output, indent=2)


# =============================================================================
# Tools
# =============================================================================


@mcp.tool(
    meta={
        "ui": {"resourceUri": ResourceURIs.RESULTS_VIEWER_APP},
        "ui/resourceUri": ResourceURIs.RESULTS_VIEWER_APP,  # legacy support
    }
)
async def view_results(output_path: str) -> list[TextContent]:
    """View experiment results with aggregated metrics and individual record details.

    Args:
        output_path: Path to a specific experiment output directory (e.g., output/my_exp_v1.0__2026-01-29) or a results JSON file
    """
    from evee.mcp.tools.view_results import ViewResultsTool

    tool = ViewResultsTool()
    result = await tool.execute({"output_path": output_path})
    data = result.to_dict()

    if not result.success:
        return [TextContent(type="text", text=json.dumps(data, indent=2))]

    # Build a concise text summary for the agent
    models = data.get("models", [])
    lines = [
        "The results are displayed in the Results Viewer UI panel.",
        "Do NOT repeat these metrics or write a summary table — the user can already see them in the UI.",
        "If you need specific values for analysis, refer to the raw JSON data in the second content block.",
        "",
        f"Results loaded successfully from: {data.get('output_path', output_path)}",
        f"Total models: {len(models)}",
        "",
    ]
    for m in models:
        display = m.get("model_display_name") or m.get("model_name", "unknown")
        metrics = m.get("summary", {}).get("aggregated_metrics", {})
        n_records = metrics.get("number_of_records", 0)
        avg_rt = metrics.get("average_response_time_ms")
        score_parts = []
        for k, v in metrics.items():
            if k in ("number_of_records", "average_response_time_ms"):
                continue
            if isinstance(v, (int, float)):
                score_parts.append(f"{k}={v:.3f}" if v < 10 else f"{k}={v:.1f}")
        line = f"  - {display} ({n_records} records"
        if avg_rt is not None:
            line += f", avg {avg_rt:.0f}ms"
        line += ")"
        if score_parts:
            line += ": " + ", ".join(score_parts)
        lines.append(line)

    return [
        TextContent(type="text", text="\n".join(lines)),
        TextContent(type="text", text=json.dumps(data, indent=2)),
    ]


@mcp.tool()
async def run_experiment(
    config_path: str = "experiment/config.yaml",
    working_dir: str | None = None,
    env_file: str | None = None,
) -> str:
    """Execute an evaluation workflow using the evee framework.

    Prerequisites:
        - A virtual environment (.venv, venv, or env) must exist in working_dir with evee installed
        - Alternatively, set experiment.runtime.python_executable in config.yaml

    Args:
        config_path: Path to the experiment configuration YAML file
        working_dir: Working directory for the experiment (defaults to current directory)
        env_file: Path to .env file for environment variables
    """
    from evee.mcp.tools.experiment import RunExperimentTool

    runner = get_runner()
    tool = RunExperimentTool(runner)
    result = await tool.execute(
        {
            "config_path": config_path,
            "project_path": working_dir or os.getcwd(),
            "env_file": env_file,
        }
    )
    return _format_experiment_result(result)


@mcp.tool()
async def validate_config(
    config_path: str = "experiment/config.yaml",
    working_dir: str | None = None,
    env_file: str = ".env",
) -> str:
    """Validate an experiment configuration file. Always recommended before running experiments.

    Prerequisites:
        - A virtual environment (.venv, venv, or env) must exist in working_dir with evee installed
        - Alternatively, set experiment.runtime.python_executable in config.yaml

    Args:
        config_path: Path to the experiment configuration YAML file
        working_dir: Working directory for validation (defaults to current directory)
        env_file: Path to .env file for environment variables (default: .env)
    """
    from evee.mcp.tools.validation import ValidateConfigTool

    runner = get_runner()
    tool = ValidateConfigTool(runner)
    result = await tool.execute(
        {
            "config_path": config_path,
            "project_path": working_dir or os.getcwd(),
            "env_file": env_file,
        }
    )
    return json.dumps(result.to_dict(), indent=2)


@mcp.tool()
async def fetch_documentation(topic: str) -> str:
    """Fetch evee documentation on a specific topic.

    Available topics:
        - connections: How to configure and use connections for AI services
        - models: Model implementation patterns (chat, agents, async, webhooks)
        - metrics: Metric implementation patterns (F1, ROUGE, LLM-judge, tool calls)
        - config: Configuration schema for experiment/config.yaml
        - decorators: Quick reference for @model, @metric, @dataset decorators
        - evaluators: List of available Azure AI evaluators

    Args:
        topic: The documentation topic to fetch (connections, models, metrics, config, decorators, evaluators)
    """
    topic_to_uri = {
        "connections": ResourceURIs.CONNECTIONS,
        "models": ResourceURIs.MODEL_PATTERNS,
        "metrics": ResourceURIs.METRIC_PATTERNS,
        "config": ResourceURIs.CONFIG_SCHEMA,
        "decorators": ResourceURIs.DECORATOR_PATTERNS,
        "evaluators": ResourceURIs.AZURE_EVALUATORS,
    }

    topic_lower = topic.lower().strip()
    if topic_lower not in topic_to_uri:
        available = ", ".join(topic_to_uri.keys())
        return json.dumps(
            {
                "success": False,
                "error": f"Unknown topic '{topic}'. Available topics: {available}",
            }
        )

    # Import the appropriate resource class and read it
    uri = topic_to_uri[topic_lower]

    if uri == ResourceURIs.CONNECTIONS:
        from evee.mcp.resources.connections import ConnectionsResource

        content = await ConnectionsResource().read()
    elif uri == ResourceURIs.MODEL_PATTERNS:
        from evee.mcp.resources.model_patterns import ModelPatternsResource

        content = await ModelPatternsResource().read()
    elif uri == ResourceURIs.METRIC_PATTERNS:
        from evee.mcp.resources.metric_patterns import MetricPatternsResource

        content = await MetricPatternsResource().read()
    elif uri == ResourceURIs.CONFIG_SCHEMA:
        from evee.mcp.resources.config import ConfigSchemaResource

        content = await ConfigSchemaResource().read()
    elif uri == ResourceURIs.DECORATOR_PATTERNS:
        from evee.mcp.resources.patterns import DecoratorPatternsResource

        content = await DecoratorPatternsResource().read()
    elif uri == ResourceURIs.AZURE_EVALUATORS:
        from evee.mcp.resources.evaluators import AzureEvaluatorsResource

        content = await AzureEvaluatorsResource().read()
    else:
        return json.dumps({"success": False, "error": f"Resource not found: {uri}"})

    return content


@mcp.tool()
async def list_components(
    component_type: str = "all",
    working_dir: str | None = None,
) -> str:
    """Discover available components in an evee project.

    Prerequisites:
        - A virtual environment (.venv, venv, or env) must exist in working_dir with evee installed
        - Alternatively, set experiment.runtime.python_executable in config.yaml

    Args:
        component_type: Type of components to list: 'all', 'models', 'metrics', or 'datasets'
        working_dir: Project directory to scan (defaults to current directory)
    """
    from evee.mcp.tools.discovery import ListComponentsTool

    runner = get_runner()
    tool = ListComponentsTool(runner)
    result = await tool.execute(
        {
            "component_type": component_type,
            "project_path": working_dir or os.getcwd(),
        }
    )
    return json.dumps(result.to_dict(), indent=2)


# =============================================================================
# Entry Points
# =============================================================================


def main() -> None:
    """Entry point for the Evee MCP server.

    This function is called when running:
        - python -m evee.mcp.server
    """
    import sys

    import evee

    logger.info(f"Starting Evee MCP Server v{evee.__version__}")
    logger.info(f"Python executable: {sys.executable}")

    # Always use stdio transport for CLI usage
    mcp.run(transport="stdio")


# Alias for main() - used by tests and for programmatic server startup
run_server = main


if __name__ == "__main__":
    main()
