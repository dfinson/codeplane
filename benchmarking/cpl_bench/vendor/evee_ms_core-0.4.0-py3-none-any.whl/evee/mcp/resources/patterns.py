"""Decorator patterns resource.

This module provides reference implementations showing correct usage
of the @model, @metric, and @dataset decorators in evee.
"""

from evee.mcp.constants import MimeTypes, ResourceURIs
from evee.mcp.resources.base import BaseResource, ResourceMetadata

# Decorator patterns content as a constant for easy maintenance
DECORATOR_PATTERNS_CONTENT = '''# Evee Decorator Quick Reference

Quick reference for @model, @metric, and @dataset decorators.

> **For comprehensive examples, see:**
> - `evee://docs/model-patterns` - Full model implementation guide
> - `evee://docs/metric-patterns` - Full metric implementation guide
> - `evee://docs/connections` - Connection configuration guide

## @model Decorator

Registers a class as a model for evaluation.

```python
from typing import Any
from evee import ExecutionContext, model

@model(name="my_model")
class MyModel:
    def __init__(self, context: ExecutionContext, connection_name: str, temperature: float = 0.7):
        """Initialize with config args. context is injected by evee."""
        self.connection = context.connections_registry[connection_name]
        self.temperature = temperature
    
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        """Perform inference on input from dataset record.
        
        Returns: Dict with output fields used by metric mappings.
        """
        return {"response": "...", "token_usage": {...}}
    
    def close(self) -> None:
        """Optional: Clean up resources (HTTP clients, etc.)"""
        pass
```

**Config.yaml:**
```yaml
models:
  - name: "my_model"
    args:
      - connection_name: ["gpt-4"]
      - temperature: [0.7, 0.9]  # Grid search creates variants
```

## @metric Decorator

Registers a class as a metric for evaluation.

```python
from typing import Any
from evee import metric

@metric(name="my_metric")
class MyMetric:
    def __init__(self, threshold: float = 0.5):
        """Initialize with config parameters."""
        self.threshold = threshold
    
    def compute(self, response: str, ground_truth: str) -> dict[str, Any]:
        """Compute metric for a single sample.
        
        Args are mapped from model output and dataset via config mapping.
        Returns: Dict with metric values.
        """
        score = calculate_score(response, ground_truth)
        return {"score": score}
    
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Aggregate all sample scores into summary metrics."""
        values = [s["score"] for s in scores]
        return {"mean_score": sum(values) / len(values)}
```

**Config.yaml:**
```yaml
metrics:
  - name: "my_metric"
    threshold: 0.8
    mapping:
      response: "model.response"        # From infer() output
      ground_truth: "dataset.label"     # From dataset record
```

## @dataset Decorator

Registers a class as a dataset loader.

```python
from typing import Any, Iterator
from evee import dataset

@dataset(name="my_dataset")
class MyDataset:
    def __init__(self, file_path: str):
        """Initialize with config args."""
        self.file_path = file_path
    
    def __iter__(self) -> Iterator[dict[str, Any]]:
        """Yield dataset records. Each becomes input to infer()."""
        yield {"question": "...", "context": "...", "ground_truth": "..."}
```

**Config.yaml:**
```yaml
dataset:
  name: "my_dataset"
  type: "jsonl"  # Built-in type, or use custom
  args:
    file_path: "data/my_data.jsonl"
```

## Connection Access

Models and metrics receive `context` for secure credential access and experiment metadata:

```python
from evee import ExecutionContext

@model(name="my_model")
class MyModel:
    def __init__(self, context: ExecutionContext, connection_name: str):
        conn = context.connections_registry[connection_name]
        
        # Available properties (all connections):
        conn.name          # Connection identifier
        conn.endpoint      # API endpoint URL
        
        # Common optional properties:
        conn.deployment    # Model deployment name
        conn.api_version   # API version
        conn.api_key       # API key (may be None for managed identity)
        conn.client_id     # Managed identity client ID
        
        # Any custom properties you defined in config.yaml
```

## ExecutionContext

The `ExecutionContext` is the recommended way for models, metrics, and datasets to access
connections and experiment-level information:

```python
from evee import ExecutionContext, model

@model(name="context_aware_model")
class ContextAwareModel:
    def __init__(self, context: ExecutionContext, connection_name: str):
        """Use context for experiment-aware behavior."""
        # Access connections through context
        conn = context.connections_registry[connection_name]
        
        # Access experiment metadata
        context.experiment_name     # Name from config
        context.experiment_version  # Version from config
        context.experiment_dir      # Resolved output directory (Path)
        context.output_path         # Configured output path
        context.tracking_enabled    # Whether tracking is active
        context.model_variant_id    # Unique identifier for this model variant
```

> `context` is an optional parameter — evee detects it in your `__init__` signature
> and injects it automatically. It provides both connections and experiment metadata.

## Mapping Reference

| Source | Syntax | Example |
|--------|--------|---------|
| Model output | `model.field` | `model.response` → `infer()["response"]` |
| Dataset record | `dataset.field` | `dataset.label` → `record["label"]` |

## CLI Commands

```bash
# List available metric types
evee metric list-types

# Add a new metric
evee metric add --type foundry --name F1ScoreEvaluator
evee metric add --type custom --name my_metric

# Validate configuration
evee validate

# List discovered components
evee list

# Run evaluation
evee run
```
'''


class DecoratorPatternsResource(BaseResource):
    """Resource providing decorator pattern reference implementations.

    This resource contains documentation and code examples showing
    the correct way to implement models, metrics, and datasets
    using evee's decorator system.

    The content is returned as Markdown for easy reading by LLMs.
    """

    @property
    def metadata(self) -> ResourceMetadata:
        """Return metadata for the decorator patterns resource."""
        return ResourceMetadata(
            uri=ResourceURIs.DECORATOR_PATTERNS,
            name="Decorator Patterns",
            description="Reference implementations showing correct @model, @metric, @dataset decorator usage",
            mime_type=MimeTypes.MARKDOWN,
        )

    async def read(self) -> str:
        """Read and return decorator patterns documentation.

        Returns:
            Markdown string containing decorator pattern examples.
        """
        return DECORATOR_PATTERNS_CONTENT
