"""Results Viewer MCP App resource.

This module provides the bundled HTML resource for the results viewer
MCP App UI, which displays experiment results interactively.
"""

from pathlib import Path

from evee.logging.logger import setup_logger
from evee.mcp.constants import ResourceURIs
from evee.mcp.resources.base import BaseResource, ResourceMetadata, ResourceReadError

logger = setup_logger(__name__)

# MIME type for MCP app resources (HTML with inline JS/CSS)
MCP_APP_MIME_TYPE = "text/html;type=mcp-app"


class ResultsViewerAppResource(BaseResource):
    """MCP resource for the results viewer app HTML.

    This resource serves the bundled single-file HTML app that provides
    an interactive UI for viewing experiment results. The HTML file is
    built from React source using Vite + vite-plugin-singlefile.

    The app:
    - Displays aggregated metrics from experiment runs
    - Shows individual record details with expandable views
    - Supports color-coded score visualization
    - Integrates with host theming via CSS variables

    Example:
        resource = ResultsViewerAppResource()
        html = await resource.read()
        # Returns bundled HTML with inline JS/CSS
    """

    def __init__(self, dist_path: Path | None = None):
        """Initialize the resource.

        Args:
            dist_path: Optional path to the dist directory containing mcp-app.html.
                      If None, uses the default location relative to this module.
        """
        if dist_path is None:
            # Default: look in apps/results-viewer/dist relative to mcp package
            self._dist_path = Path(__file__).parent.parent / "apps" / "results-viewer" / "dist"
        else:
            self._dist_path = dist_path

        logger.debug(f"ResultsViewerAppResource initialized with dist_path: {self._dist_path}")
        logger.debug(f"HTML file exists: {(self._dist_path / 'mcp-app.html').exists()}")

    @property
    def metadata(self) -> ResourceMetadata:
        """Return metadata for the results viewer app resource."""
        return ResourceMetadata(
            uri=ResourceURIs.RESULTS_VIEWER_APP,
            name="Results Viewer App",
            description="Interactive UI for viewing experiment results with metrics and record details",
            mime_type=MCP_APP_MIME_TYPE,
        )

    async def read(self) -> str:
        """Read the bundled HTML app.

        Returns:
            HTML content as string.

        Raises:
            ResourceReadError: If the HTML file cannot be read.
        """
        html_path = self._dist_path / "mcp-app.html"

        logger.info(f"Reading results viewer app from: {html_path}")
        logger.info(f"File exists: {html_path.exists()}")

        if not html_path.exists():
            logger.warning(f"Results viewer app not built. Expected at: {html_path}. Run 'npm run build' in src/evee/mcp/apps/results-viewer/")
            # Return a fallback message
            return self._get_fallback_html()

        try:
            content = html_path.read_text(encoding="utf-8")
            logger.info(f"Successfully read HTML file, length: {len(content)}")
            return content
        except Exception as e:
            logger.error(f"Failed to read results viewer app: {e}")
            raise ResourceReadError(self.metadata.uri, e) from e

    def _get_fallback_html(self) -> str:
        """Return fallback HTML when the app is not built.

        Returns:
            Simple HTML page with build instructions.
        """
        return """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light dark">
    <title>Results Viewer - Not Built</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            padding: 20px;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.6;
        }
        code {
            background: #f0f0f0;
            padding: 2px 6px;
            border-radius: 4px;
        }
        @media (prefers-color-scheme: dark) {
            body { background: #1a1a1a; color: #fff; }
            code { background: #333; }
        }
    </style>
</head>
<body>
    <h1>Results Viewer App Not Built</h1>
    <p>The results viewer MCP app has not been built yet.</p>
    <p>To build it, run:</p>
    <pre><code>cd src/evee/mcp/apps/results-viewer
npm install
npm run build</code></pre>
    <p>Then restart the MCP server.</p>
</body>
</html>"""
