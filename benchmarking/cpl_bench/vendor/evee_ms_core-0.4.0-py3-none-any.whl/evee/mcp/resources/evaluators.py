"""Azure AI Evaluators resource.

This module provides a reference list of available Azure AI evaluators
from the azure-ai-evaluation package, including how to wrap them as
evee metrics for use in evaluation workflows.
"""

import json
from pathlib import Path

from evee.mcp.constants import MimeTypes, ResourceURIs
from evee.mcp.resources.base import (
    BaseResource,
    ResourceMetadata,
    ResourceReadError,
)


class AzureEvaluatorsResource(BaseResource):
    """Resource providing Azure AI evaluators and how to use them in evee.

    This resource loads evaluator information from the azure_evaluators.json
    file bundled with the evee CLI, and provides context about how these
    evaluators are wrapped as evee metrics.

    Key concepts for AI assistants:
        - Azure evaluators must be WRAPPED as evee metrics to use in experiments
        - Use `evee metric add --type foundry --name <EvaluatorName>` to generate wrapper
        - Parameters are mapped using `model.*` (from model output) or `dataset.*` (from input data)

    The output includes:
        - List of available evaluators with their parameters
        - Instructions on how to wrap them as evee metrics
        - Parameter mapping conventions
        - Example wrapper code

    Example output structure:
        {
            "usage": {
                "description": "How to use Azure evaluators in evee",
                "cli_command": "evee metric add --type foundry --name F1ScoreEvaluator",
                "mapping_convention": {...}
            },
            "evaluators": [
                {
                    "name": "F1ScoreEvaluator",
                    "description": "...",
                    "init_params": [...],
                    "compute_params": [...],
                    "requires_model_config": false,
                    "requires_credentials": false
                },
                ...
            ],
            "example_wrapper": "..."
        }
    """

    @property
    def metadata(self) -> ResourceMetadata:
        """Return metadata for the Azure evaluators resource."""
        return ResourceMetadata(
            uri=ResourceURIs.AZURE_EVALUATORS,
            name="Azure AI Evaluators",
            description="Azure AI evaluators and how to wrap them as evee metrics",
            mime_type=MimeTypes.JSON,
        )

    def _get_evaluators_file_path(self) -> Path:
        """Get the path to the azure_evaluators.json file.

        Returns:
            Path to the evaluators JSON file.
        """
        # Navigate from mcp/resources to cli directory
        return Path(__file__).parent.parent.parent / "cli" / "azure_evaluators.json"

    def _format_evaluator(self, name: str, info: dict) -> dict:
        """Format a single evaluator with full context.

        Args:
            name: Evaluator class name.
            info: Raw evaluator info from JSON.

        Returns:
            Formatted evaluator dictionary with usage context.
        """
        # Extract init parameters (constructor args)
        init_params = []
        requires_model_config = False
        requires_credentials = False

        for param in info.get("parameters", []):
            category = param.get("category", "simple")
            if category == "model_config":
                requires_model_config = True
            elif category == "credential":
                requires_credentials = True
            elif category == "simple":
                init_params.append(
                    {
                        "name": param["name"],
                        "type": param.get("type", "Any"),
                        "required": param.get("required", False),
                        "default": param.get("default"),
                    }
                )

        # Extract compute parameters (callable args)
        compute_params = []
        for param in info.get("callable_params", []):
            compute_params.append(
                {
                    "name": param["name"],
                    "required": param.get("required", True),
                    "suggested_mapping": self._suggest_mapping(param["name"]),
                }
            )

        return {
            "name": name,
            "class_name": info.get("class_name", name),
            "init_params": init_params,
            "compute_params": compute_params,
            "requires_model_config": requires_model_config,
            "requires_credentials": requires_credentials,
            "cli_command": f"evee metric add --type foundry --name {name}",
        }

    def _suggest_mapping(self, param_name: str) -> str:
        """Suggest the evee mapping for a parameter name.

        Args:
            param_name: The parameter name from the evaluator.

        Returns:
            Suggested mapping string (model.* or dataset.*).
        """
        # Response typically comes from model output
        if param_name == "response":
            return "model.response"
        # These typically come from dataset
        if param_name in ("ground_truth", "query", "context", "question"):
            return f"dataset.{param_name}"
        # Default to dataset for unknown params
        return f"dataset.{param_name}"

    def _get_usage_context(self) -> dict:
        """Get usage documentation for AI assistants.

        Returns:
            Dictionary with usage instructions and examples.
        """
        return {
            "description": ("Azure AI evaluators from the azure-ai-evaluation package must be wrapped as evee metrics before use in experiments. The wrapper translates between evee's decorator-based system and Azure's evaluator API."),
            "cli_command": "evee metric add --type foundry --name <EvaluatorName>",
            "mapping_convention": {
                "model.*": "Values from the model's inference output (e.g., model.response)",
                "dataset.*": "Values from the input dataset record (e.g., dataset.ground_truth)",
            },
            "common_mappings": {
                "response": "model.response (the model's generated output)",
                "ground_truth": "dataset.ground_truth (expected answer from dataset)",
                "query": "dataset.query (input question/prompt from dataset)",
                "context": "dataset.context (retrieved context for RAG)",
            },
            "example_config": {
                "metrics": [
                    {
                        "name": "f1score",
                        "threshold": 0.5,
                        "mapping": {
                            "response": "model.response",
                            "ground_truth": "dataset.ground_truth",
                        },
                    }
                ]
            },
        }

    def _get_example_wrapper(self) -> str:
        """Get an example wrapper implementation.

        Returns:
            String containing example Python code.
        """
        return '''from typing import Any
from azure.ai.evaluation import F1ScoreEvaluator
from evee import metric, setup_logger

@metric(name="f1score")
class F1ScoreMetric:
    """Wrapper for Azure AI F1ScoreEvaluator."""

    def __init__(self, threshold: float = 0.5) -> None:
        self.logger = setup_logger(self.__class__.__module__)
        self.evaluator = F1ScoreEvaluator(threshold=threshold)

    def compute(self, response: str, ground_truth: str) -> dict[str, Any]:
        """Compute F1 score for a single sample."""
        result = self.evaluator(response=response, ground_truth=ground_truth)
        return {"f1_score": result.get("f1_score", 0.0)}

    def aggregate(self, results: list[dict[str, Any]]) -> dict[str, Any]:
        """Aggregate F1 scores across all samples."""
        scores = [r["f1_score"] for r in results if "f1_score" in r]
        return {"mean_f1_score": sum(scores) / len(scores) if scores else 0.0}'''

    async def read(self) -> str:
        """Read and return Azure evaluators with full usage context.

        Returns:
            JSON string containing evaluators, usage instructions, and examples.

        Raises:
            ResourceReadError: If the evaluators file cannot be read.
        """
        evaluators_file = self._get_evaluators_file_path()

        try:
            with open(evaluators_file, encoding="utf-8") as f:
                raw_evaluators = json.load(f)
        except FileNotFoundError as e:
            raise ResourceReadError(
                self.metadata.uri,
                cause=FileNotFoundError(f"Evaluators file not found: {evaluators_file}"),
            ) from e
        except json.JSONDecodeError as e:
            raise ResourceReadError(
                self.metadata.uri,
                cause=ValueError(f"Invalid JSON in evaluators file: {e}"),
            ) from e

        # Format each evaluator with full context
        formatted_evaluators = [self._format_evaluator(name, info) for name, info in sorted(raw_evaluators.items())]

        # Build complete response with usage context
        result = {
            "usage": self._get_usage_context(),
            "evaluators": formatted_evaluators,
            "example_wrapper": self._get_example_wrapper(),
            "total_count": len(formatted_evaluators),
        }

        return json.dumps(result, indent=2)
