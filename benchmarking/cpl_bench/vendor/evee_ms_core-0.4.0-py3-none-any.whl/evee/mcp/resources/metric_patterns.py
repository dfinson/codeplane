"""Metric implementation patterns resource.

This module provides comprehensive metric implementation patterns
showing how to build metrics for different evaluation scenarios.
"""

from evee.mcp.constants import MimeTypes, ResourceURIs
from evee.mcp.resources.base import BaseResource, ResourceMetadata

# Metric patterns content
METRIC_PATTERNS_CONTENT = '''# Evee Metric Patterns

Complete guide to implementing metrics in evee for evaluating model outputs.

## Metric Structure

A metric in evee:
1. Uses the `@metric` decorator to register the class
2. Implements `__init__` for setup (config args + optional `context` for connections and experiment info)
3. Implements `compute(**mapped_fields) -> dict` for per-sample scoring
4. Implements `aggregate(scores: list[dict]) -> dict` for summarization

```python
from typing import Any
from evee import metric

@metric(name="my_metric")
class MyMetric:
    def __init__(self, threshold: float = 0.5):
        """Initialize metric with config parameters.
        
        Args:
            threshold: Score threshold (from config.yaml)
        """
        self.threshold = threshold
    
    def compute(self, response: str, ground_truth: str) -> dict[str, Any]:
        """Compute metric for a single sample.
        
        Args are determined by the `mapping` config - evee maps values
        from model output and dataset to these parameter names.
        
        Returns:
            Dict with metric values (passed to aggregate)
        """
        score = calculate_score(response, ground_truth)
        return {"score": score, "passed": score >= self.threshold}
    
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Aggregate all sample scores into summary metrics.
        
        Args:
            scores: List of dicts from compute() for each sample
        
        Returns:
            Dict with aggregated metrics (displayed in results)
        """
        values = [s["score"] for s in scores]
        return {
            "mean_score": sum(values) / len(values),
            "pass_rate": sum(1 for s in scores if s["passed"]) / len(scores),
        }
```

## Config.yaml Mapping

The `mapping` config tells evee how to map values to your `compute()` parameters:

```yaml
metrics:
  - name: "my_metric"
    threshold: 0.8  # Passed to __init__
    mapping:
      response: "model.answer"           # compute(response=output["answer"])
      ground_truth: "dataset.label"      # compute(ground_truth=record["label"])
```

**Mapping Sources:**
- `model.X` → Value from model's `infer()` output dict
- `dataset.X` → Value from dataset record dict

## Pattern 1: Simple Text Comparison (F1 Score)

```python
from typing import Any
import numpy as np
from evee import metric


@metric(name="f1_score")
class F1ScoreMetric:
    """Token-level F1 score between response and ground truth."""
    
    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold
    
    def compute(self, response: str, ground_truth: str) -> dict[str, Any]:
        """Compute F1 score for a single sample."""
        # Tokenize
        pred_tokens = set(response.lower().split())
        truth_tokens = set(ground_truth.lower().split())
        
        # Calculate
        true_positives = len(pred_tokens & truth_tokens)
        precision = true_positives / len(pred_tokens) if pred_tokens else 0.0
        recall = true_positives / len(truth_tokens) if truth_tokens else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall > 0 else 0.0
        
        return {
            "f1_score": f1,
            "precision": precision,
            "recall": recall,
            "passed": f1 >= self.threshold,
        }
    
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Aggregate F1 scores using median."""
        f1_values = np.fromiter((s["f1_score"] for s in scores), dtype=float)
        return {
            "f1_score_median": float(np.median(f1_values)),
            "f1_score_mean": float(np.mean(f1_values)),
            "pass_rate": sum(1 for s in scores if s["passed"]) / len(scores),
        }
```

**Config.yaml:**
```yaml
metrics:
  - name: "f1_score"
    threshold: 0.7
    mapping:
      response: "model.answer"
      ground_truth: "dataset.ground_truth"
```

## Pattern 2: Using Azure AI Evaluators

Wrap Azure AI Evaluation library evaluators.

```python
from typing import Any
import numpy as np
from azure.ai.evaluation import RougeScoreEvaluator, RougeType
from evee import metric, setup_logger


@metric(name="rouge")
class RougeMetric:
    """ROUGE metric using Azure AI Evaluation."""
    
    def __init__(self, rouge_type: str = "ROUGE_L"):
        self.logger = setup_logger(self.__class__.__module__)
        
        # Parse rouge type from string
        try:
            rouge_type_enum = RougeType[rouge_type.upper()]
        except KeyError as e:
            valid = ", ".join(RougeType.__members__.keys())
            raise ValueError(f"Invalid rouge_type '{rouge_type}'. Must be: {valid}") from e
        
        self.evaluator = RougeScoreEvaluator(rouge_type_enum)
    
    def compute(self, response: str, ground_truth: str) -> dict[str, Any]:
        """Compute ROUGE score."""
        result = self.evaluator(response=response, ground_truth=ground_truth)
        return {
            "f1_score": result["rouge_f1_score"],
            "precision": result["rouge_precision"],
            "recall": result["rouge_recall"],
        }
    
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Aggregate ROUGE scores."""
        metrics = {}
        for key in ["f1_score", "precision", "recall"]:
            values = np.fromiter((s[key] for s in scores), dtype=float)
            metrics[f"{key}_median"] = float(np.median(values))
        return metrics
```

**Config.yaml:**
```yaml
metrics:
  - name: "rouge"
    rouge_type: "ROUGE_L"
    mapping:
      response: "model.answer"
      ground_truth: "dataset.ground_truth"
```

## Pattern 3: LLM-as-Judge Metric

Use an LLM to evaluate responses.

```python
from typing import Any
import numpy as np
from azure.identity import AzureCliCredential, get_bearer_token_provider
from openai import AzureOpenAI
from evee import ExecutionContext, metric, setup_logger


@metric(name="llm_judge")
class LLMJudgeMetric:
    """LLM-based evaluation metric."""
    
    def __init__(self, context: ExecutionContext, chat_connection_name: str, temperature: float = 0):
        self.logger = setup_logger(self.__class__.__module__)
        
        conn = context.connections_registry[chat_connection_name]
        
        # Set up client
        token_provider = get_bearer_token_provider(
            AzureCliCredential(),
            "https://cognitiveservices.azure.com/.default"
        )
        
        self.client = AzureOpenAI(
            azure_ad_token_provider=token_provider,
            api_version=conn.api_version,
            azure_endpoint=conn.endpoint,
        )
        self.deployment = conn.deployment
        self.temperature = temperature
        
        self.system_prompt = """You are an expert evaluator. Given a response and ground truth,
rate the response on a scale of 1-5 where:
1 = Completely wrong
2 = Mostly wrong  
3 = Partially correct
4 = Mostly correct
5 = Fully correct

Respond with ONLY a number (1-5)."""
    
    def compute(self, response: str, ground_truth: str) -> dict[str, Any]:
        """Use LLM to judge response quality."""
        prompt = f"Response: {response}\\n\\nGround Truth: {ground_truth}\\n\\nScore:"
        
        completion = self.client.chat.completions.create(
            model=self.deployment,
            messages=[
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": prompt},
            ],
            temperature=self.temperature,
            max_tokens=10,
        )
        
        try:
            score = int(completion.choices[0].message.content.strip())
            score = max(1, min(5, score))  # Clamp to 1-5
        except (ValueError, TypeError):
            self.logger.warning(f"Could not parse LLM score, defaulting to 3")
            score = 3
        
        return {
            "score": score,
            "normalized_score": (score - 1) / 4,  # 0-1 scale
        }
    
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Aggregate LLM judge scores."""
        values = np.fromiter((s["score"] for s in scores), dtype=float)
        normalized = np.fromiter((s["normalized_score"] for s in scores), dtype=float)
        return {
            "mean_score": float(np.mean(values)),
            "median_score": float(np.median(values)),
            "normalized_mean": float(np.mean(normalized)),
        }
```

**Config.yaml:**
```yaml
metrics:
  - name: "llm_judge"
    chat_connection_name: "gpt-4"
    temperature: 0
    mapping:
      response: "model.answer"
      ground_truth: "dataset.ground_truth"
```

## Pattern 4: Tool Call Evaluation

Evaluate agent tool usage.

```python
from typing import Any
import numpy as np
from evee import metric, setup_logger


@metric(name="tool_call_f1")
class ToolCallF1Metric:
    """Evaluate agent tool calls using F1 score."""
    
    def __init__(self):
        self.logger = setup_logger(self.__class__.__module__)
    
    def compute(self, tool_calls: list[str], expected_tool_calls: list[str]) -> dict[str, Any]:
        """Compute precision, recall, F1 for tool calls.
        
        Args:
            tool_calls: List of tool names called by the agent
            expected_tool_calls: List of expected tool names from dataset
        """
        actual_set = set(tool_calls)
        expected_set = set(expected_tool_calls)
        
        true_positives = len(actual_set & expected_set)
        
        recall = true_positives / len(expected_set) if expected_set else 1.0
        precision = true_positives / len(actual_set) if actual_set else 1.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall > 0 else 0.0
        
        return {
            "f1_score": f1,
            "precision": precision,
            "recall": recall,
            "true_positives": true_positives,
            "total_actual": len(actual_set),
            "total_expected": len(expected_set),
        }
    
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Aggregate tool call metrics."""
        return {
            "f1_median": float(np.median([s["f1_score"] for s in scores])),
            "precision_median": float(np.median([s["precision"] for s in scores])),
            "recall_median": float(np.median([s["recall"] for s in scores])),
        }
```

**Config.yaml:**
```yaml
metrics:
  - name: "tool_call_f1"
    mapping:
      tool_calls: "model.tool_calls"
      expected_tool_calls: "dataset.expected_tool_calls"
```

## Pattern 5: Token Usage Tracking

Track inference costs.

```python
from typing import Any
import numpy as np
from evee import metric


@metric(name="token_usage")
class TokenUsageMetric:
    """Track token usage for cost analysis."""
    
    def __init__(self):
        pass
    
    def compute(self, token_usage: dict[str, int]) -> dict[str, Any]:
        """Extract token counts from model output."""
        return {
            "prompt_tokens": token_usage.get("prompt_tokens", 0),
            "completion_tokens": token_usage.get("completion_tokens", 0),
            "total_tokens": token_usage.get("total_tokens", 0),
        }
    
    def aggregate(self, scores: list[dict[str, Any]]) -> dict[str, float]:
        """Sum total token usage."""
        return {
            "total_prompt_tokens": sum(s["prompt_tokens"] for s in scores),
            "total_completion_tokens": sum(s["completion_tokens"] for s in scores),
            "total_tokens": sum(s["total_tokens"] for s in scores),
            "avg_tokens_per_sample": np.mean([s["total_tokens"] for s in scores]),
        }
```

**Config.yaml:**
```yaml
metrics:
  - name: "token_usage"
    mapping:
      token_usage: "model.token_usage"
```

## Using evee metric add CLI

Scaffold a new metric with:

```bash
# List available Azure AI evaluator types
evee metric list-types

# Add a Foundry evaluator
evee metric add --type foundry --name CoherenceEvaluator

# Add a custom metric
evee metric add --type custom --name my_custom_metric
```

The generated file will need customization - implement `compute()` and `aggregate()`.

## Mapping Reference

| Source | Syntax | Description |
|--------|--------|-------------|
| Model output | `model.field_name` | Value from `infer()` return dict |
| Dataset record | `dataset.field_name` | Value from dataset record |

Examples:
```yaml
mapping:
  response: "model.answer"           # output["answer"]
  ground_truth: "dataset.label"      # record["label"]
  context: "dataset.context"         # record["context"]
  tool_calls: "model.tool_calls"     # output["tool_calls"]
```

## Best Practices

1. **Return consistent keys** - Use the same keys in all `compute()` returns
2. **Handle edge cases** - Check for empty lists, None values
3. **Use numpy for aggregation** - More efficient for large result sets
4. **Log warnings** - Use `setup_logger` for debugging issues
5. **Document score ranges** - Note what values mean (0-1, 1-5, etc.)
6. **Validate inputs** - Raise clear errors on invalid mapping data
'''


class MetricPatternsResource(BaseResource):
    """Resource providing metric implementation patterns.

    This resource contains comprehensive examples of how to implement
    metrics in evee for different evaluation scenarios: text comparison,
    Azure AI evaluators, LLM-as-judge, tool call evaluation, etc.
    """

    @property
    def metadata(self) -> ResourceMetadata:
        """Return metadata for the metric patterns resource."""
        return ResourceMetadata(
            uri=ResourceURIs.METRIC_PATTERNS,
            name="Metric Patterns",
            description="Comprehensive guide to implementing metrics in evee",
            mime_type=MimeTypes.MARKDOWN,
        )

    async def read(self) -> str:
        """Read and return metric patterns documentation.

        Returns:
            Markdown string containing metric pattern examples.
        """
        return METRIC_PATTERNS_CONTENT
