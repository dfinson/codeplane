"""Connection properties and patterns resource.

This module provides documentation on how evee connections work,
their properties, and how to use them in models and metrics.
"""

from evee.mcp.constants import MimeTypes, ResourceURIs
from evee.mcp.resources.base import BaseResource, ResourceMetadata

# Connection patterns content
CONNECTIONS_CONTENT = """# Evee Connections Guide

Connections in evee are configured in `config.yaml` and provide access to AI services
(Azure OpenAI, AI Foundry projects, webhooks, etc.) without hardcoding credentials.

## Connection Configuration

Connections are defined in the `connections` section of your config.yaml:

```yaml
experiment:
  connections:
    - name: "my_connection"
      # Fields depend on your use case (see below)
      endpoint: "${AZURE_OPENAI_ENDPOINT}"
      deployment: "gpt-4"
      api_version: "2024-12-01-preview"
      api_key: "${AZURE_OPENAI_API_KEY:-}"
      client_id: "${DEFAULT_IDENTITY_CLIENT_ID:-}"
```

## Connection Properties

The `ConnectionConfig` model uses `extra="allow"`, meaning you can add **any fields** your model needs.
However, the following fields have built-in support:

| Property | Type | Description |
|----------|------|-------------|
| `name` | str | **Required**. Unique identifier for this connection |

### Custom Fields

You can add any custom field - evee will pass it through:

```yaml
connections:
  - name: "webhook"
    endpoint: "${WEBHOOK_URL}"
    timeout: 30
    custom_header: "X-Custom-Value"
```

## Accessing Connections in Models

Connections are available through the `ExecutionContext` injected into your model's `__init__`:

```python
from typing import Any
from evee import ExecutionContext, model

@model(name="my_model")
class MyModel:
    def __init__(self, context: ExecutionContext, connection_name: str):
        # Get the connection object by name
        connection = context.connections_registry[connection_name]
        
        # Access standard properties
        self.endpoint = connection.endpoint
        self.deployment = connection.deployment
        self.api_version = connection.api_version
        self.api_key = connection.api_key      # May be None if using managed identity
        self.client_id = connection.client_id  # For managed identity auth
        
        # Access experiment metadata from context
        # context.experiment_name, context.experiment_dir, context.model_variant_id, etc.
        
        # Access any custom properties you defined
        # self.timeout = getattr(connection, 'timeout', 30)
```

## Common Connection Patterns

### Pattern 1: Azure OpenAI with API Key

```yaml
connections:
  - name: "gpt-4"
    endpoint: "${AZURE_OPENAI_ENDPOINT}"
    deployment: "gpt-4"
    api_version: "2024-12-01-preview"
    api_key: "${AZURE_OPENAI_API_KEY}"
```

```python
from openai import AzureOpenAI
from evee import ExecutionContext

@model(name="gpt4_model")
class GPT4Model:
    def __init__(self, context: ExecutionContext, connection_name: str):
        conn = context.connections_registry[connection_name]
        self.client = AzureOpenAI(
            api_key=conn.api_key,
            api_version=conn.api_version,
            azure_endpoint=conn.endpoint,
        )
        self.deployment = conn.deployment
```

### Pattern 2: Azure with Managed Identity (DefaultAzureCredential)

```yaml
connections:
  - name: "gpt-4"
    endpoint: "${AZURE_OPENAI_ENDPOINT}"
    deployment: "gpt-4"
    api_version: "2024-12-01-preview"
    api_key: ""  # Empty = use managed identity
    client_id: "${DEFAULT_IDENTITY_CLIENT_ID:-}"
```

```python
from azure.identity import AzureCliCredential, ChainedTokenCredential, ManagedIdentityCredential, get_bearer_token_provider
from openai import AzureOpenAI
from evee import ExecutionContext

@model(name="managed_identity_model")
class ManagedIdentityModel:
    def __init__(self, context: ExecutionContext, connection_name: str):
        conn = context.connections_registry[connection_name]
        
        # Use ChainedTokenCredential for local dev (CLI) + production (MI)
        credentials = ChainedTokenCredential(
            AzureCliCredential(),
            ManagedIdentityCredential(client_id=conn.client_id)
        )
        token_provider = get_bearer_token_provider(
            credentials, 
            "https://cognitiveservices.azure.com/.default"
        )
        
        self.client = AzureOpenAI(
            azure_ad_token_provider=token_provider,
            api_version=conn.api_version,
            azure_endpoint=conn.endpoint,
        )
        self.deployment = conn.deployment
```

### Pattern 3: Azure AI Foundry Project

```yaml
connections:
  - name: "foundry_project"
    endpoint: "${AZURE_AI_FOUNDRY_PROJECT_ENDPOINT}"
```

```python
from azure.ai.projects import AIProjectClient
from azure.identity import AzureCliCredential
from evee import ExecutionContext

@model(name="foundry_model")
class FoundryModel:
    def __init__(self, context: ExecutionContext, project_connection: str, chat_connection: str):
        project_conn = context.connections_registry[project_connection]
        chat_conn = context.connections_registry[chat_connection]
        
        # AIProjectClient only needs endpoint + credential
        self.project_client = AIProjectClient(
            endpoint=project_conn.endpoint,
            credential=AzureCliCredential(),
        )
        
        # Get OpenAI-compatible client from project
        self.openai_client = self.project_client.get_openai_client()
        self.deployment = chat_conn.deployment
    
    def close(self):
        self.openai_client.close()
        self.project_client.close()
```

### Pattern 4: Generic Webhook/API

```yaml
connections:
  - name: "webhook"
    endpoint: "${WEBHOOK_ENDPOINT}"
    api_key: "${WEBHOOK_API_KEY:-}"
```

```python
import httpx
from evee import ExecutionContext

@model(name="webhook_model")
class WebhookModel:
    def __init__(self, context: ExecutionContext, connection_name: str):
        conn = context.connections_registry[connection_name]
        self.endpoint = conn.endpoint
        self.api_key = conn.api_key
        self.client = httpx.Client(timeout=30)
    
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
        response = self.client.post(self.endpoint, json=input, headers=headers)
        return response.json()
    
    def close(self):
        self.client.close()
```

## Environment Variable Substitution

Evee supports POSIX-style env var substitution:

| Syntax | Description |
|--------|-------------|
| `${VAR}` | Required - error if not set |
| `${VAR:-default}` | Use default if VAR is unset or empty |
| `${VAR:-}` | Optional - empty string if not set |

Examples:

```yaml
connections:
  - name: "prod"
    endpoint: "${AZURE_OPENAI_ENDPOINT}"           # Required
    api_key: "${AZURE_OPENAI_API_KEY:-}"           # Optional (empty = use managed identity)
    client_id: "${IDENTITY_CLIENT_ID:-}"           # Optional managed identity
    timeout: "${TIMEOUT:-30}"                       # Optional with default
```

## Accessing Connections in Metrics

Metrics also receive `context` with access to connections:

```python
from evee import ExecutionContext, metric

@metric(name="llm_judge")
class LLMJudgeMetric:
    def __init__(self, context: ExecutionContext, chat_connection_name: str, temperature: float):
        conn = context.connections_registry[chat_connection_name]
        # ... initialize your LLM client
```

Configure in config.yaml:

```yaml
metrics:
  - name: "llm_judge"
    chat_connection_name: "gpt-4"
    temperature: 0
    mapping:
      response: "model.answer"
      ground_truth: "dataset.ground_truth"
```

## Best Practices

1. **Never hardcode credentials** - Always use environment variables
2. **Use `api_key: "${VAR:-}"` pattern** - Falls back to managed identity when empty
3. **Add `close()` method** - Clean up HTTP clients to avoid resource leaks
4. **One connection per service** - Reuse connections across models via names
5. **Validate early** - Check connection properties in `__init__`, not `infer`
"""


class ConnectionsResource(BaseResource):
    """Resource providing connection configuration and usage documentation.

    This resource explains how evee connections work, their properties,
    and common patterns for using them with different AI services.
    """

    @property
    def metadata(self) -> ResourceMetadata:
        """Return metadata for the connections resource."""
        return ResourceMetadata(
            uri=ResourceURIs.CONNECTIONS,
            name="Connection Patterns",
            description="Guide to configuring and using connections for AI services",
            mime_type=MimeTypes.MARKDOWN,
        )

    async def read(self) -> str:
        """Read and return connections documentation.

        Returns:
            Markdown string containing connection patterns and examples.
        """
        return CONNECTIONS_CONTENT
