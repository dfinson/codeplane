"""Model implementation patterns resource.

This module provides comprehensive model implementation patterns
showing how to build models with different capabilities.
"""

from evee.mcp.constants import MimeTypes, ResourceURIs
from evee.mcp.resources.base import BaseResource, ResourceMetadata

# Model patterns content
MODEL_PATTERNS_CONTENT = '''# Evee Model Patterns

Complete guide to implementing models in evee with real-world patterns.

## Model Structure

A model in evee:
1. Uses the `@model` decorator to register the class
2. Implements `__init__` for setup (receives config args + `context` for connections and experiment info)
3. Implements `infer(input: dict) -> dict` for inference
4. Optionally implements `close()` for cleanup

```python
from typing import Any
from evee import ExecutionContext, model

@model(name="my_model")
class MyModel:
    def __init__(self, context: ExecutionContext, connection_name: str, temperature: float = 0.7):
        """Initialize model with config parameters.
        
        Args:
            context: Execution context with connections and experiment metadata (injected by evee)
            connection_name: Name of connection to use (from config.yaml)
            temperature: Sampling temperature (from config.yaml args)
        """
        self.connection = context.connections_registry[connection_name]
        self.temperature = temperature
        # Initialize your client here
    
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        """Perform inference on a single dataset record.
        
        Args:
            input: Dict containing fields from your dataset record
        
        Returns:
            Dict with output fields (used in metric mappings)
        """
        # Your inference logic
        return {"response": "...", "token_usage": {...}}
    
    def close(self) -> None:
        """Optional: Clean up resources like HTTP clients."""
        pass
```

## Pattern 1: Basic Azure OpenAI Chat

Simple chat completion model with error handling and retries.

```python
from typing import Any

from azure.identity import AzureCliCredential, ChainedTokenCredential, ManagedIdentityCredential, get_bearer_token_provider
from openai import OpenAI, RateLimitError
from tenacity import retry, retry_if_exception_type, wait_exponential

from evee import ExecutionContext, model


@model(name="chat_model")
class ChatModel:
    """Basic Azure OpenAI chat completion model."""

    def __init__(self, context: ExecutionContext, chat_connection_name: str, temperature: float, max_tokens: int):
        self.connection = context.connections_registry[chat_connection_name]
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        # Set up Azure AD auth with managed identity fallback
        credentials = ChainedTokenCredential(
            AzureCliCredential(),
            ManagedIdentityCredential(client_id=self.connection.client_id)
        )
        token_provider = get_bearer_token_provider(
            credentials, 
            "https://cognitiveservices.azure.com/.default"
        )
        
        self.client = OpenAI(
            base_url=self.connection.endpoint,
            api_key=token_provider
        )
    
    @retry(
        retry=retry_if_exception_type(RateLimitError),
        wait=wait_exponential(multiplier=1, max=300),
        reraise=True,
    )
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        completion = self.client.chat.completions.create(
            model=self.connection.deployment,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": input.get("question")},
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        
        return {
            "answer": completion.choices[0].message.content,
            "token_usage": {
                "prompt_tokens": completion.usage.prompt_tokens,
                "completion_tokens": completion.usage.completion_tokens,
                "total_tokens": completion.usage.total_tokens,
            },
        }
```

**Config.yaml:**
```yaml
models:
  - name: "chat_model"
    args:
      - temperature: [0.7]
      - max_tokens: [1000]
      - chat_connection_name: ["gpt-4"]

connections:
  - name: "gpt-4"
    endpoint: "${AZURE_OPENAI_ENDPOINT}"
    deployment: "gpt-4"
    client_id: "${DEFAULT_IDENTITY_CLIENT_ID:-}"
```

## Pattern 2: Agent with Function Calling (Tools)

Model that uses function tools and executes them in a loop.

```python
import json
from typing import Any

from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import FunctionTool, PromptAgentDefinition
from azure.identity import AzureCliCredential
from openai import RateLimitError
from tenacity import retry, retry_if_exception_type, wait_exponential

from evee import ExecutionContext, model


@model(name="agent_with_tools")
class AgentWithTools:
    """Agent model with function calling capabilities."""

    # Define tools as class attributes
    search_tool = FunctionTool(
        name="search_knowledge_base",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
            },
            "required": ["query"],
            "additionalProperties": False,
        },
        description="Search the knowledge base for relevant information.",
        strict=True,
    )
    
    calculate_tool = FunctionTool(
        name="calculate",
        parameters={
            "type": "object",
            "properties": {
                "expression": {"type": "string", "description": "Math expression"},
            },
            "required": ["expression"],
            "additionalProperties": False,
        },
        description="Calculate a mathematical expression.",
        strict=True,
    )
    
    def __init__(self, context: ExecutionContext, project_connection: str, chat_connection: str):
        project_conn = context.connections_registry[project_connection]
        chat_conn = context.connections_registry[chat_connection]
        
        self.project_client = AIProjectClient(
            endpoint=project_conn.endpoint,
            credential=AzureCliCredential(),
        )
        
        # Create or update the agent
        self.agent_name = f"evee-agent-{chat_conn.name}"
        self.agent = self.project_client.agents.create_version(
            agent_name=self.agent_name,
            definition=PromptAgentDefinition(
                model=chat_conn.deployment,
                tools=[self.search_tool, self.calculate_tool],
                instructions="You are a helpful assistant. Use tools when needed.",
            ),
        )
        
        self.openai_client = self.project_client.get_openai_client()
    
    def _execute_tool(self, name: str, arguments: dict[str, Any]) -> str:
        """Execute a tool by name."""
        if name == "search_knowledge_base":
            return self._search(arguments["query"])
        elif name == "calculate":
            return self._calculate(arguments["expression"])
        return f"Unknown tool: {name}"
    
    def _search(self, query: str) -> str:
        # Your search implementation
        return f"Results for: {query}"
    
    def _calculate(self, expression: str) -> str:
        # Your calculation implementation
        try:
            result = eval(expression)  # Note: use safe eval in production!
            return str(result)
        except Exception as e:
            return f"Error: {e}"

    @retry(
        retry=retry_if_exception_type(RateLimitError),
        wait=wait_exponential(multiplier=1, max=60),
        reraise=True,
    )
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        conversation = self.openai_client.conversations.create()
        
        user_input = f"context: {input['context']}\\nquestion: {input['question']}"
        
        response = self.openai_client.responses.create(
            conversation=conversation.id,
            extra_body={"agent": {"name": self.agent_name, "type": "agent_reference"}},
            input=user_input,
            tool_choice="auto",
        )
        
        all_tool_calls = []
        total_usage = dict(response.usage)
        
        # Process tool calls until we get a final text response
        max_iterations = 10
        for _ in range(max_iterations):
            tool_outputs = []
            has_function_calls = False
            
            for item in response.output:
                if item.type == "function_call":
                    has_function_calls = True
                    all_tool_calls.append(item.name)
                    args = json.loads(item.arguments)
                    result = self._execute_tool(item.name, args)
                    tool_outputs.append({
                        "type": "function_call_output",
                        "call_id": item.call_id,
                        "output": result,
                    })
            
            if not has_function_calls:
                break
            
            # Send tool results back
            response = self.openai_client.responses.create(
                conversation=conversation.id,
                extra_body={"agent": {"name": self.agent_name, "type": "agent_reference"}},
                input=tool_outputs,
                tool_choice="auto",
            )
            total_usage["total_tokens"] += response.usage.total_tokens
        
        return {
            "answer": response.output_text,
            "tool_calls": all_tool_calls,
            "token_usage": total_usage,
        }
    
    def close(self) -> None:
        """Clean up clients."""
        self.openai_client.close()
        self.project_client.close()
```

**Config.yaml:**
```yaml
models:
  - name: "agent_with_tools"
    args:
      - project_connection: ["foundry_project"]
      - chat_connection: ["gpt-4"]

connections:
  - name: "foundry_project"
    endpoint: "${AZURE_AI_FOUNDRY_PROJECT_ENDPOINT}"
  
  - name: "gpt-4"
    deployment: "gpt-4"
    endpoint: "${AZURE_OPENAI_ENDPOINT}"
```

## Pattern 3: Async Model

For high-throughput scenarios with concurrent API calls.

```python
from typing import Any

import httpx
from openai import AsyncAzureOpenAI

from evee import ExecutionContext, model


@model(name="async_model")
class AsyncModel:
    """Async model for concurrent inference."""

    def __init__(self, context: ExecutionContext, connection_name: str):
        conn = context.connections_registry[connection_name]
        
        self.client = AsyncAzureOpenAI(
            api_key=conn.api_key,
            api_version=conn.api_version,
            azure_endpoint=conn.endpoint,
        )
        self.deployment = conn.deployment
    
    async def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        """Async inference - evee handles sync/async bridging."""
        response = await self.client.chat.completions.create(
            model=self.deployment,
            messages=[{"role": "user", "content": input["question"]}],
        )
        
        return {
            "answer": response.choices[0].message.content,
            "token_usage": {"total_tokens": response.usage.total_tokens},
        }
    
    async def close(self) -> None:
        """Async cleanup."""
        await self.client.close()
```

## Pattern 4: Model with External Prompt File

Load prompts from separate files for better organization.

```python
from pathlib import Path
from typing import Any

from evee import ExecutionContext, model


@model(name="prompt_model")
class PromptModel:
    """Model loading prompt from external file."""

    def __init__(self, context: ExecutionContext, connection_name: str, prompt: str):
        self.connection = context.connections_registry[connection_name]
        
        # Load prompt from file relative to this model
        prompt_path = Path(__file__).parent / f"{prompt}.txt"
        if not prompt_path.exists():
            raise FileNotFoundError(f"Prompt file not found: {prompt_path}")
        self.system_prompt = prompt_path.read_text().strip()
        
        # Initialize client...
    
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        # Use self.system_prompt in your messages
        ...
```

**Config.yaml (test multiple prompts):**
```yaml
models:
  - name: "prompt_model"
    args:
      - connection_name: ["gpt-4"]
      - prompt: ["baseline", "few_shot", "chain_of_thought"]
```

## Pattern 5: Webhook/External API Model

Integrate with external services via webhooks.

```python
from typing import Any

import httpx

from evee import ExecutionContext, model


@model(name="webhook_model")
class WebhookModel:
    """Model calling an external webhook/API."""

    def __init__(self, context: ExecutionContext, connection_name: str):
        conn = context.connections_registry[connection_name]
        self.endpoint = conn.endpoint
        self.api_key = getattr(conn, "api_key", None)
        self.client = httpx.Client(timeout=60)
    
    def infer(self, input: dict[str, Any]) -> dict[str, Any]:
        headers = {}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        response = self.client.post(
            self.endpoint,
            json={"query": input["question"]},
            headers=headers,
        )
        response.raise_for_status()
        data = response.json()
        
        return {
            "answer": data.get("response", ""),
            "tool_calls": data.get("tools_used", []),
        }
    
    def close(self) -> None:
        self.client.close()
```

## Config.yaml Model Args Pattern

Model args support **grid search** - each list creates combinations:

```yaml
models:
  - name: "my_model"
    args:
      # Creates 2 × 2 = 4 model variants
      - temperature: [0.5, 0.8]
      - connection_name: ["gpt-4", "gpt-4-turbo"]
```

This runs evaluations for all combinations automatically.

## Model Output for Metrics

Your `infer()` output is used by metrics via the `mapping` config:

```yaml
metrics:
  - name: "accuracy"
    mapping:
      response: "model.answer"       # Maps to output["answer"]
      ground_truth: "dataset.label"  # Maps to dataset record["label"]
```

Ensure your model returns all fields needed by your metrics.

## Best Practices

1. **Use `@retry` decorator** - Handle rate limits and transient errors
2. **Implement `close()`** - Clean up HTTP clients to avoid resource leaks
3. **Validate config in `__init__`** - Fail fast on missing parameters
4. **Return consistent output schema** - Document what fields your model returns
5. **Use type hints** - Improves IDE support and documentation
6. **Load external resources in `__init__`** - Not in `infer()` for efficiency
'''


class ModelPatternsResource(BaseResource):
    """Resource providing model implementation patterns.

    This resource contains comprehensive examples of how to implement
    models in evee for different use cases: basic chat, agents with
    tools, async models, webhook integrations, etc.
    """

    @property
    def metadata(self) -> ResourceMetadata:
        """Return metadata for the model patterns resource."""
        return ResourceMetadata(
            uri=ResourceURIs.MODEL_PATTERNS,
            name="Model Patterns",
            description="Comprehensive guide to implementing models in evee",
            mime_type=MimeTypes.MARKDOWN,
        )

    async def read(self) -> str:
        """Read and return model patterns documentation.

        Returns:
            Markdown string containing model pattern examples.
        """
        return MODEL_PATTERNS_CONTENT
