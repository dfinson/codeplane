"""Configuration schema resource.

This module provides the complete YAML schema for evee experiment
configuration files.
"""

from evee.mcp.constants import MimeTypes, ResourceURIs
from evee.mcp.resources.base import BaseResource, ResourceMetadata

# Config schema content as a constant for easy maintenance
CONFIG_SCHEMA_CONTENT = """# Evee Configuration Schema

Complete YAML schema for `experiment/config.yaml`.

> **Related resources:**
> - `evee://docs/connections` - Connection configuration patterns
> - `evee://docs/model-patterns` - Model implementation guide
> - `evee://docs/metric-patterns` - Metric implementation guide

## Structure Overview

```yaml
experiment:
  # Metadata
  name: string                  # Required: Experiment name
  version: string               # Optional: Experiment version
  description: string           # Optional: Description
  output_path: string           # Optional: Output directory
  max_workers: int              # Optional: Parallel workers
  telemetry_enabled: bool       # Optional: Enable telemetry
  
  # Runtime configuration
  runtime:
    python_executable: string   # Optional: Python interpreter path
  
  # Tracking backend (experiment tracking)
  tracking_backend:
    type: string               # "local", "mlflow", or "azureml"
    enabled: bool              # Enable/disable tracking
    # ... backend-specific fields
  
  # Compute backend (where to run)
  compute_backend:
    type: string               # "local" or "azureml"
    # ... backend-specific fields
  
  # Model variants to evaluate
  models:
    - name: string             # Model name (matches @model decorator)
      args:                    # Grid search parameters
        - param1: [value1, value2]
        - param2: [value3]
  
  # Dataset to evaluate on
  dataset:
    name: string               # Dataset name (matches @dataset decorator)
    type: string               # "jsonl" or custom type
    version: string            # Optional: version
    args:
      data_path: string        # Path to data file
  
  # Metrics for evaluation
  metrics:
    - name: string             # Metric name (matches @metric decorator)
      param1: value            # Direct parameters to __init__
      mapping:                 # Map compute() params to data sources
        param_name: "model.field" or "dataset.field"
  
  # Connections (AI service credentials)
  connections:
    - name: string             # Connection identifier
      endpoint: string         # API endpoint
      deployment: string       # Model deployment name
      api_version: string      # API version
      api_key: string          # API key (use env vars)
      client_id: string        # Managed identity client ID
```

## Complete Example

```yaml
experiment:
  name: "Question Answering Evaluation"
  version: "1.0"
  description: "Evaluate QA models on sample dataset"
  output_path: "experiment/output"
  max_workers: "${MAX_WORKERS:-}"
  telemetry_enabled: "${EVEE_TELEMETRY_ENABLED:-true}"

  runtime:
    python_executable: "${HOME}/.venvs/evee/bin/python"

  tracking_backend:
    type: "mlflow"
    enabled: true
    autolog_flavor: "openai"
    tracking_uri: "sqlite:///mlflow.db"
  
  compute_backend:
    type: "local"

  models:
    - name: "baseline"
      args:
        - temperature: [0.7, 1.0]
        - max_tokens: [1000, 2000]
        - chat_connection_name: ["gpt-4", "gpt-4-turbo"]
    
    - name: "agent_model"
      args:
        - project_connection: ["foundry_project"]
        - chat_connection: ["gpt-4"]

  dataset:
    name: "qa_dataset"
    type: "jsonl"
    version: "1.0.0"
    args:
      data_path: "experiment/data/questions.jsonl"

  metrics:
    - name: "f1_score"
      threshold: 0.5
      mapping:
        response: "model.answer"
        ground_truth: "dataset.ground_truth"

    - name: "rouge"
      rouge_type: "ROUGE_L"
      mapping:
        response: "model.answer"
        ground_truth: "dataset.ground_truth"
    
    - name: "llm_judge"
      chat_connection_name: "gpt-4"
      temperature: 0
      mapping:
        response: "model.answer"
        ground_truth: "dataset.ground_truth"
    
    - name: "token_usage"
      mapping:
        token_usage: "model.token_usage"

  connections:
    - name: "gpt-4"
      deployment: "gpt-4"
      api_version: "2024-12-01-preview"
      endpoint: "${AZURE_OPENAI_ENDPOINT}"
      api_key: "${AZURE_OPENAI_API_KEY:-}"
      client_id: "${DEFAULT_IDENTITY_CLIENT_ID:-}"
    
    - name: "gpt-4-turbo"
      deployment: "gpt-4-turbo"
      api_version: "2024-12-01-preview"
      endpoint: "${AZURE_OPENAI_ENDPOINT}"
      client_id: "${DEFAULT_IDENTITY_CLIENT_ID:-}"

    - name: "foundry_project"
      endpoint: "${AZURE_AI_FOUNDRY_PROJECT_ENDPOINT}"
```

## Environment Variable Substitution

Evee supports POSIX-style environment variable substitution:

| Syntax | Description |
|--------|-------------|
| `${VAR}` | Required - error if VAR is not set |
| `${VAR:-default}` | Use default if VAR is unset or empty |
| `${VAR:-}` | Optional - empty string if not set |

Examples:
```yaml
connections:
  - name: "openai"
    endpoint: "${AZURE_OPENAI_ENDPOINT}"        # Required
    api_key: "${AZURE_OPENAI_API_KEY:-}"        # Optional (empty = managed identity)
    client_id: "${IDENTITY_CLIENT_ID:-}"        # Optional managed identity

experiment:
  max_workers: "${MAX_WORKERS:-4}"              # Default to 4
  output_path: "${OUTPUT_DIR:-experiment/output}"
```

## Model Args Grid Search

The `args` section creates combinations for evaluation:

```yaml
models:
  - name: "my_model"
    args:
      # Creates 2 × 2 × 2 = 8 model variants
      - temperature: [0.5, 0.9]
      - max_tokens: [500, 1000]
      - connection_name: ["gpt-4", "gpt-4-turbo"]
```

Each combination is evaluated independently, allowing comparison.

## Metric Mapping

The `mapping` section maps `compute()` parameters to data sources:

```yaml
metrics:
  - name: "accuracy"
    mapping:
      response: "model.answer"        # output["answer"] from infer()
      ground_truth: "dataset.label"   # record["label"] from dataset
      context: "dataset.context"      # record["context"] from dataset
```

Valid mapping prefixes:
- `model.X` → Value from model's `infer()` return dict
- `dataset.X` → Value from dataset record

## Field Reference

### experiment

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| name | string | Yes | Experiment name |
| version | string | No | Version string |
| description | string | No | Description |
| output_path | string | No | Output directory for results |
| max_workers | int | No | Parallel workers (default: CPU cores) |
| telemetry_enabled | bool | No | Enable telemetry collection |

### experiment.models[]

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| name | string | Yes | Model name from @model decorator |
| args | list[dict] | No | Grid search parameters |

### experiment.dataset

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| name | string | Yes | Dataset name from @dataset decorator |
| type | string | No | Dataset type ("jsonl" or custom) |
| version | string | No | Dataset version |
| args | dict | No | Arguments for dataset __init__ |

### experiment.metrics[]

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| name | string | Yes | Metric name from @metric decorator |
| mapping | dict | Yes | Maps compute() params to data sources |
| *other* | any | No | Passed to metric __init__ |

### experiment.connections[]

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| name | string | Yes | Unique connection identifier |
| endpoint | string | Yes | API endpoint URL |
| deployment | string | No | Model deployment name |
| api_version | string | No | API version |
| api_key | string | No | API key (empty = use managed identity) |
| client_id | string | No | Managed identity client ID |
| *custom* | any | No | Any custom fields you need |

### experiment.compute_backend

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| type | string | Yes | "local" or "azureml" |

For `type: azureml`:
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| subscription_id | string | Yes | Azure subscription ID |
| resource_group | string | Yes | Azure resource group |
| workspace_name | string | Yes | Azure ML workspace name |
| compute_name | string | Yes | Compute cluster name |

### experiment.tracking_backend

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| type | string | Yes | "local", "mlflow", or "azureml" |
| enabled | bool | No | Enable/disable tracking |

For `type: mlflow`:
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| tracking_uri | string | Yes | MLflow tracking server URI |
| experiment_name | string | No | Experiment name in MLflow |
| autolog_flavor | string | No | Autolog flavor ("openai", etc.) |
"""


class ConfigSchemaResource(BaseResource):
    """Resource providing experiment configuration schema documentation.

    This resource contains the complete YAML schema for evee experiment
    configuration files, including field descriptions, examples, and
    environment variable substitution syntax.

    The content is returned as Markdown for easy reading by LLMs.
    """

    @property
    def metadata(self) -> ResourceMetadata:
        """Return metadata for the config schema resource."""
        return ResourceMetadata(
            uri=ResourceURIs.CONFIG_SCHEMA,
            name="Configuration Schema",
            description="Complete YAML schema for experiment configuration",
            mime_type=MimeTypes.MARKDOWN,
        )

    async def read(self) -> str:
        """Read and return config schema documentation.

        Returns:
            Markdown string containing schema documentation.
        """
        return CONFIG_SCHEMA_CONTENT
