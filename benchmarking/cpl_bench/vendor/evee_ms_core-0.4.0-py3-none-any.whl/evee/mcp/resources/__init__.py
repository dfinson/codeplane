"""MCP Resources for Evee.

This module provides static reference resources for AI assistants,
including Azure evaluator documentation, decorator patterns, and
configuration schemas.
"""

from evee.mcp.resources.app_viewer import ResultsViewerAppResource
from evee.mcp.resources.base import (
    BaseResource,
    ResourceError,
    ResourceMetadata,
    ResourceNotFoundError,
    ResourceReadError,
    ResourceRegistry,
)
from evee.mcp.resources.config import ConfigSchemaResource
from evee.mcp.resources.connections import ConnectionsResource
from evee.mcp.resources.evaluators import AzureEvaluatorsResource
from evee.mcp.resources.metric_patterns import MetricPatternsResource
from evee.mcp.resources.model_patterns import ModelPatternsResource
from evee.mcp.resources.patterns import DecoratorPatternsResource

__all__ = [
    # Base classes
    "BaseResource",
    "ResourceMetadata",
    "ResourceRegistry",
    # Exceptions
    "ResourceError",
    "ResourceNotFoundError",
    "ResourceReadError",
    # Implementations
    "AzureEvaluatorsResource",
    "ConnectionsResource",
    "DecoratorPatternsResource",
    "ConfigSchemaResource",
    "MetricPatternsResource",
    "ModelPatternsResource",
    "ResultsViewerAppResource",
]


def create_default_registry() -> ResourceRegistry:
    """Create a ResourceRegistry with all default resources registered.

    Returns:
        ResourceRegistry with Azure evaluators, decorator patterns,
        config schema, and results viewer app resources.
    """
    registry = ResourceRegistry()
    registry.register(AzureEvaluatorsResource())
    registry.register(ConnectionsResource())
    registry.register(DecoratorPatternsResource())
    registry.register(ConfigSchemaResource())
    registry.register(MetricPatternsResource())
    registry.register(ModelPatternsResource())
    registry.register(ResultsViewerAppResource())
    return registry
