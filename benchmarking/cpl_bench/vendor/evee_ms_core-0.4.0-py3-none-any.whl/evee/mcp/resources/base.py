"""Base classes for MCP resources.

This module defines the abstract interface for MCP resources,
enabling consistent implementation and testing.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ResourceMetadata:
    """Metadata describing an MCP resource.

    Attributes:
        uri: Unique resource URI (e.g., "evee://templates/azure-evaluators")
        name: Human-readable name for the resource
        description: Brief description of what the resource provides
        mime_type: MIME type of the resource content
    """

    uri: str
    name: str
    description: str
    mime_type: str


class BaseResource(ABC):
    """Abstract base class for MCP resources.

    Resources provide static reference information that doesn't change
    during runtime, such as schemas, templates, and documentation.

    Implementations should override:
        - metadata: Return ResourceMetadata describing the resource
        - read: Return the resource content as a string

    Example:
        class MyResource(BaseResource):
            @property
            def metadata(self) -> ResourceMetadata:
                return ResourceMetadata(
                    uri="evee://my/resource",
                    name="My Resource",
                    description="Example resource",
                    mime_type="application/json"
                )

            async def read(self) -> str:
                return '{"key": "value"}'
    """

    @property
    @abstractmethod
    def metadata(self) -> ResourceMetadata:
        """Return metadata describing this resource.

        Returns:
            ResourceMetadata with uri, name, description, and mime_type.
        """
        pass

    @abstractmethod
    async def read(self) -> str:
        """Read and return the resource content.

        Returns:
            Resource content as a string. Format depends on mime_type.

        Raises:
            ResourceNotFoundError: If the underlying data source is unavailable.
            ResourceReadError: If there's an error reading the resource.
        """
        pass


class ResourceError(Exception):
    """Base exception for resource errors."""

    pass


class ResourceNotFoundError(ResourceError):
    """Raised when a requested resource cannot be found."""

    def __init__(self, uri: str, message: str | None = None):
        """Initialize the error.

        Args:
            uri: The URI that was not found.
            message: Optional custom error message.
        """
        self.uri = uri
        super().__init__(message or f"Resource not found: {uri}")


class ResourceReadError(ResourceError):
    """Raised when there's an error reading a resource."""

    def __init__(self, uri: str, cause: Exception | None = None):
        """Initialize the error.

        Args:
            uri: The URI that failed to read.
            cause: The underlying exception that caused the error.
        """
        self.uri = uri
        self.cause = cause
        message = f"Error reading resource: {uri}"
        if cause:
            message += f" ({cause})"
        super().__init__(message)


class ResourceRegistry:
    """Registry for managing MCP resources.

    Provides a centralized way to register, list, and retrieve resources.

    Example:
        registry = ResourceRegistry()
        registry.register(AzureEvaluatorsResource())
        registry.register(DecoratorPatternsResource())

        # List all resources
        for metadata in registry.list_all():
            print(metadata.uri)

        # Read a specific resource
        content = await registry.read("evee://templates/azure-evaluators")
    """

    def __init__(self):
        """Initialize an empty resource registry."""
        self._resources: dict[str, BaseResource] = {}

    def register(self, resource: BaseResource) -> None:
        """Register a resource with the registry.

        Args:
            resource: Resource instance to register.

        Raises:
            ValueError: If a resource with the same URI is already registered.
        """
        uri = resource.metadata.uri
        if uri in self._resources:
            raise ValueError(f"Resource already registered: {uri}")
        self._resources[uri] = resource

    def list_all(self) -> list[ResourceMetadata]:
        """List metadata for all registered resources.

        Returns:
            List of ResourceMetadata for all resources.
        """
        return [r.metadata for r in self._resources.values()]

    async def read(self, uri: str) -> str:
        """Read content from a resource by URI.

        Args:
            uri: Resource URI to read.

        Returns:
            Resource content as string.

        Raises:
            ResourceNotFoundError: If no resource matches the URI.
        """
        resource = self._resources.get(uri)
        if resource is None:
            raise ResourceNotFoundError(uri)
        return await resource.read()

    def get(self, uri: str) -> BaseResource | None:
        """Get a resource by URI.

        Args:
            uri: Resource URI to look up.

        Returns:
            Resource instance or None if not found.
        """
        return self._resources.get(uri)
