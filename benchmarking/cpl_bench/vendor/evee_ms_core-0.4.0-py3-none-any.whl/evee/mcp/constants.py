"""Constants for the Evee MCP Server.

This module defines shared constants, URIs, and configuration values
used throughout the MCP server implementation.
"""

from typing import Final

# =============================================================================
# Server Configuration
# =============================================================================

SERVER_NAME: Final[str] = "evee"
"""Name of the MCP server as registered with clients."""

SERVER_VERSION: Final[str] = "1.0.0"
"""Version of the MCP server implementation."""

# =============================================================================
# Resource URIs
# =============================================================================


class ResourceURIs:
    """Standard URIs for MCP resources."""

    AZURE_EVALUATORS: Final[str] = "evee://templates/azure-evaluators"
    """URI for Azure AI evaluators reference resource."""

    DECORATOR_PATTERNS: Final[str] = "evee://templates/decorator-patterns"
    """URI for decorator patterns reference resource."""

    CONFIG_SCHEMA: Final[str] = "evee://schema/config"
    """URI for configuration schema resource."""

    RESULTS_VIEWER_APP: Final[str] = "ui://evee/results-viewer.html"
    """URI for the results viewer MCP app HTML. Uses ui:// scheme for MCP Apps."""

    CONNECTIONS: Final[str] = "evee://docs/connections"
    """URI for connection configuration and usage patterns."""

    MODEL_PATTERNS: Final[str] = "evee://docs/model-patterns"
    """URI for model implementation patterns resource."""

    METRIC_PATTERNS: Final[str] = "evee://docs/metric-patterns"
    """URI for metric implementation patterns resource."""


# =============================================================================
# MIME Types
# =============================================================================


class MimeTypes:
    """MIME types for resource content."""

    TEXT: Final[str] = "text/plain"
    JSON: Final[str] = "application/json"
    MARKDOWN: Final[str] = "text/markdown"
    YAML: Final[str] = "text/yaml"
    MCP_APP_HTML: Final[str] = "text/html;profile=mcp-app"


# =============================================================================
# Default Paths
# =============================================================================


class DefaultPaths:
    """Default file paths used in evee projects."""

    CONFIG: Final[str] = "experiment/config.yaml"
    """Default path to experiment configuration file."""

    ENV_FILE: Final[str] = ".env"
    """Default path to environment variables file."""

    OUTPUT_DIR: Final[str] = "output"
    """Default output directory for experiment results."""

    AZURE_EVALUATORS_JSON: Final[str] = "cli/azure_evaluators.json"
    """Path to Azure evaluators JSON file relative to evee package."""


# =============================================================================
# Tool Names
# =============================================================================


class ToolNames:
    """Names of MCP tools."""

    RUN_EXPERIMENT: Final[str] = "run_experiment"
    """Tool for executing evaluation workflows."""

    VALIDATE_CONFIG: Final[str] = "validate_config"
    """Tool for validating experiment configuration."""

    LIST_COMPONENTS: Final[str] = "list_components"
    """Tool for discovering project components."""

    VIEW_RESULTS: Final[str] = "view_results"
    """Tool for viewing experiment results with UI."""


# =============================================================================
# Component Types
# =============================================================================


class ComponentTypes:
    """Types of components that can be discovered."""

    ALL: Final[str] = "all"
    MODELS: Final[str] = "models"
    METRICS: Final[str] = "metrics"
    DATASETS: Final[str] = "datasets"

    @classmethod
    def valid_types(cls) -> list[str]:
        """Return list of valid component types."""
        return [cls.ALL, cls.MODELS, cls.METRICS, cls.DATASETS]


# =============================================================================
# Error Types
# =============================================================================


class ErrorTypes:
    """Types of errors that can occur during tool execution."""

    VALIDATION: Final[str] = "validation"
    """Error in input validation."""

    EXECUTION: Final[str] = "execution"
    """Error during tool execution."""

    ENVIRONMENT: Final[str] = "environment"
    """Error with project environment."""

    NOT_FOUND: Final[str] = "not_found"
    """Resource or path not found."""
