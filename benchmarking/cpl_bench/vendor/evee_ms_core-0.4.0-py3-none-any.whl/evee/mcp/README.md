# Evee MCP Server

The Evee MCP (Model Context Protocol) server enables AI assistants like GitHub Copilot and other MCP-compatible clients to interact with your evaluation workflows through natural language.

## Overview

The MCP server provides three main capabilities:

1. **Tools** - Execute operations in your project environment (run experiments, validate configs, discover components)
2. **Resources** - Access static reference information (Azure evaluators list, decorator patterns, config schema)
3. **Seamless Integration** - Works with the same shared infrastructure as the evee CLI

## Installation

The MCP server is included when you install evee:

```bash
# Install from GitHub
pip install git+https://github.com/microsoft/evee.git

# Or for development
git clone https://github.com/microsoft/evee.git
cd evee
pip install -e .
```

## Configuration

### VS Code / Cursor

Add to your MCP settings (`.vscode/mcp.json` or user settings):

```json
{
  "servers": {
    "evee": {
      "command": "python",
      "args": ["-m", "evee.mcp.server"],
      "cwd": "${workspaceFolder}",
      "env": {
        "EVEE_DISABLE_RICH_LOGGING": "true"
      }
    }
  }
}
```

### Other MCP Clients

Use `python -m evee.mcp.server` to start the server via stdio transport.

## Available Tools

### 1. run_experiment

Execute a complete evaluation workflow, running your models on a dataset and computing metrics.

**Parameters:**
- `project_path` (required): Absolute path to your evee project
- `config_path` (optional): Path to config file (default: `experiment/config.yaml`)
- `env_file` (optional): Path to .env file (default: `.env`)
- `dataset_path` (optional): Override dataset path from config

**Example conversation:**
> **You:** "Run my evaluation using the test dataset"
>
> **AI:** *Uses run_experiment tool*
>
> ✅ Evaluation completed successfully! Your model achieved 95% accuracy on 100 samples. Results saved to `output/exp_20251229_143022/`.

**Returns:**
```json
{
  "status": "success",
  "execution_backend": "local",
  "experiment_id": "exp_20251229_143022",
  "summary": {
    "total_samples": 100,
    "metrics": {
      "accuracy": 0.95
    }
  },
  "output_path": "/path/to/project/output/exp_20251229_143022",
  "duration_seconds": 45.2
}
```

### 2. validate_config

Validate your experiment configuration before running (recommended before submitting to Azure ML).

**Parameters:**
- `project_path` (required): Absolute path to your evee project
- `config_path` (optional): Path to config file (default: `experiment/config.yaml`)

**Example conversation:**
> **You:** "Check if my config is correct before running"
>
> **AI:** *Uses validate_config tool*
>
> ⚠️ Your config is valid but has 1 warning: the dataset path 'data/test.csv' doesn't exist.

**Returns:**
```json
{
  "valid": true,
  "errors": [],
  "warnings": [
    "Dataset path 'data/test.csv' not found"
  ],
  "validation_details": {
    "schema_valid": true,
    "environment_ready": true
  }
}
```

### 3. list_components

Discover models, metrics, and datasets in your project via decorator scanning.

**Parameters:**
- `project_path` (required): Absolute path to your evee project
- `component_type` (optional): Filter by type (`all`, `models`, `metrics`, `datasets`)

**Example conversation:**
> **You:** "What metrics are available in this project?"
>
> **AI:** *Uses list_components with component_type="metrics"*
>
> Found 3 metrics: `accuracy_metric`, `f1_metric`, and `latency_metric`.

**Returns:**
```json
{
  "models": [
    {
      "name": "gpt4_model",
      "file": "models/gpt4.py",
      "description": "OpenAI GPT-4 wrapper"
    }
  ],
  "metrics": [
    {
      "name": "accuracy_metric",
      "file": "metrics/accuracy.py"
    }
  ],
  "datasets": [],
  "discovery_warnings": []
}
```

## Available Resources

Resources provide static reference information that helps AI assistants understand evee without needing to execute code.

### 1. evee://templates/azure-evaluators

JSON list of all available Azure AI evaluators from the `azure-ai-evaluation` package.

**Usage:** When you ask "What Azure evaluators are available?" or "Add a Foundry metric"

**Example:**
```json
[
  {
    "name": "CoherenceEvaluator",
    "description": "Evaluates coherence of generated text",
    "parameters": ["query", "response"]
  },
  {
    "name": "F1ScoreEvaluator",
    "description": "Calculates F1 score",
    "parameters": ["response", "ground_truth"]
  }
]
```

### 2. evee://templates/decorator-patterns

Markdown reference showing correct usage of `@model`, `@metric`, and `@dataset` decorators.

**Usage:** When you ask "How do I implement a custom metric?" or "Create a new model"

**Includes:**
- Model decorator with sync/async `infer()` methods
- Metric decorator with `compute()` and `aggregate()` methods
- Dataset decorator with `__iter__()` implementation
- Connection registry patterns

### 3. evee://schema/config

Complete YAML schema for `experiment/config.yaml` with examples.

**Usage:** When you ask "What fields are required in config?" or "How do I configure Azure ML?"

**Includes:**
- All configuration fields with types and defaults
- Environment variable substitution syntax
- Complete example configurations
- Different backend configurations (local, Azure ML, MLflow)

## How It Works

The MCP server uses the same shared execution infrastructure as the evee CLI:

1. **Environment Resolution** - Auto-detects your project's Python environment (`.venv`, `venv`, conda, etc.)
2. **Subprocess Execution** - Runs evee commands in your project's isolated environment
3. **Consistent Behavior** - Same logic powers both CLI and MCP server

```
VS Code / Copilot
      ↓
  MCP Server (global)
      ↓
  Environment Resolver → Detect .venv
      ↓
  Execution Runner → subprocess
      ↓
  Project Environment (.venv)
      ↓
  Your Models/Metrics/Datasets
```

## Development

### Running Tests

```bash
# Run MCP server tests
make test-core

# Or with pytest directly
source ~/.venvs/evee-core/bin/activate
pytest tests/test_mcp_server.py -v

# Run integration tests
pytest tests/test_mcp_server.py -m integration -v
```

### Manual Testing

You can test the MCP server using the MCP Inspector:

```bash
# Install MCP Inspector
npm install -g @modelcontextprotocol/inspector

# Run inspector with evee MCP server
npx @modelcontextprotocol/inspector python -m evee.mcp.server
```

Or test individual tools:

```bash
# Start server and send JSON-RPC requests via stdio
python -m evee.mcp.server
```

## Security Considerations

The MCP server follows these security principles:

1. **Environment Isolation** - Each project runs in its own isolated Python environment
2. **Path Validation** - Rejects paths with `..` or symlinks outside project root
3. **No Automatic Execution** - Only executes code via explicit tool invocations
4. **Credential Safety** - Environment variables stay in project subprocess, never logged
5. **Read-Only by Default** - Most operations are read-only (config validation, component discovery)

## Troubleshooting

### MCP Server Not Starting

1. Verify evee is installed:
   ```bash
   python -c "from evee.mcp.server import mcp; print('MCP server ready')"
   ```

2. Check Python version (requires >=3.12, <3.14):
   ```bash
   python --version
   ```

3. Check MCP dependency:
   ```bash
   python -c "import mcp; print(mcp.__version__)"
   ```

### Tools Failing with Environment Errors

The MCP server needs evee installed in your project's environment:

```bash
cd /path/to/your/project
source .venv/bin/activate  # Or activate your environment
pip install git+https://github.com/microsoft/evee.git
```

### AI Assistant Can't Find Tools

1. Restart your AI client after updating configuration
2. Verify JSON syntax is valid
3. Ensure evee is installed in your Python environment

## Architecture

For detailed architecture and design decisions, see [docs/design/mcp-server.md](../../docs/design/mcp-server.md).

Key design principles:
- **Shared Infrastructure** - Reuses CLI execution logic
- **Generic Execution** - Runner doesn't know about specific commands
- **stdio Transport** - Simple, local-only communication
- **Stateless** - Each tool call is independent

## Next Steps

- **Phase 3** - Enhanced scaffolding tools (`add_foundry_metric`, `add_custom_metric`, `add_sample_dataset`)
- **Progress Notifications** - Real-time progress for long-running Azure ML jobs
- **Additional Backends** - Support for more compute/tracking backends

## Contributing

See [CONTRIBUTING.md](../../CONTRIBUTING.md) for development guidelines.

When adding new CLI commands, they automatically become available through the MCP server - no runner changes needed!
