"""Evee MCP (Model Context Protocol) Server.

Enables AI assistants to interact with evaluation workflows.
"""

from evee.mcp.server import main, mcp, run_server

__all__ = [
    # FastMCP server instance
    "mcp",
    # Entry points
    "main",
    "run_server",
]
