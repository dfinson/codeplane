"""View experiment results tool.

This module implements the view_results MCP tool for displaying
evaluation results with an interactive UI.
"""

import json
import os
from pathlib import Path
from typing import Any

from evee.logging.logger import setup_logger
from evee.mcp.constants import ErrorTypes
from evee.mcp.tools.base import BaseTool, ToolResult

logger = setup_logger(__name__)


class ViewResultsTool(BaseTool):
    """MCP tool for viewing experiment results with an interactive UI.

    This tool loads experiment results from a specific experiment output
    directory and returns them in a format suitable for the results viewer UI.

    Important: Point to a specific experiment output folder, not a parent
    directory containing multiple experiments.

    Args (via execute):
        output_path: Path to a specific experiment output directory or results JSON file.

    Returns:
        On success: Summary metrics, individual records, and output path.
        On error: Error details with type and suggestions.

    Example:
        tool = ViewResultsTool()
        result = await tool.execute({
            "output_path": "/path/to/experiment/output/my_exp_v1.0__2026-01-29"
        })
    """

    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        """Load and return experiment results.

        Args:
            arguments: Tool arguments with output_path.

        Returns:
            ToolResult with experiment summary and records for all models.
        """
        output_path = arguments["output_path"]

        # Validate path exists
        if not os.path.exists(output_path):
            return ToolResult(
                success=False,
                error={
                    "type": ErrorTypes.NOT_FOUND,
                    "message": f"Output path does not exist: {output_path}",
                },
            )

        logger.info(f"Loading results from: {output_path}")

        try:
            # Find all model results files
            all_results = self._find_all_results_files(output_path)

            if not all_results:
                return ToolResult(
                    success=False,
                    error={
                        "type": ErrorTypes.NOT_FOUND,
                        "message": f"No results JSON file found in: {output_path}",
                        "suggestion": "Point to a specific experiment output folder (e.g., experiment/output/my_experiment_v1.0__2026-01-29_12-00-00), not a parent directory",
                    },
                )

            # Load all models' results
            models = []
            for results_json, records_jsonl in all_results:
                summary = self._load_summary(results_json)
                records = []
                if records_jsonl and os.path.exists(records_jsonl):
                    records = self._load_records(records_jsonl)

                model_display_name = results_json.stem.replace("_results", "")
                model_name = summary.get("run_id", model_display_name)
                models.append(
                    {
                        "model_name": model_name,
                        "model_display_name": model_display_name,
                        "summary": summary,
                        "records": records,
                        "files": {
                            "summary": str(results_json),
                            "records": str(records_jsonl) if records_jsonl else None,
                        },
                    }
                )

            # For backward compatibility, also include first model as top-level fields
            first_model = models[0]
            return ToolResult(
                success=True,
                data={
                    "summary": first_model["summary"],
                    "records": first_model["records"],
                    "output_path": output_path,
                    "files": first_model["files"],
                    "models": models,  # New: all models
                },
            )

        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error: {e}")
            return ToolResult(
                success=False,
                error={
                    "type": ErrorTypes.VALIDATION,
                    "message": f"Invalid JSON in results file: {e}",
                },
            )
        except Exception as e:
            logger.error(f"Failed to load results: {e}", exc_info=True)
            return ToolResult(
                success=False,
                error={
                    "type": ErrorTypes.EXECUTION,
                    "message": str(e),
                },
            )

    def _find_all_results_files(self, path: str) -> list[tuple[Path, Path | None]]:
        """Find all results JSON and JSONL files from a path.

        Only looks directly in the specified directory - does not search
        subdirectories. This ensures users point to a specific experiment
        output folder, not a parent directory containing multiple experiments.

        Args:
            path: Path to results file or directory.

        Returns:
            List of tuples (results_json_path, records_jsonl_path) for each model.
        """
        path_obj = Path(path)
        results = []

        # If path is already a results JSON file, return just that one
        if path_obj.is_file() and path_obj.name.endswith("_results.json"):
            jsonl_name = path_obj.name.replace("_results.json", ".jsonl")
            jsonl_path = path_obj.parent / jsonl_name
            return [(path_obj, jsonl_path if jsonl_path.exists() else None)]

        # If path is a directory, search for results files ONLY in that directory
        if path_obj.is_dir():
            # Check for artifacts subdirectory (MLflow structure)
            artifacts_dir = path_obj / "artifacts"
            search_dir = artifacts_dir if artifacts_dir.is_dir() else path_obj

            # Find all results JSON files directly in the directory (no recursive search)
            results_files = list(search_dir.glob("*_results.json"))

            # Sort by name for consistent ordering
            results_files.sort(key=lambda p: p.name)

            for results_json in results_files:
                # Look for matching JSONL
                jsonl_name = results_json.name.replace("_results.json", ".jsonl")
                jsonl_path = results_json.parent / jsonl_name
                results.append((results_json, jsonl_path if jsonl_path.exists() else None))

        # If path is a specific JSON file (not _results.json naming)
        if path_obj.is_file() and path_obj.suffix == ".json" and not results:
            return [(path_obj, None)]

        return results

    def _load_summary(self, results_path: Path) -> dict[str, Any]:
        """Load results summary from JSON file.

        Args:
            results_path: Path to results JSON file.

        Returns:
            Dictionary with experiment summary.
        """
        with open(results_path, encoding="utf-8") as f:
            return json.load(f)

    def _load_records(self, records_path: Path) -> list[dict[str, Any]]:
        """Load individual records from JSONL file.

        Args:
            records_path: Path to records JSONL file.

        Returns:
            List of record dictionaries.
        """
        records = []
        with open(records_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    records.append(json.loads(line))
        return records
