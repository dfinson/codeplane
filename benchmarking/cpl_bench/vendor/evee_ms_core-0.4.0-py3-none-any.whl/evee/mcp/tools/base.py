"""Base classes for MCP tools.

This module defines the abstract interface for MCP tools,
enabling consistent implementation and testing.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolSchema:
    """JSON Schema for tool input validation.

    Attributes:
        properties: Dictionary of property definitions.
        required: List of required property names.
        additional_properties: Whether additional properties are allowed.
    """

    properties: dict[str, dict[str, Any]]
    required: list[str] = field(default_factory=list)
    additional_properties: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to JSON Schema dictionary.

        Returns:
            Dictionary representation of the schema.
        """
        return {
            "type": "object",
            "properties": self.properties,
            "required": self.required,
            "additionalProperties": self.additional_properties,
        }


@dataclass
class ToolMetadata:
    """Metadata describing an MCP tool.

    Attributes:
        name: Unique tool name (e.g., "run_experiment").
        description: Human-readable description of what the tool does.
        input_schema: JSON Schema for tool input validation.
        ui_metadata: Optional UI metadata for MCP Apps (resourceUri, visibility, etc.).
    """

    name: str
    description: str
    input_schema: ToolSchema
    ui_metadata: dict[str, Any] | None = None


@dataclass
class ToolResult:
    """Result from tool execution.

    Attributes:
        success: Whether the tool executed successfully.
        data: Result data (varies by tool).
        error: Error information if success is False.
    """

    success: bool
    data: dict[str, Any] = field(default_factory=dict)
    error: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization.

        Returns:
            Dictionary representation of the result.
        """
        if self.success:
            return self.data
        else:
            return {
                "status": "error",
                "error_type": self.error.get("type", "unknown") if self.error else "unknown",
                "message": self.error.get("message", "Unknown error") if self.error else "Unknown error",
                **({k: v for k, v in (self.error or {}).items() if k not in ("type", "message")}),
            }


class BaseTool(ABC):
    """Abstract base class for MCP tools.

    Tools provide execution capabilities that the LLM cannot achieve
    through direct file access, such as running code in isolated
    environments or validating configurations.

    Subclasses must implement:
        - execute: Perform the tool's operation and return a ToolResult.

    Note: With FastMCP, tool metadata (name, description, parameters) is
    extracted from the @mcp.tool() decorated function signature and docstring.
    The metadata property is only used by ToolRegistry for testing.

    Example:
        class MyTool(BaseTool):
            def __init__(self, runner: ExecutionRunner):
                self._runner = runner

            async def execute(self, arguments: dict[str, Any]) -> ToolResult:
                # Implementation
                return ToolResult(success=True, data={"result": "..."})
    """

    @property
    def metadata(self) -> ToolMetadata:
        """Return metadata describing this tool.

        Default implementation derives name from class name.
        Override in subclasses or MockTool for custom metadata.

        Returns:
            ToolMetadata with name derived from class name.
        """
        # Convert CamelCase to snake_case (e.g., ValidateConfigTool -> validate_config_tool)
        import re

        name = re.sub(r"(?<!^)(?=[A-Z])", "_", self.__class__.__name__).lower()
        # Remove _tool suffix if present
        if name.endswith("_tool"):
            name = name[:-5]
        return ToolMetadata(
            name=name,
            description=f"{self.__class__.__name__} tool",
            input_schema=ToolSchema(properties={}, required=[]),
        )

    @abstractmethod
    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        """Execute the tool with given arguments.

        Args:
            arguments: Tool arguments matching the input_schema.

        Returns:
            ToolResult containing success status and data or error.
        """
        pass

    def _validate_path_exists(self, path: str, path_type: str = "path") -> ToolResult | None:
        """Validate that a path exists.

        Args:
            path: Path to validate.
            path_type: Type description for error message.

        Returns:
            ToolResult with error if path doesn't exist, None if valid.
        """
        import os

        if not os.path.exists(path):
            return ToolResult(
                success=False,
                error={
                    "type": "validation",
                    "message": f"{path_type.capitalize()} does not exist: {path}",
                },
            )
        return None


class ToolError(Exception):
    """Base exception for tool errors."""

    pass


class ToolExecutionError(ToolError):
    """Raised when tool execution fails."""

    def __init__(self, tool_name: str, message: str, cause: Exception | None = None):
        """Initialize the error.

        Args:
            tool_name: Name of the tool that failed.
            message: Error message.
            cause: The underlying exception that caused the error.
        """
        self.tool_name = tool_name
        self.cause = cause
        super().__init__(f"Tool '{tool_name}' failed: {message}")


class ToolRegistry:
    """Registry for managing MCP tools.

    Provides a centralized way to register, list, and execute tools.

    Example:
        registry = ToolRegistry()
        registry.register(RunExperimentTool(runner))
        registry.register(ValidateConfigTool(runner))

        # List all tools
        for metadata in registry.list_all():
            print(metadata.name)

        # Execute a tool
        result = await registry.execute("run_experiment", {"project_path": "/path"})
    """

    def __init__(self):
        """Initialize an empty tool registry."""
        self._tools: dict[str, BaseTool] = {}

    def register(self, tool: BaseTool) -> None:
        """Register a tool with the registry.

        Args:
            tool: Tool instance to register.

        Raises:
            ValueError: If a tool with the same name is already registered.
        """
        name = tool.metadata.name
        if name in self._tools:
            raise ValueError(f"Tool already registered: {name}")
        self._tools[name] = tool

    def list_all(self) -> list[ToolMetadata]:
        """List metadata for all registered tools.

        Returns:
            List of ToolMetadata for all tools.
        """
        return [t.metadata for t in self._tools.values()]

    async def execute(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        """Execute a tool by name.

        Args:
            name: Tool name to execute.
            arguments: Arguments to pass to the tool.

        Returns:
            ToolResult from tool execution.
        """
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(
                success=False,
                error={
                    "type": "not_found",
                    "message": f"Unknown tool: {name}",
                },
            )

        try:
            return await tool.execute(arguments)
        except Exception as e:
            return ToolResult(
                success=False,
                error={
                    "type": "execution",
                    "message": str(e),
                },
            )

    def get(self, name: str) -> BaseTool | None:
        """Get a tool by name.

        Args:
            name: Tool name to look up.

        Returns:
            Tool instance or None if not found.
        """
        return self._tools.get(name)
