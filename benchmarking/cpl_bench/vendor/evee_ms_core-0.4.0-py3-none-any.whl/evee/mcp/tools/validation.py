"""Validate config tool.

This module implements the validate_config MCP tool for validating
experiment configurations before execution.
"""

import os
from typing import Any

from evee.execution.runner import ExecutionRunner
from evee.logging.logger import setup_logger
from evee.mcp.constants import DefaultPaths
from evee.mcp.tools.base import BaseTool, ToolResult

logger = setup_logger(__name__)


class ValidateConfigTool(BaseTool):
    """MCP tool for validating experiment configuration.

    This tool performs pre-flight checks on experiment configuration
    to catch errors before execution. Always recommended before running
    experiments to avoid wasted time and compute costs.

    Validation includes:
        - YAML syntax validation
        - Schema validation (required fields, types)
        - File existence checks (dataset, model files)
        - Model/metric instantiation to catch mapping errors
        - Registry validation for models and metrics

    Args (via execute):
        project_path: Absolute path to the evee project directory.
        config_path: Path to config file relative to project (default: experiment/config.yaml).

    Returns:
        Validation result with valid flag, errors, and warnings.

    Example:
        tool = ValidateConfigTool(runner)
        result = await tool.execute({
            "project_path": "/path/to/project"
        })
    """

    def __init__(self, runner: ExecutionRunner):
        """Initialize the tool with an execution runner.

        Args:
            runner: ExecutionRunner instance for subprocess execution.
        """
        self._runner = runner

    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        """Validate experiment configuration.

        Args:
            arguments: Tool arguments with project_path, optional config_path and env_file.

        Returns:
            ToolResult with validation result (valid, errors, warnings).
        """
        # Extract arguments with defaults - use `or` to handle explicit None values
        project_path = arguments["project_path"]
        config_path = arguments.get("config_path") or DefaultPaths.CONFIG
        env_file = arguments.get("env_file") or DefaultPaths.ENV_FILE

        # Validate project path exists
        if not os.path.isdir(project_path):
            return ToolResult(
                success=True,  # Tool executed, validation found errors
                data={
                    "valid": False,
                    "errors": [f"Project path does not exist: {project_path}"],
                    "warnings": [],
                },
            )

        # Validate config file exists
        full_config_path = os.path.join(project_path, config_path)
        if not os.path.isfile(full_config_path):
            return ToolResult(
                success=True,
                data={
                    "valid": False,
                    "errors": [f"Config file does not exist: {config_path}"],
                    "warnings": [],
                },
            )

        logger.info(f"Validating config: {config_path} in {project_path}")

        try:
            # Run validation via shared execution runner
            result = self._runner.validate_config(
                project_path=project_path,
                config_path=config_path,
                env_path=env_file,
            )

            return ToolResult(success=True, data=result)

        except Exception as e:
            logger.error(f"Config validation failed: {e}", exc_info=True)
            return ToolResult(
                success=True,  # Tool executed, but validation itself failed
                data={
                    "valid": False,
                    "errors": [str(e)],
                    "warnings": [],
                    "suggestion": "Check YAML syntax and ensure evee is installed in project environment",
                },
            )
