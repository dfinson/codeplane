"""List components tool.

This module implements the list_components MCP tool for discovering
models, metrics, and datasets via decorator scanning.
"""

import os
from typing import Any

from evee.execution.runner import ExecutionRunner
from evee.logging.logger import setup_logger
from evee.mcp.constants import ComponentTypes, ErrorTypes
from evee.mcp.tools.base import BaseTool, ToolResult

logger = setup_logger(__name__)


class ListComponentsTool(BaseTool):
    """MCP tool for discovering project components.

    This tool discovers available models, metrics, and datasets
    by importing Python modules in the project environment.
    The decorator system (@model, @metric, @dataset) registers
    components during import.

    Args (via execute):
        project_path: Absolute path to the evee project directory.
        component_type: Type of components to discover (all, models, metrics, datasets).

    Returns:
        Component lists with names, files, and descriptions.

    Example:
        tool = ListComponentsTool(runner)
        result = await tool.execute({
            "project_path": "/path/to/project",
            "component_type": "metrics"
        })
    """

    def __init__(self, runner: ExecutionRunner):
        """Initialize the tool with an execution runner.

        Args:
            runner: ExecutionRunner instance for subprocess execution.
        """
        self._runner = runner

    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        """Discover project components via decorator scanning.

        Args:
            arguments: Tool arguments with project_path and optional component_type.

        Returns:
            ToolResult with discovered components lists.
        """
        # Extract arguments with defaults
        project_path = arguments["project_path"]
        component_type = arguments.get("component_type", ComponentTypes.ALL)

        # Validate component type
        if component_type not in ComponentTypes.valid_types():
            return ToolResult(
                success=False,
                error={
                    "type": ErrorTypes.VALIDATION,
                    "message": f"Invalid component_type: {component_type}. Must be one of: {ComponentTypes.valid_types()}",
                },
            )

        # Validate project path exists
        if not os.path.isdir(project_path):
            return ToolResult(
                success=True,  # Tool executed, but discovery returned empty
                data={
                    "models": [],
                    "metrics": [],
                    "datasets": [],
                    "discovery_warnings": [f"Project path does not exist: {project_path}"],
                },
            )

        logger.info(f"Discovering {component_type} components in: {project_path}")

        try:
            # Run component discovery via shared execution runner
            result = self._runner.discover_components(
                project_path=project_path,
                component_type=component_type,
            )

            return ToolResult(success=True, data=result)

        except Exception as e:
            logger.error(f"Component discovery failed: {e}", exc_info=True)
            return ToolResult(
                success=True,  # Tool executed, but discovery failed
                data={
                    "models": [],
                    "metrics": [],
                    "datasets": [],
                    "discovery_warnings": [
                        str(e),
                        "Check that evee is installed in the project environment",
                    ],
                },
            )
