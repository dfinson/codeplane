"""MCP Tools for Evee.

This module provides execution tools for AI assistants,
enabling them to run experiments, validate configurations,
and discover project components.
"""

from evee.mcp.tools.base import (
    BaseTool,
    ToolError,
    ToolExecutionError,
    ToolMetadata,
    ToolRegistry,
    ToolResult,
    ToolSchema,
)
from evee.mcp.tools.discovery import ListComponentsTool
from evee.mcp.tools.experiment import RunExperimentTool
from evee.mcp.tools.validation import ValidateConfigTool
from evee.mcp.tools.view_results import ViewResultsTool

__all__ = [
    # Base classes
    "BaseTool",
    "ToolMetadata",
    "ToolResult",
    "ToolSchema",
    "ToolRegistry",
    # Exceptions
    "ToolError",
    "ToolExecutionError",
    # Implementations
    "RunExperimentTool",
    "ValidateConfigTool",
    "ListComponentsTool",
    "ViewResultsTool",
]


def create_default_registry(runner: "ExecutionRunner") -> ToolRegistry:  # noqa: F821
    """Create a ToolRegistry with all default tools registered.

    Args:
        runner: ExecutionRunner instance for tool execution.

    Returns:
        ToolRegistry with run_experiment, validate_config,
        list_components, and view_results tools.
    """
    registry = ToolRegistry()
    registry.register(RunExperimentTool(runner))
    registry.register(ValidateConfigTool(runner))
    registry.register(ListComponentsTool(runner))
    registry.register(ViewResultsTool())
    return registry
