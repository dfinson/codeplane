"""Run experiment tool.

This module implements the run_experiment MCP tool for executing
evaluation workflows in project environments.
"""

import os
from typing import Any

import evee
from evee.execution.runner import ExecutionRunner
from evee.logging.logger import setup_logger
from evee.mcp.constants import DefaultPaths, ErrorTypes
from evee.mcp.tools.base import BaseTool, ToolResult

logger = setup_logger(__name__)


class RunExperimentTool(BaseTool):
    """MCP tool for executing evaluation workflows.

    This tool runs a complete evaluation workflow, executing models
    on a dataset and computing metrics. It delegates to the shared
    ExecutionRunner to run in the project's Python environment.

    Args (via execute):
        project_path: Absolute path to the evee project directory.
        config_path: Path to config file relative to project (default: experiment/config.yaml).
        env_file: Path to .env file relative to project (default: .env).
        dataset_path: Optional path to dataset file (overrides config).

    Returns:
        On success: Evaluation results with metrics and output path.
        On error: Error details with type and suggestions.

    Example:
        tool = RunExperimentTool(runner)
        result = await tool.execute({
            "project_path": "/path/to/project",
            "config_path": "experiment/config.yaml"
        })
    """

    def __init__(self, runner: ExecutionRunner):
        """Initialize the tool with an execution runner.

        Args:
            runner: ExecutionRunner instance for subprocess execution.
        """
        self._runner = runner

    async def execute(self, arguments: dict[str, Any]) -> ToolResult:
        """Execute an evaluation workflow.

        Args:
            arguments: Tool arguments with project_path and optional config paths.

        Returns:
            ToolResult with evaluation results or error details.
            Always includes version info:
                - evee_mcp_version: version of evee running the MCP server
                - evee_project_version: version of evee in the project's venv
        """
        # Extract arguments with defaults - use `or` to handle explicit None values
        project_path = arguments["project_path"]
        config_path = arguments.get("config_path") or DefaultPaths.CONFIG
        env_file = arguments.get("env_file") or DefaultPaths.ENV_FILE
        dataset_path = arguments.get("dataset_path")

        # Version of evee powering the MCP server process
        mcp_version = evee.__version__

        # Validate project path exists
        if not os.path.isdir(project_path):
            return ToolResult(
                success=False,
                error={
                    "type": ErrorTypes.VALIDATION,
                    "message": f"Project path does not exist: {project_path}",
                    "evee_mcp_version": mcp_version,
                },
            )

        logger.info(f"Running experiment in: {project_path}")
        logger.debug(f"Config: {config_path}, Env: {env_file}, Dataset: {dataset_path}")

        try:
            # Run evaluation via shared execution runner
            result = self._runner.run_evaluation(
                project_path=project_path,
                config_path=config_path,
                env_path=env_file,
                dataset_path=dataset_path,
                stream_output=False,  # MCP mode: blocking execution
                env_vars={"EVEE_MCP_MODE": "true"},
            )

            # Extract the project venv version (set by run_evaluation)
            project_version = result.pop("evee_version", "unknown")

            # Check if execution returned an error
            if result.get("status") == "error":
                return ToolResult(
                    success=False,
                    error={
                        "type": result.get("error_type", ErrorTypes.EXECUTION),
                        "message": result.get("message", "Evaluation failed"),
                        "evee_mcp_version": mcp_version,
                        "evee_project_version": project_version,
                    },
                )

            # Inject version info into success response
            result["evee_mcp_version"] = mcp_version
            result["evee_project_version"] = project_version

            # Report partial failures accurately
            if result.get("status") == "completed_with_errors":
                failed = result.get("failed_records", 0)
                total = result.get("total_records", 0)
                result["message"] = f"{failed} of {total} records failed during evaluation"

            return ToolResult(success=True, data=result)

        except Exception as e:
            logger.error(f"Experiment execution failed: {e}", exc_info=True)
            return ToolResult(
                success=False,
                error={
                    "type": ErrorTypes.EXECUTION,
                    "message": str(e),
                    "suggestion": "Check that evee is installed in the project environment and config is valid",
                    "evee_mcp_version": mcp_version,
                },
            )
