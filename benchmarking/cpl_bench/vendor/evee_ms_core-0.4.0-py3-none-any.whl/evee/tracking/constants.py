"""Constants and enums for tracking backends.

Use these instead of magic strings for type safety.
"""

from enum import StrEnum


class OperationStatus(StrEnum):
    """Status values for operations (runs, inferences, etc.)."""

    SUCCESS = "success"
    FAILED = "failed"
