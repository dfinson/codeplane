"""TrackingBackend protocol defining the backend interface.

Backends implement lifecycle hooks for experiment tracking.
Only start_run() is required; all other methods are optional.
"""

from pydantic import BaseModel

from .events import (
    ArtifactGeneratedEvent,
    ExperimentCompletedEvent,
    ExperimentStartEvent,
    InferenceCompletedEvent,
    InferenceStartEvent,
    ModelRunCompletedEvent,
    ModelRunStartEvent,
    ResultsAnalyzedEvent,
)


class TrackingBackend[ConfigT: BaseModel]:
    """Base class for tracking backends.

    Methods are ordered chronologically by their typical execution order.

    Type parameter ConfigT specifies the backend's configuration type.
    The factory will automatically instantiate the correct config type
    and pass it to __init__.

    Example:
        class MyBackend(TrackingBackend[MyBackendConfig]):
            def __init__(self, config: MyBackendConfig):
                self.my_field = config.my_field  # Typed access, no extraction needed
    """

    def __init__(self, config: ConfigT) -> None:
        """Initialize the tracking backend.

        Args:
            config: Backend-specific configuration. The factory automatically
                    instantiates the correct type based on the Generic parameter.
        """
        pass

    def on_startup(self) -> None:
        """Handle backend startup (optional)."""
        pass

    def on_experiment_started(self, event: ExperimentStartEvent) -> None:
        """Handle experiment start event."""
        pass

    def on_experiment_completed(self, event: ExperimentCompletedEvent) -> None:
        """Handle experiment completion event."""
        pass

    def start_run(self, event: ModelRunStartEvent) -> str | None:
        """Start a new model evaluation run (required).

        Args:
            event: Model run start event data

        Returns:
            Backend-specific run ID (e.g., MLflow UUID) or None if not applicable
        """
        raise NotImplementedError("Subclasses must implement start_run()")

    def on_artifact_generated(self, event: ArtifactGeneratedEvent) -> None:
        """Handle artifact generation.

        Called once per artifact generated during a model run. A single run may
        produce multiple artifacts (e.g., results.jsonl, aggregated_results.json).
        Implementations should be stateless and handle each artifact independently.
        If aggregation across artifacts is needed, perform it in on_run_completed.
        """
        pass

    def on_results_analyzed(self, event: ResultsAnalyzedEvent) -> None:
        """Handle results analysis (optional)."""
        pass

    def on_run_completed(self, event: ModelRunCompletedEvent) -> None:
        """Handle model run completion (optional)."""
        pass

    def on_inference_started(self, event: InferenceStartEvent) -> None:
        """Handle inference start (optional)."""
        pass

    def on_inference_completed(self, event: InferenceCompletedEvent) -> None:
        """Handle inference completion (optional)."""
        pass

    def on_shutdown(self) -> None:
        """Handle backend shutdown (optional)."""
        pass
