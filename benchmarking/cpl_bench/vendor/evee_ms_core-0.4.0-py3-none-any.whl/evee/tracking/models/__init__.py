"""Configuration models for tracking backends.

These models will move with their respective backends in Phase 4.
"""

__all__ = []  # Models are imported by backends, not exposed publicly
