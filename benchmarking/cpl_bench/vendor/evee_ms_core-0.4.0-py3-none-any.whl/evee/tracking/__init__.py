"""Tracking backend infrastructure.

This module provides a pluggable tracking backend system with support for
MLflow and Azure ML. Backends are discovered via entry points.
"""

from .backend import TrackingBackend
from .constants import OperationStatus
from .events import (
    ArtifactGeneratedEvent,
    ExperimentCompletedEvent,
    ExperimentStartEvent,
    InferenceCompletedEvent,
    InferenceStartEvent,
    ModelRunCompletedEvent,
    ModelRunStartEvent,
    ResultsAnalyzedEvent,
)
from .factory import create_tracking_backend

__all__ = [
    # Core protocol
    "TrackingBackend",
    # Factory
    "create_tracking_backend",
    # Events
    "ExperimentStartEvent",
    "ExperimentCompletedEvent",
    "ModelRunStartEvent",
    "ModelRunCompletedEvent",
    "InferenceStartEvent",
    "InferenceCompletedEvent",
    "ResultsAnalyzedEvent",
    "ArtifactGeneratedEvent",
    # Constants
    "OperationStatus",
]
