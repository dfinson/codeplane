"""Factory function for creating tracking backends.

Backends are discovered via Python entry points, allowing external packages
to register new backend types without modifying core code.
"""

from importlib.metadata import entry_points
from typing import get_args, get_origin

from pydantic import BaseModel, ValidationError

from ..config import Config, TrackingBackendConfig
from ..logging.logger import setup_logger
from .backend import TrackingBackend
from .backends.no_op_fallback_backend import NoOpFallbackBackend

logger = setup_logger(__name__)


def create_tracking_backend(config: Config | None, tracking_enabled: bool = True) -> TrackingBackend:
    """Create tracking backend from config using entry point discovery.

    Args:
        config: Full configuration object (entire config, not just tracking section)
        tracking_enabled: If False, forces use of NoOpFallbackBackend regardless of config

    Returns:
        TrackingBackend instance (returns NoOpFallbackBackend if no config found or disabled)
    """
    if config is None or not tracking_enabled:
        return NoOpFallbackBackend(config=None)

    # Look for tracking_backend in experiment section (new format) or at root (old format)
    tracking_config = None

    if hasattr(config, "experiment") and hasattr(config.experiment, "tracking_backend"):
        tracking_config = config.experiment.tracking_backend

    if not tracking_config and hasattr(config, "tracking_backend"):
        tracking_config = config.tracking_backend

    if not tracking_config:
        return NoOpFallbackBackend(config=None)

    # Check for explicit disable in config
    if hasattr(tracking_config, "enabled") and tracking_config.enabled is False:
        return NoOpFallbackBackend(config=None)

    # Inject experiment name from root config as single source of truth
    if hasattr(config, "experiment") and hasattr(config.experiment, "name"):
        experiment_name = config.experiment.name
        if experiment_name:
            tracking_config.experiment_name = experiment_name

    return _load_backend_from_config(tracking_config)


def _load_backend_from_config(tracking_config: TrackingBackendConfig) -> TrackingBackend:
    """Load backend via entry points.

    Args:
        tracking_config: Tracking backend configuration section.

    Returns:
        TrackingBackend instance (returns NoOpFallbackBackend if type not specified)

    Raises:
        ValueError: If backend type unknown or not found
    """
    if not hasattr(tracking_config, "type"):
        return NoOpFallbackBackend(config=None)

    backend_type = tracking_config.type

    if not backend_type:
        return NoOpFallbackBackend(config=None)

    eps = entry_points(group="evee.tracking_backends")
    for ep in eps:
        if ep.name == backend_type:
            backend_class = ep.load()

            # Resolve the config type from Generic[ConfigT] if specified
            try:
                typed_config = _resolve_typed_config(backend_class, tracking_config)
                return backend_class(config=typed_config)
            except ValidationError as e:
                errors = "; ".join(f"{err['loc']}: {err['msg']}" for err in e.errors())
                raise ValueError(f"Invalid configuration for '{backend_type}' tracking backend: {errors}") from e

    available_backends = [ep.name for ep in eps]

    msg = f"Unknown tracking backend type: '{backend_type}'. Available backends: {available_backends}"

    if backend_type == "azureml" and "azureml" not in available_backends:
        msg += "\nRequirement: Install the 'evee-ms-azureml' package to use the Azure ML backend."
    elif backend_type == "mlflow" and "mlflow" not in available_backends:
        msg += "\nRequirement: Install the 'evee-ms-mlflow' package to use the MLflow backend."

    raise ValueError(msg)


def _resolve_typed_config(backend_class: type, tracking_config: TrackingBackendConfig) -> BaseModel:
    """Resolve the typed config from a backend's Generic parameter.

    If the backend class is parameterized as TrackingBackend[SomeConfig],
    this extracts SomeConfig and instantiates it from the raw tracking_config.

    Args:
        backend_class: The backend class (may be Generic-parameterized)
        tracking_config: The raw TrackingBackendConfig with extra fields

    Returns:
        Typed config instance, or the original tracking_config if no Generic param
    """
    # Look for Generic base classes
    for base in getattr(backend_class, "__orig_bases__", []):
        origin = get_origin(base)
        if origin is TrackingBackend:
            args = get_args(base)
            if args:
                config_type = args[0]
                # Check if it's a real type (not a TypeVar)
                if isinstance(config_type, type) and issubclass(config_type, BaseModel):
                    # Build the typed config from the raw config's data + extras
                    data = tracking_config.model_dump()
                    extras = tracking_config.model_extra or {}
                    data.update(extras)
                    return config_type.model_validate(data)

    # Fallback: return the original config
    return tracking_config
