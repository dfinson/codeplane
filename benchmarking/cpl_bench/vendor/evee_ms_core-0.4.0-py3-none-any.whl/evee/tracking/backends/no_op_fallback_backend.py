from ...config import TrackingBackendConfig
from ...logging.logger import setup_logger
from ..backend import TrackingBackend
from ..events import (
    ArtifactGeneratedEvent,
    ExperimentCompletedEvent,
    ExperimentStartEvent,
    InferenceCompletedEvent,
    InferenceStartEvent,
    ModelRunCompletedEvent,
    ModelRunStartEvent,
    ResultsAnalyzedEvent,
)

logger = setup_logger(__name__)


class NoOpFallbackBackend(TrackingBackend[TrackingBackendConfig]):
    """No-op tracking backend that does nothing.

    Used as a fallback when no specific tracking backend is configured.
    """

    def __init__(self, config: TrackingBackendConfig | None = None) -> None:
        """Initialize default backend.

        Args:
            config: Tracking backend configuration (optional, ignored by this backend).
        """
        logger.info("Initializing NoOpFallbackBackend (no external tracking configured)")
        self._config = config

    def start_run(self, event: ModelRunStartEvent) -> str | None:
        """Start a run and return the run name as run ID."""
        return event.run_id

    def on_experiment_started(self, event: ExperimentStartEvent) -> None:
        pass

    def on_experiment_completed(self, event: ExperimentCompletedEvent) -> None:
        pass

    def on_run_completed(self, event: ModelRunCompletedEvent) -> None:
        if event.error:
            logger.error(f"Run '{event.run_id}' failed with error: {event.error}")

    def on_inference_started(self, event: InferenceStartEvent) -> None:
        pass

    def on_inference_completed(self, event: InferenceCompletedEvent) -> None:
        pass

    def on_results_analyzed(self, event: ResultsAnalyzedEvent) -> None:
        pass

    def on_artifact_generated(self, event: ArtifactGeneratedEvent) -> None:
        pass
