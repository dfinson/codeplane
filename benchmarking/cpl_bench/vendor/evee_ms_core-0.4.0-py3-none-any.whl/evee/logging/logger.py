import logging
import os
import threading
from pathlib import Path

from rich.console import Console
from rich.logging import RichHandler

from evee.utils.environment import is_rich_compatible_environment

DEFAULT_LOGGER_NAME = "model_evaluation"
DEFAULT_LOG_DIR = "logs"
LOG_FILE_NAME = "model_evaluation.log"

_shared_console: Console | None = None
_console_lock = threading.Lock()


def get_console() -> Console:
    """Get or create the shared console instance."""
    global _shared_console
    with _console_lock:
        if _shared_console is None:
            _shared_console = Console(force_terminal=True)
    return _shared_console


def _get_log_level() -> int:
    name = os.getenv("LOG_LEVEL", "INFO").upper()
    return logging.getLevelNamesMapping().get(name, logging.INFO)


def _create_console_handler(level: int, console: Console | None = None) -> logging.Handler:
    if not is_rich_compatible_environment():
        handler: logging.Handler = logging.StreamHandler()
    else:
        if console is None:
            console = get_console()
        handler = RichHandler(rich_tracebacks=True, console=console)

    handler.setLevel(level)
    return handler


def setup_logger(
    logger_name: str = DEFAULT_LOGGER_NAME,
    logs_path: str = DEFAULT_LOG_DIR,
    *,
    force: bool = False,
    console: Console | None = None,
) -> logging.Logger:
    level = _get_log_level()
    log_dir = Path(os.getenv("LOG_PATH", logs_path))
    log_dir.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger(logger_name)
    logger.setLevel(level)

    # If handlers exist and not forced, return existing logger to avoid duplicates
    if logger.hasHandlers() and not force:
        return logger

    if force:
        logger.handlers.clear()

    # Create handlers
    # Use minimal format for Rich (it handles time/level), full format for plain stream
    use_rich = is_rich_compatible_environment()
    console_fmt = logging.Formatter("%(message)s") if use_rich else logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    if console is None:
        console = get_console()

    console_handler = _create_console_handler(level, console=console)
    console_handler.setFormatter(console_fmt)

    file_fmt = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler = logging.FileHandler(log_dir / LOG_FILE_NAME)
    file_handler.setLevel(level)
    file_handler.setFormatter(file_fmt)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    logger.propagate = False

    return logger
