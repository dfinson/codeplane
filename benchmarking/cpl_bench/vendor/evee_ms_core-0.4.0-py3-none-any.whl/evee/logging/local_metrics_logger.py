"""Unified logging functionality for model evaluation metrics."""

import json
import os
import threading
from collections import defaultdict
from pathlib import Path

from ..core.models.evaluation_output import EvaluationOutput
from ..evaluation.metrics_aggregator import AggregatedMetrics
from .logger import setup_logger


class LocalMetricsLogger:
    """Default local metrics logger.

    Responsible for persisting evaluation artifacts to the local filesystem.
    This includes appending individual inference results to log files in a thread-safe
    manner and saving aggregated metric summaries as JSON files.
    """

    def __init__(self, output_dir: str):
        """Initialize metrics logger.

        Args:
            output_dir: Directory where metric files will be saved
        """
        self.output_dir = output_dir
        self.logger = setup_logger(self.__class__.__module__)
        self._locks = defaultdict(threading.Lock)
        self._locks_guard = threading.Lock()

        os.makedirs(output_dir, exist_ok=True)

    def _get_lock(self, key: str) -> threading.Lock:
        with self._locks_guard:
            return self._locks[key]

    def log_inference_result(self, evaluation_output: EvaluationOutput, output_path: Path) -> None:
        """Save a single inference result to the local results file.

        Args:
            evaluation_output: Evaluation output object containing the model inference result and metrics
            output_path: Path to the results file
        """
        try:
            with self._get_lock(str(output_path)), open(output_path, "a") as f:
                output_dict = evaluation_output.to_dict()
                f.write(json.dumps(output_dict) + "\n")
            self.logger.debug(f"Successfully saved evaluation result to {output_path}")
        except Exception:
            self.logger.exception("Failed to save model inference result")
            raise

    def log_results(self, results: AggregatedMetrics, results_path) -> Path:
        """Save aggregated metrics to local file.

        Args:
            results: Aggregated metrics to save
            results_path: Path to the raw results file (artifact)

        Returns:
            Path to the saved results JSON file

        Raises:
            Exception: If there's an error during logging
        """
        try:
            output_file = f"{results_path.stem}_results.json"
            output_path = Path(self.output_dir) / output_file

            with open(output_path, "w") as f:
                json.dump(results.to_dict(), f, indent=2)

            self.logger.debug(f"Analyzed Results Summary for run ID {results.run_id}\nTags: {results.tags} \nAggregated Metrics: {results.aggregated_metrics} \nSaved to: {output_path}")
            return output_path

        except Exception:
            self.logger.exception(f"Failed to analyze and log results for '{results_path}'")
            raise
